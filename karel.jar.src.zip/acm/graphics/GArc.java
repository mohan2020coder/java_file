/*     */ package acm.graphics;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GArc
/*     */   extends GObject
/*     */   implements GFillable, GScalable
/*     */ {
/*     */   public static final double ARC_TOLERANCE = 2.5D;
/*     */   private double width;
/*     */   private double height;
/*     */   private double start;
/*     */   private double sweep;
/*     */   private boolean fill;
/*     */   private Color fillColor;
/*     */   
/*  49 */   public GArc(double width, double height, double start, double sweep) { this(0.0D, 0.0D, width, height, start, sweep); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GArc(double x, double y, double width, double height, double start, double sweep) {
/*  80 */     this.width = width;
/*  81 */     this.height = height;
/*  82 */     this.start = start;
/*  83 */     this.sweep = sweep;
/*  84 */     setLocation(x, y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setStartAngle(double start) {
/*  95 */     this.start = start;
/*  96 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 107 */   public double getStartAngle() { return this.start; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSweepAngle(double sweep) {
/* 118 */     this.sweep = sweep;
/* 119 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 130 */   public double getSweepAngle() { return this.sweep; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 141 */   public GPoint getStartPoint() { return getArcPoint(this.start); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 152 */   public GPoint getEndPoint() { return getArcPoint(this.start + this.sweep); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void paint(Graphics g) {
/* 162 */     Rectangle r = getAWTBounds();
/* 163 */     int cx = GObject.round(getX() + this.width / 2.0D);
/* 164 */     int cy = GObject.round(getY() + this.width / 2.0D);
/* 165 */     int iStart = GObject.round(this.start);
/* 166 */     int iSweep = GObject.round(this.sweep);
/* 167 */     if (isFilled()) {
/* 168 */       g.setColor(getFillColor());
/* 169 */       g.fillArc(r.x, r.y, r.width, r.height, iStart, iSweep);
/* 170 */       g.setColor(getColor());
/* 171 */       g.drawArc(r.x, r.y, r.width, r.height, iStart, iSweep);
/* 172 */       Point start = getArcPoint(iStart).toPoint();
/* 173 */       g.drawLine(cx, cy, start.x, start.y);
/* 174 */       Point end = getArcPoint((iStart + iSweep)).toPoint();
/* 175 */       g.drawLine(cx, cy, end.x, end.y);
/*     */     } else {
/* 177 */       g.drawArc(r.x, r.y, r.width, r.height, iStart, iSweep);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GRectangle getBounds() {
/* 194 */     double rx = this.width / 2.0D;
/* 195 */     double ry = this.height / 2.0D;
/* 196 */     double cx = getX() + rx;
/* 197 */     double cy = getY() + ry;
/* 198 */     double p1x = cx + Math.cos(GObject.toRadians(this.start)) * rx;
/* 199 */     double p1y = cy - Math.sin(GObject.toRadians(this.start)) * ry;
/* 200 */     double p2x = cx + Math.cos(GObject.toRadians(this.start + this.sweep)) * rx;
/* 201 */     double p2y = cy - Math.sin(GObject.toRadians(this.start + this.sweep)) * ry;
/* 202 */     double xMin = Math.min(p1x, p2x);
/* 203 */     double xMax = Math.max(p1x, p2x);
/* 204 */     double yMin = Math.min(p1y, p2y);
/* 205 */     double yMax = Math.max(p1y, p2y);
/* 206 */     if (containsAngle(0.0D)) xMax = cx + rx; 
/* 207 */     if (containsAngle(90.0D)) yMin = cy - ry; 
/* 208 */     if (containsAngle(180.0D)) xMin = cx - rx; 
/* 209 */     if (containsAngle(270.0D)) yMax = cy + ry; 
/* 210 */     if (isFilled()) {
/* 211 */       xMin = Math.min(xMin, cx);
/* 212 */       yMin = Math.min(yMin, cy);
/* 213 */       xMax = Math.max(xMax, cx);
/* 214 */       yMax = Math.max(yMax, cy);
/*     */     } 
/* 216 */     return new GRectangle(xMin, yMin, xMax - xMin + 1.0D, yMax - yMin + 1.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(double x, double y) {
/* 234 */     double rx = this.width / 2.0D;
/* 235 */     double ry = this.height / 2.0D;
/* 236 */     if (rx == 0.0D || ry == 0.0D) return false; 
/* 237 */     double dx = x - getX() + rx;
/* 238 */     double dy = y - getY() + ry;
/* 239 */     double r = dx * dx / rx * rx + dy * dy / ry * ry;
/* 240 */     if (isFilled()) {
/* 241 */       if (r > 1.0D) return false; 
/*     */     } else {
/* 243 */       double t = 2.5D / (rx + ry) / 2.0D;
/* 244 */       if (Math.abs(1.0D - r) > t) return false; 
/*     */     } 
/* 246 */     return containsAngle(GObject.toDegrees(Math.atan2(-dy, dx)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFrameRectangle(double x, double y, double width, double height) {
/* 260 */     this.width = width;
/* 261 */     this.height = height;
/* 262 */     setLocation(x, y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 273 */   public final void setFrameRectangle(GRectangle bounds) { setFrameRectangle(bounds.getX(), bounds.getY(), bounds.getWidth(), bounds.getHeight()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 287 */   public GRectangle getFrameRectangle() { return new GRectangle(getX(), getY(), this.width, this.height); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void scale(double sx, double sy) {
/* 299 */     this.width *= sx;
/* 300 */     this.height *= sy;
/* 301 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 313 */   public final void scale(double sf) { scale(sf, sf); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFilled(boolean fill) {
/* 324 */     this.fill = fill;
/* 325 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 336 */   public boolean isFilled() { return this.fill; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFillColor(Color c) {
/* 347 */     this.fillColor = c;
/* 348 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 361 */   public Color getFillColor() { return (this.fillColor == null) ? getColor() : this.fillColor; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 512 */   protected Rectangle getAWTBounds() { return new Rectangle(GObject.round(getX()), GObject.round(getY()), GObject.round(this.width), GObject.round(this.height)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String paramString() {
/* 521 */     String tail = super.paramString();
/* 522 */     tail = tail.substring(tail.indexOf(')') + 1);
/* 523 */     GRectangle r = getFrameRectangle();
/* 524 */     String param = "frame=(" + r.getX() + ", " + r.getY() + ", " + 
/* 525 */       r.getWidth() + ", " + r.getHeight() + ")";
/* 526 */     param = String.valueOf(param) + ", start=" + this.start + ", sweep=" + this.sweep;
/* 527 */     return String.valueOf(param) + tail;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private GPoint getArcPoint(double angle) {
/* 535 */     double rx = this.width / 2.0D;
/* 536 */     double ry = this.height / 2.0D;
/* 537 */     double cx = getX() + rx;
/* 538 */     double cy = getY() + ry;
/* 539 */     double theta = GObject.toRadians(angle);
/* 540 */     return new GPoint(cx + rx * Math.cos(theta), cy - ry * Math.sin(theta));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean containsAngle(double theta) {
/* 548 */     double start = Math.min(getStartAngle(), getStartAngle() + getSweepAngle());
/* 549 */     double sweep = Math.abs(getSweepAngle());
/* 550 */     if (sweep >= 360.0D) return true; 
/* 551 */     start = (start < 0.0D) ? (360.0D - -start % 360.0D) : (start % 360.0D);
/* 552 */     if (start + sweep > 360.0D) {
/* 553 */       return !(theta < start && theta > start + sweep - 360.0D);
/*     */     }
/* 555 */     return (theta >= start && theta <= start + sweep);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 575 */   public static void test() { (new GArcTest()).main(); }
/*     */ }


/* Location:              /root/karel.jar!/acm/graphics/GArc.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */