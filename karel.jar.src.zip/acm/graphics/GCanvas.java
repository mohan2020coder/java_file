/*     */ package acm.graphics;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Image;
/*     */ import java.awt.MenuBar;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GCanvas
/*     */   extends Container
/*     */   implements GContainer
/*     */ {
/*     */   private GCanvasListener gCanvasListener;
/*     */   private GObject lastObject;
/*     */   private GObject dragObject;
/*     */   private Vector contents;
/*     */   private MenuBar menuBar;
/*     */   private Image offscreenImage;
/*     */   private boolean autoRepaint;
/*     */   private boolean nativeArcFlag;
/*     */   private boolean menuBarInitialized;
/*     */   private boolean opaque;
/*     */   
/*     */   public GCanvas() {
/*  33 */     this.contents = new Vector();
/*  34 */     setBackground(Color.white);
/*  35 */     setOpaque(true);
/*  36 */     setAutoRepaintFlag(true);
/*  37 */     setLayout(null);
/*  38 */     this.gCanvasListener = new GCanvasListener(this);
/*  39 */     addFocusListener(this.gCanvasListener);
/*  40 */     addComponentListener(this.gCanvasListener);
/*  41 */     addMouseListener(this.gCanvasListener);
/*  42 */     addMouseMotionListener(this.gCanvasListener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(GObject gobj) {
/*  53 */     synchronized (this.contents) {
/*  54 */       if (gobj.getParent() != null) gobj.getParent().remove(gobj); 
/*  55 */       gobj.setParent(this);
/*  56 */       this.contents.addElement(gobj);
/*     */     } 
/*  58 */     conditionalRepaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void add(GObject gobj, double x, double y) {
/*  72 */     add(gobj);
/*  73 */     gobj.setLocation(x, y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  85 */   public final void add(GObject gobj, GPoint pt) { add(gobj, pt.getX(), pt.getY()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove(GObject gobj) {
/*  96 */     synchronized (this.contents) {
/*  97 */       this.contents.removeElement(gobj);
/*  98 */       gobj.setParent(null);
/*     */     } 
/* 100 */     conditionalRepaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeAll() {
/* 110 */     synchronized (this.contents) {
/* 111 */       this.contents.removeAllElements();
/*     */     } 
/* 113 */     super.removeAll();
/* 114 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Component add(Component comp) {
/* 129 */     super.add(comp);
/* 130 */     Dimension size = comp.getSize();
/* 131 */     if (size.width == 0 || size.height == 0) {
/* 132 */       Dimension preferredSize = comp.getPreferredSize();
/* 133 */       if (size.width == 0) size.width = preferredSize.width; 
/* 134 */       if (size.height == 0) size.height = preferredSize.height; 
/* 135 */       comp.setSize(size);
/*     */     } 
/* 137 */     return comp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void add(Component comp, double x, double y) {
/* 151 */     comp.setLocation(GObject.round(x), GObject.round(y));
/* 152 */     add(comp);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 164 */   public final void add(Component comp, GPoint pt) { add(comp, pt.getX(), pt.getY()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove(Component comp) {
/* 175 */     synchronized (this.contents) {
/* 176 */       super.remove(comp);
/*     */     } 
/* 178 */     conditionalRepaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 189 */   public int getElementCount() { return this.contents.size(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 202 */   public GObject getElement(int index) { return (GObject)this.contents.elementAt(index); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GObject getElementAt(double x, double y) {
/* 218 */     synchronized (this.contents) {
/* 219 */       for (int i = getElementCount() - 1; i >= 0; i--) {
/* 220 */         GObject gobj = getElement(i);
/* 221 */         if (gobj.contains(x, y)) return gobj; 
/*     */       } 
/*     */     } 
/* 224 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 238 */   public final GObject getElementAt(GPoint pt) { return getElementAt(pt.getX(), pt.getY()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 261 */   public Iterator iterator() { return iterator(0); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 285 */   public Iterator iterator(int direction) { return GCompound.createIterator(this, direction); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MenuBar getMenuBar() {
/* 296 */     if (!this.menuBarInitialized) {
/* 297 */       this.menuBar = createMenuBar();
/* 298 */       this.menuBarInitialized = true;
/*     */     } 
/* 300 */     return this.menuBar;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOpaque(boolean flag) {
/* 316 */     this.opaque = flag;
/* 317 */     conditionalRepaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 330 */   public boolean isOpaque() { return this.opaque; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 343 */   public int getWidth() { return (getSize()).width; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 356 */   public int getHeight() { return (getSize()).height; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void paint(Graphics g) {
/* 368 */     Graphics g0 = g;
/* 369 */     if (isOpaque()) {
/* 370 */       if (this.offscreenImage == null) initOffscreenImage(); 
/* 371 */       if (this.offscreenImage != null) g = this.offscreenImage.getGraphics(); 
/* 372 */       Dimension size = getSize();
/* 373 */       g.setColor(getBackground());
/* 374 */       g.fillRect(0, 0, size.width, size.height);
/* 375 */       g.setColor(getForeground());
/*     */     } 
/* 377 */     synchronized (this.contents) {
/* 378 */       for (Enumeration e = this.contents.elements(); e.hasMoreElements();) {
/* 379 */         ((GObject)e.nextElement()).paintObject(g);
/*     */       }
/*     */     } 
/* 382 */     if (isOpaque() && this.offscreenImage != null) {
/* 383 */       g0.drawImage(this.offscreenImage, 0, 0, this);
/*     */     }
/* 385 */     super.paint(g0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 398 */   public void update(Graphics g) { paint(g); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 418 */   public void setAutoRepaintFlag(boolean state) { this.autoRepaint = state; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 431 */   public boolean getAutoRepaintFlag() { return this.autoRepaint; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 446 */   public void setNativeArcFlag(boolean state) { this.nativeArcFlag = state; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 459 */   public boolean getNativeArcFlag() { return this.nativeArcFlag; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 471 */   protected MenuBar createMenuBar() { return new GCanvasMenuBar(this); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void sendToFront(GObject gobj) {
/* 482 */     synchronized (this.contents) {
/* 483 */       int index = this.contents.indexOf(gobj);
/* 484 */       if (index >= 0) {
/* 485 */         this.contents.removeElementAt(index);
/* 486 */         this.contents.addElement(gobj);
/*     */       } 
/*     */     } 
/* 489 */     conditionalRepaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void sendToBack(GObject gobj) {
/* 500 */     synchronized (this.contents) {
/* 501 */       int index = this.contents.indexOf(gobj);
/* 502 */       if (index >= 0) {
/* 503 */         this.contents.removeElementAt(index);
/* 504 */         this.contents.insertElementAt(gobj, 0);
/*     */       } 
/*     */     } 
/* 507 */     conditionalRepaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void sendForward(GObject gobj) {
/* 518 */     synchronized (this.contents) {
/* 519 */       int index = this.contents.indexOf(gobj);
/* 520 */       if (index >= 0) {
/* 521 */         this.contents.removeElementAt(index);
/* 522 */         this.contents.insertElementAt(gobj, Math.min(this.contents.size(), index + 1));
/*     */       } 
/*     */     } 
/* 525 */     conditionalRepaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void sendBackward(GObject gobj) {
/* 536 */     synchronized (this.contents) {
/* 537 */       int index = this.contents.indexOf(gobj);
/* 538 */       if (index >= 0) {
/* 539 */         this.contents.removeElementAt(index);
/* 540 */         this.contents.insertElementAt(gobj, Math.max(0, index - 1));
/*     */       } 
/*     */     } 
/* 543 */     conditionalRepaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void dispatchMouseEvent(MouseEvent e) {
/* 556 */     GObject gobj = getElementAt(e.getX(), e.getY());
/* 557 */     MouseEvent newEvent = null;
/* 558 */     if (gobj != this.lastObject) {
/* 559 */       if (this.lastObject != null) {
/* 560 */         newEvent = new GMouseEvent(this.lastObject, 505, e);
/* 561 */         this.lastObject.fireMouseListeners(newEvent);
/*     */       } 
/* 563 */       if (gobj != null) {
/* 564 */         newEvent = new GMouseEvent(gobj, 504, e);
/* 565 */         gobj.fireMouseListeners(newEvent);
/*     */       } 
/*     */     } 
/* 568 */     this.lastObject = gobj;
/* 569 */     if (this.dragObject != null) gobj = this.dragObject; 
/* 570 */     if (gobj != null) {
/* 571 */       int id = e.getID();
/* 572 */       if (id != 505 && id != 504) {
/* 573 */         if (id == 501) {
/* 574 */           this.dragObject = gobj;
/* 575 */         } else if (id == 502) {
/* 576 */           this.dragObject = null;
/*     */         } 
/* 578 */         newEvent = new GMouseEvent(gobj, id, e);
/* 579 */         gobj.fireMouseListeners(newEvent);
/*     */       } 
/*     */     } 
/* 582 */     if (newEvent != null && newEvent.isConsumed()) e.consume();
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initOffscreenImage() {
/* 593 */     synchronized (this.contents) {
/* 594 */       Dimension size = getSize();
/* 595 */       this.offscreenImage = createImage(size.width, size.height);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 609 */   protected void conditionalRepaint() { if (this.autoRepaint) repaint();
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 632 */   public static void test() { (new GCanvasTest()).main(); }
/*     */ }


/* Location:              /root/karel.jar!/acm/graphics/GCanvas.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */