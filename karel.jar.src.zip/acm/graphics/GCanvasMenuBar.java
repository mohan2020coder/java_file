/*    */ package acm.graphics;
/*    */ 
/*    */ import acm.util.AppletMenuBar;
/*    */ import acm.util.Platform;
/*    */ import java.awt.Frame;
/*    */ import java.awt.Menu;
/*    */ import java.awt.PrintJob;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GCanvasMenuBar
/*    */   extends AppletMenuBar
/*    */ {
/*    */   private GCanvas gc;
/*    */   
/* 28 */   public GCanvasMenuBar(GCanvas gc) { this.gc = gc; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 36 */   public void initMenus() { add(createFileMenu()); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Menu createFileMenu() {
/* 44 */     Menu menu = new Menu("File");
/* 45 */     setMnemonic(menu, 70);
/* 46 */     menu.add(createMenuItem("Print", 80));
/* 47 */     menu.addSeparator();
/* 48 */     addQuitItem(menu);
/* 49 */     return menu;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void menuAction(String cmd) {
/* 66 */     if (cmd.equals("Print")) {
/* 67 */       Frame frame = Platform.getEnclosingFrame(this.gc);
/* 68 */       if (frame == null)
/* 69 */         return;  PrintJob pj = this.gc.getToolkit().getPrintJob(frame, "Graphics", null);
/* 70 */       if (pj == null)
/* 71 */         return;  this.gc.print(pj.getGraphics());
/* 72 */       pj.end();
/*    */     } else {
/* 74 */       super.menuAction(cmd);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /root/karel.jar!/acm/graphics/GCanvasMenuBar.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */