/*     */ package acm.graphics;
/*     */ 
/*     */ import acm.util.ErrorException;
/*     */ import java.awt.Component;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GCompound
/*     */   extends GObject
/*     */   implements GContainer, GScalable
/*     */ {
/*     */   private GObject dragObject;
/*     */   private GObject lastObject;
/*  32 */   private Vector contents = new Vector();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean complete = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(GObject gobj) {
/*  44 */     if (this.complete) {
/*  45 */       throw new ErrorException("You can't add objects to a GCompound that has been marked as complete.");
/*     */     }
/*     */     
/*  48 */     synchronized (this.contents) {
/*  49 */       if (gobj.getParent() != null) gobj.getParent().remove(gobj); 
/*  50 */       gobj.setParent(this);
/*  51 */       this.contents.addElement(gobj);
/*     */     } 
/*  53 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void add(GObject gobj, double x, double y) {
/*  67 */     add(gobj);
/*  68 */     gobj.setLocation(x, y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  80 */   public final void add(GObject gobj, GPoint pt) { add(gobj, pt.getX(), pt.getY()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove(GObject gobj) {
/*  91 */     if (this.complete) {
/*  92 */       throw new ErrorException("You can't remove objects from a GCompound that has been marked as complete.");
/*     */     }
/*     */     
/*  95 */     synchronized (this.contents) {
/*  96 */       this.contents.removeElement(gobj);
/*  97 */       gobj.setParent(null);
/*     */     } 
/*  99 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeAll() {
/* 109 */     if (this.complete) {
/* 110 */       throw new ErrorException("You can't remove objects from a GCompound that has been marked as complete.");
/*     */     }
/*     */     
/* 113 */     synchronized (this.contents) {
/* 114 */       this.contents.removeAllElements();
/*     */     } 
/* 116 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 127 */   public int getElementCount() { return this.contents.size(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 140 */   public GObject getElement(int index) { return (GObject)this.contents.elementAt(index); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GObject getElementAt(double x, double y) {
/* 158 */     synchronized (this.contents) {
/* 159 */       for (int i = getElementCount() - 1; i >= 0; i--) {
/* 160 */         GObject gobj = getElement(i);
/* 161 */         if (gobj.contains(x, y)) return gobj; 
/*     */       } 
/*     */     } 
/* 164 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 178 */   public final GObject getElementAt(GPoint pt) { return getElementAt(pt.getX(), pt.getY()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 201 */   public Iterator iterator() { return iterator(0); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 225 */   public Iterator iterator(int direction) { return createIterator(this, direction); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispatchMouseEvent(MouseEvent e) {
/* 235 */     GPoint pt = new GPoint(e.getX() - getX(), e.getY() - getY());
/* 236 */     GObject gobj = getElementAt(pt);
/* 237 */     MouseEvent newEvent = null;
/* 238 */     if (gobj != this.lastObject) {
/* 239 */       if (this.lastObject != null) {
/* 240 */         newEvent = new GMouseEvent(this.lastObject, 505, e);
/* 241 */         this.lastObject.fireMouseListeners(newEvent);
/*     */       } 
/* 243 */       if (gobj != null) {
/* 244 */         newEvent = new GMouseEvent(gobj, 504, e);
/* 245 */         gobj.fireMouseListeners(newEvent);
/*     */       } 
/*     */     } 
/* 248 */     this.lastObject = gobj;
/* 249 */     if (this.dragObject != null) gobj = this.dragObject; 
/* 250 */     if (gobj != null) {
/* 251 */       int id = e.getID();
/* 252 */       if (id != 505 && id != 504) {
/* 253 */         if (id == 501) {
/* 254 */           this.dragObject = gobj;
/* 255 */         } else if (id == 502) {
/* 256 */           this.dragObject = null;
/*     */         } 
/* 258 */         newEvent = new GMouseEvent(gobj, id, e);
/* 259 */         gobj.fireMouseListeners(newEvent);
/*     */       } 
/*     */     } 
/* 262 */     if (newEvent != null && newEvent.isConsumed()) e.consume();
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void paint(Graphics g) {
/* 273 */     g = g.create();
/* 274 */     g.translate(GObject.round(getX()), GObject.round(getY()));
/* 275 */     synchronized (this.contents) {
/* 276 */       for (Enumeration e = this.contents.elements(); e.hasMoreElements();) {
/* 277 */         ((GObject)e.nextElement()).paintObject(g);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void scale(double sx, double sy) {
/* 293 */     Component comp = getComponent();
/* 294 */     boolean oldAutoRepaint = false;
/* 295 */     if (comp instanceof GCanvas) {
/* 296 */       oldAutoRepaint = ((GCanvas)comp).getAutoRepaintFlag();
/* 297 */       ((GCanvas)comp).setAutoRepaintFlag(false);
/*     */     } 
/* 299 */     for (int i = getElementCount() - 1; i >= 0; i--) {
/* 300 */       GObject gobj = getElement(i);
/* 301 */       gobj.setLocation(sx * gobj.getX(), sy * gobj.getY());
/* 302 */       if (gobj instanceof GScalable) {
/* 303 */         ((GScalable)gobj).scale(sx, sy);
/*     */       }
/*     */     } 
/* 306 */     if (comp instanceof GCanvas) {
/* 307 */       ((GCanvas)comp).setAutoRepaintFlag(oldAutoRepaint);
/*     */     }
/* 309 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 321 */   public final void scale(double sf) { scale(sf, sf); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GRectangle getBounds() {
/* 333 */     GRectangle bounds = new GRectangle();
/* 334 */     boolean first = true;
/* 335 */     synchronized (this.contents) {
/* 336 */       for (Enumeration e = this.contents.elements(); e.hasMoreElements(); ) {
/* 337 */         if (first) {
/* 338 */           bounds = new GRectangle(((GObject)e.nextElement()).getBounds());
/* 339 */           first = false; continue;
/*     */         } 
/* 341 */         bounds.add(((GObject)e.nextElement()).getBounds());
/*     */       } 
/*     */     } 
/*     */     
/* 345 */     bounds.translate(getX(), getY());
/* 346 */     return bounds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(double x, double y) {
/* 361 */     double cx = x - getX();
/* 362 */     double cy = y - getY();
/* 363 */     synchronized (this.contents) {
/* 364 */       for (Enumeration e = this.contents.elements(); e.hasMoreElements(); ) {
/* 365 */         GObject gobj = (GObject)e.nextElement();
/* 366 */         if (gobj.contains(cx, cy)) return true; 
/*     */       } 
/*     */     } 
/* 369 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 381 */   public void markAsComplete() { this.complete = true; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void sendToFront(GObject gobj) {
/* 520 */     synchronized (this.contents) {
/* 521 */       int index = this.contents.indexOf(gobj);
/* 522 */       if (index >= 0) {
/* 523 */         this.contents.removeElementAt(index);
/* 524 */         this.contents.addElement(gobj);
/*     */       } 
/*     */     } 
/* 527 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void sendToBack(GObject gobj) {
/* 538 */     synchronized (this.contents) {
/* 539 */       int index = this.contents.indexOf(gobj);
/* 540 */       if (index >= 0) {
/* 541 */         this.contents.removeElementAt(index);
/* 542 */         this.contents.insertElementAt(gobj, 0);
/*     */       } 
/*     */     } 
/* 545 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void sendForward(GObject gobj) {
/* 556 */     synchronized (this.contents) {
/* 557 */       int index = this.contents.indexOf(gobj);
/* 558 */       if (index >= 0) {
/* 559 */         this.contents.removeElementAt(index);
/* 560 */         this.contents.insertElementAt(gobj, Math.min(this.contents.size(), index + 1));
/*     */       } 
/*     */     } 
/* 563 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void sendBackward(GObject gobj) {
/* 574 */     synchronized (this.contents) {
/* 575 */       int index = this.contents.indexOf(gobj);
/* 576 */       if (index >= 0) {
/* 577 */         this.contents.removeElementAt(index);
/* 578 */         this.contents.insertElementAt(gobj, Math.max(0, index - 1));
/*     */       } 
/*     */     } 
/* 581 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static Iterator createIterator(GContainer container, int direction) {
/*     */     try {
/* 594 */       Class iteratorClass = Class.forName("acm.graphics.GIterator");
/* 595 */       Class[] types = { Class.forName("acm.graphics.GContainer"), int.class };
/* 596 */       Object[] args = { container, new Integer(direction) };
/* 597 */       Constructor constructor = iteratorClass.getConstructor(types);
/* 598 */       return (Iterator)constructor.newInstance(args);
/* 599 */     } catch (Exception ex) {
/* 600 */       throw new ErrorException("Unable to create an Iterator on this platform.");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 618 */   public static void test() { (new GCompoundTest()).main(); }
/*     */ }


/* Location:              /root/karel.jar!/acm/graphics/GCompound.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */