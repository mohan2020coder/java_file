package acm.graphics;

public interface GContainer {
  public static final int BACK_TO_FRONT = 0;
  
  public static final int FRONT_TO_BACK = 1;
  
  void add(GObject paramGObject);
  
  void add(GObject paramGObject, double paramDouble1, double paramDouble2);
  
  void add(GObject paramGObject, GPoint paramGPoint);
  
  void remove(GObject paramGObject);
  
  void removeAll();
  
  int getElementCount();
  
  GObject getElement(int paramInt);
  
  GObject getElementAt(double paramDouble1, double paramDouble2);
  
  GObject getElementAt(GPoint paramGPoint);
}


/* Location:              /root/karel.jar!/acm/graphics/GContainer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */