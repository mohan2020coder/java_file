package acm.graphics;

import java.awt.Color;

public interface GFillable {
  void setFilled(boolean paramBoolean);
  
  boolean isFilled();
  
  void setFillColor(Color paramColor);
  
  Color getFillColor();
}


/* Location:              /root/karel.jar!/acm/graphics/GFillable.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */