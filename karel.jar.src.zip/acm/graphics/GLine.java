/*     */ package acm.graphics;
/*     */ 
/*     */ import java.awt.Graphics;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GLine
/*     */   extends GObject
/*     */   implements GScalable
/*     */ {
/*     */   public static final double LINE_TOLERANCE = 1.5D;
/*     */   private double dx;
/*     */   private double dy;
/*     */   
/*     */   public GLine(double x0, double y0, double x1, double y1) {
/*  45 */     setLocation(x0, y0);
/*  46 */     this.dx = x1 - x0;
/*  47 */     this.dy = y1 - y0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void paint(Graphics g) {
/*  57 */     double x = getX();
/*  58 */     double y = getY();
/*  59 */     g.drawLine(GObject.round(x), GObject.round(y), GObject.round(x + this.dx), GObject.round(y + this.dy));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GRectangle getBounds() {
/*  70 */     double x = Math.min(getX(), getX() + this.dx);
/*  71 */     double y = Math.min(getY(), getY() + this.dy);
/*  72 */     return new GRectangle(x, y, Math.abs(this.dx) + 1.0D, Math.abs(this.dy) + 1.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setStartPoint(double x, double y) {
/*  87 */     this.dx += getX() - x;
/*  88 */     this.dy += getY() - y;
/*  89 */     setLocation(x, y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 102 */   public GPoint getStartPoint() { return getLocation(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEndPoint(double x, double y) {
/* 115 */     this.dx = x - getX();
/* 116 */     this.dy = y - getY();
/* 117 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 128 */   public GPoint getEndPoint() { return new GPoint(getX() + this.dx, getY() + this.dy); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void scale(double sx, double sy) {
/* 141 */     this.dx *= sx;
/* 142 */     this.dy *= sy;
/* 143 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 155 */   public final void scale(double sf) { scale(sf, sf); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(double x, double y) {
/* 171 */     double x0 = getX();
/* 172 */     double y0 = getY();
/* 173 */     double x1 = x0 + this.dx;
/* 174 */     double y1 = y0 + this.dy;
/* 175 */     double tSquared = 2.25D;
/* 176 */     if (distanceSquared(x, y, x0, y0) < tSquared) return true; 
/* 177 */     if (distanceSquared(x, y, x1, y1) < tSquared) return true; 
/* 178 */     if (x < Math.min(x0, x1) - 1.5D) return false; 
/* 179 */     if (x > Math.max(x0, x1) + 1.5D) return false; 
/* 180 */     if (y < Math.min(y0, y1) - 1.5D) return false; 
/* 181 */     if (y > Math.max(y0, y1) + 1.5D) return false; 
/* 182 */     if ((float)x0 - (float)x1 == 0.0F && (float)y0 - (float)y1 == 0.0F) return false; 
/* 183 */     double u = ((x - x0) * (x1 - x0) + (y - y0) * (y1 - y0)) / distanceSquared(x0, y0, x1, y1);
/* 184 */     return (distanceSquared(x, y, x0 + u * (x1 - x0), y0 + u * (y1 - y0)) < tSquared);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String paramString() {
/* 283 */     String tail = super.paramString();
/* 284 */     tail = tail.substring(tail.indexOf(')') + 1);
/* 285 */     GPoint pt = getStartPoint();
/* 286 */     String param = "start=(" + pt.getX() + ", " + pt.getY() + ")";
/* 287 */     pt = getEndPoint();
/* 288 */     param = String.valueOf(param) + ", end=(" + pt.getX() + ", " + pt.getY() + ")";
/* 289 */     return String.valueOf(param) + tail;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 298 */   private double distanceSquared(double x0, double y0, double x1, double y1) { return (x1 - x0) * (x1 - x0) + (y1 - y0) * (y1 - y0); }
/*     */ }


/* Location:              /root/karel.jar!/acm/graphics/GLine.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */