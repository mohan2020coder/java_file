/*     */ package acm.graphics;
/*     */ 
/*     */ import acm.util.ErrorException;
/*     */ import java.awt.AWTEventMulticaster;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseListener;
/*     */ import java.awt.event.MouseMotionListener;
/*     */ import java.lang.reflect.Method;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class GObject
/*     */   implements Cloneable
/*     */ {
/*     */   private GContainer parent;
/*     */   private Color color;
/*     */   private boolean visible = true;
/*     */   private double x;
/*     */   private double y;
/*     */   private MouseListener mouseListener;
/*     */   private MouseMotionListener mouseMotionListener;
/*     */   
/*     */   public abstract void paint(Graphics paramGraphics);
/*     */   
/*     */   public abstract GRectangle getBounds();
/*     */   
/*     */   public void setLocation(double x, double y) {
/*  76 */     this.x = x;
/*  77 */     this.y = y;
/*  78 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  90 */   public final void setLocation(GPoint pt) { setLocation(pt.getX(), pt.getY()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 101 */   public GPoint getLocation() { return new GPoint(this.x, this.y); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 112 */   public double getX() { return this.x; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 123 */   public double getY() { return this.y; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 135 */   public void move(double dx, double dy) { setLocation(this.x + dx, this.y + dy); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void movePolar(double r, double theta) {
/* 151 */     double radians = theta * Math.PI / 180.0D;
/* 152 */     move(r * Math.cos(radians), -r * Math.sin(radians));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GDimension getSize() {
/* 163 */     GRectangle bounds = getBounds();
/* 164 */     return new GDimension(bounds.getWidth(), bounds.getHeight());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 176 */   public double getWidth() { return getBounds().getWidth(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 188 */   public double getHeight() { return getBounds().getHeight(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 205 */   public boolean contains(double x, double y) { return getBounds().contains(round(x), round(y)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 217 */   public final boolean contains(GPoint pt) { return contains(pt.getX(), pt.getY()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void sendToFront() {
/* 229 */     if (this.parent == null)
/* 230 */       return;  if (this.parent instanceof GCanvas) {
/* 231 */       ((GCanvas)this.parent).sendToFront(this);
/* 232 */     } else if (this.parent instanceof GCompound) {
/* 233 */       ((GCompound)this.parent).sendToFront(this);
/*     */     } else {
/*     */       try {
/* 236 */         Class parentClass = this.parent.getClass();
/* 237 */         Class[] types = { Class.forName("acm.graphics.GObject") };
/* 238 */         Object[] args = { this };
/* 239 */         Method fn = parentClass.getMethod("sendToFront", types);
/* 240 */         if (fn != null) fn.invoke(this.parent, args); 
/* 241 */       } catch (Exception exception) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void sendToBack() {
/* 256 */     if (this.parent == null)
/* 257 */       return;  if (this.parent instanceof GCanvas) {
/* 258 */       ((GCanvas)this.parent).sendToBack(this);
/* 259 */     } else if (this.parent instanceof GCompound) {
/* 260 */       ((GCompound)this.parent).sendToBack(this);
/*     */     } else {
/*     */       try {
/* 263 */         Class parentClass = this.parent.getClass();
/* 264 */         Class[] types = { Class.forName("acm.graphics.GObject") };
/* 265 */         Object[] args = { this };
/* 266 */         Method fn = parentClass.getMethod("sendToBack", types);
/* 267 */         if (fn != null) fn.invoke(this.parent, args); 
/* 268 */       } catch (Exception exception) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void sendForward() {
/* 282 */     if (this.parent == null)
/* 283 */       return;  if (this.parent instanceof GCanvas) {
/* 284 */       ((GCanvas)this.parent).sendForward(this);
/* 285 */     } else if (this.parent instanceof GCompound) {
/* 286 */       ((GCompound)this.parent).sendForward(this);
/*     */     } else {
/*     */       try {
/* 289 */         Class parentClass = this.parent.getClass();
/* 290 */         Class[] types = { Class.forName("acm.graphics.GObject") };
/* 291 */         Object[] args = { this };
/* 292 */         Method fn = parentClass.getMethod("sendForward", types);
/* 293 */         if (fn != null) fn.invoke(this.parent, args); 
/* 294 */       } catch (Exception exception) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void sendBackward() {
/* 308 */     if (this.parent == null)
/* 309 */       return;  if (this.parent instanceof GCanvas) {
/* 310 */       ((GCanvas)this.parent).sendBackward(this);
/* 311 */     } else if (this.parent instanceof GCompound) {
/* 312 */       ((GCompound)this.parent).sendBackward(this);
/*     */     } else {
/*     */       try {
/* 315 */         Class parentClass = this.parent.getClass();
/* 316 */         Class[] types = { Class.forName("acm.graphics.GObject") };
/* 317 */         Object[] args = { this };
/* 318 */         Method fn = parentClass.getMethod("sendBackward", types);
/* 319 */         if (fn != null) fn.invoke(this.parent, args); 
/* 320 */       } catch (Exception exception) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setColor(Color c) {
/* 334 */     this.color = c;
/* 335 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getColor() {
/* 346 */     GObject obj = this;
/* 347 */     while (obj.color == null) {
/* 348 */       GContainer parent = obj.getParent();
/* 349 */       if (parent instanceof Component) {
/* 350 */         return ((Component)parent).getForeground();
/*     */       }
/* 352 */       obj = (GObject)parent;
/*     */     } 
/* 354 */     return obj.color;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVisible(boolean visible) {
/* 365 */     this.visible = visible;
/* 366 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 377 */   public boolean isVisible() { return this.visible; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 387 */     String name = getClass().getName();
/* 388 */     if (name.startsWith("acm.graphics.")) {
/* 389 */       name = name.substring("acm.graphics.".length());
/*     */     }
/* 391 */     return String.valueOf(name) + "[" + paramString() + "]";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 403 */   public GContainer getParent() { return this.parent; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/*     */     try {
/* 416 */       Class programClass = Class.forName("acm.program.Program");
/* 417 */       String[] newArgs = new String[args.length + 1];
/* 418 */       for (int i = 0; i < args.length; i++) {
/* 419 */         newArgs[i] = args[i];
/*     */       }
/* 421 */       newArgs[args.length] = "program=acm.program.GObjectProgram";
/* 422 */       Class[] types = { newArgs.getClass() };
/* 423 */       Object[] params = { newArgs };
/* 424 */       Method main = programClass.getMethod("main", types);
/* 425 */       main.invoke(null, params);
/* 426 */     } catch (Exception ex) {
/* 427 */       throw new ErrorException(ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void pause(double milliseconds) {
/*     */     try {
/* 442 */       int millis = (int)milliseconds;
/* 443 */       int nanos = (int)Math.round((milliseconds - millis) * 1000000.0D);
/* 444 */       Thread.sleep(millis, nanos);
/* 445 */     } catch (InterruptedException interruptedException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 459 */   public static int round(double x) { return (int)Math.round(x); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 472 */   public static double sinD(double angle) { return Math.sin(toRadians(angle)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 485 */   public static double cosD(double angle) { return Math.cos(toRadians(angle)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 498 */   public static double tanD(double angle) { return sinD(angle) / cosD(angle); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 512 */   public static double toDegrees(double radians) { return radians * 180.0D / Math.PI; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 526 */   public static double toRadians(double degrees) { return degrees * Math.PI / 180.0D; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 540 */   public static double distance(double x, double y) { return distance(0.0D, 0.0D, x, y); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 557 */   public static double distance(double x0, double y0, double x1, double y1) { return Math.sqrt((x1 - x0) * (x1 - x0) + (y1 - y0) * (y1 - y0)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double angle(double x, double y) {
/* 576 */     if (x == 0.0D && y == 0.0D) return 0.0D; 
/* 577 */     return toDegrees(Math.atan2(-y, x));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 588 */   public void addMouseListener(MouseListener listener) { this.mouseListener = AWTEventMulticaster.add(this.mouseListener, listener); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 599 */   public void removeMouseListener(MouseListener listener) { this.mouseListener = AWTEventMulticaster.remove(this.mouseListener, listener); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 610 */   public void addMouseMotionListener(MouseMotionListener listener) { this.mouseMotionListener = AWTEventMulticaster.add(this.mouseMotionListener, listener); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 621 */   public void removeMouseMotionListener(MouseMotionListener listener) { this.mouseMotionListener = AWTEventMulticaster.remove(this.mouseMotionListener, listener); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 632 */   protected void start() { start(null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void start(String[] args) {
/*     */     try {
/* 646 */       Class programClass = Class.forName("acm.program.GraphicsProgram");
/* 647 */       Class gObjectClass = Class.forName("acm.graphics.GObject");
/* 648 */       Class[] types = { gObjectClass, args.getClass() };
/* 649 */       Object[] params = { this, args };
/* 650 */       Method startGraphicsProgram = programClass.getMethod("startGraphicsProgram", types);
/* 651 */       startGraphicsProgram.invoke(null, params);
/* 652 */     } catch (Exception ex) {
/* 653 */       throw new ErrorException(ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void fireMouseListeners(MouseEvent e) {
/* 666 */     switch (e.getID()) {
/*     */       case 501:
/* 668 */         if (this.mouseListener != null) this.mouseListener.mousePressed(e); 
/*     */         break;
/*     */       case 502:
/* 671 */         if (this.mouseListener != null) this.mouseListener.mouseReleased(e); 
/*     */         break;
/*     */       case 500:
/* 674 */         if (this.mouseListener != null) this.mouseListener.mouseClicked(e); 
/*     */         break;
/*     */       case 505:
/* 677 */         if (this.mouseListener != null) this.mouseListener.mouseExited(e); 
/*     */         break;
/*     */       case 504:
/* 680 */         if (this.mouseListener != null) this.mouseListener.mouseEntered(e); 
/*     */         break;
/*     */       case 503:
/* 683 */         if (this.mouseMotionListener != null) this.mouseMotionListener.mouseMoved(e); 
/*     */         break;
/*     */       case 506:
/* 686 */         if (this.mouseMotionListener != null) this.mouseMotionListener.mouseDragged(e);
/*     */         
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 699 */   protected Color getObjectColor() { return this.color; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String paramString() {
/* 708 */     String param = "";
/* 709 */     if (this instanceof GResizable) {
/* 710 */       GRectangle r = getBounds();
/* 711 */       param = String.valueOf(param) + "bounds=(" + r.getX() + ", " + r.getY() + ", " + 
/* 712 */         r.getWidth() + ", " + r.getHeight() + ")";
/*     */     } else {
/* 714 */       GPoint pt = getLocation();
/* 715 */       param = String.valueOf(param) + "location=(" + pt.getX() + ", " + pt.getY() + ")";
/*     */     } 
/* 717 */     if (this.color != null) {
/* 718 */       param = String.valueOf(param) + ", color=" + colorName(this.color);
/*     */     }
/* 720 */     if (this instanceof GFillable) {
/* 721 */       param = String.valueOf(param) + ", filled=" + ((GFillable)this).isFilled();
/* 722 */       Color fillColor = ((GFillable)this).getFillColor();
/* 723 */       if (fillColor != null && fillColor != this.color) {
/* 724 */         param = String.valueOf(param) + ", fillColor=" + colorName(fillColor);
/*     */       }
/*     */     } 
/* 727 */     return param;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static String colorName(Color color) {
/* 736 */     if (color == Color.black) return "black"; 
/* 737 */     if (color == Color.blue) return "blue"; 
/* 738 */     if (color == Color.cyan) return "cyan"; 
/* 739 */     if (color == Color.darkGray) return "darkGray"; 
/* 740 */     if (color == Color.gray) return "gray"; 
/* 741 */     if (color == Color.green) return "green"; 
/* 742 */     if (color == Color.lightGray) return "lightGray"; 
/* 743 */     if (color == Color.magenta) return "magenta"; 
/* 744 */     if (color == Color.orange) return "orange"; 
/* 745 */     if (color == Color.pink) return "pink"; 
/* 746 */     if (color == Color.red) return "red"; 
/* 747 */     if (color == Color.white) return "white"; 
/* 748 */     if (color == Color.yellow) return "yellow"; 
/* 749 */     return "0x" + Integer.toString(color.getRGB(), 16).toUpperCase();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paintObject(Graphics g) {
/* 759 */     if (!isVisible())
/* 760 */       return;  Color oldColor = g.getColor();
/* 761 */     if (this.color != null) g.setColor(this.color); 
/* 762 */     paint(g);
/* 763 */     if (this.color != null) g.setColor(oldColor);
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 773 */   protected void setParent(GContainer parent) { this.parent = parent; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Component getComponent() {
/* 786 */     GContainer parent = getParent();
/* 787 */     while (parent instanceof GObject) {
/* 788 */       parent = ((GObject)parent).getParent();
/*     */     }
/* 790 */     return (Component)parent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void repaint() {
/* 799 */     GContainer parent = getParent();
/* 800 */     while (parent instanceof GObject) {
/* 801 */       parent = ((GObject)parent).getParent();
/*     */     }
/* 803 */     if (parent instanceof GCanvas)
/* 804 */       ((GCanvas)parent).conditionalRepaint(); 
/*     */   }
/*     */ }


/* Location:              /root/karel.jar!/acm/graphics/GObject.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */