/*     */ package acm.graphics;
/*     */ 
/*     */ import acm.util.Platform;
/*     */ import java.awt.Color;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Rectangle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GOval
/*     */   extends GObject
/*     */   implements GFillable, GResizable, GScalable
/*     */ {
/*     */   private boolean useArcs;
/*     */   private double width;
/*     */   private double height;
/*     */   private boolean fill;
/*     */   private Color fillColor;
/*     */   
/*  33 */   public GOval(double width, double height) { this(0.0D, 0.0D, width, height); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GOval(double x, double y, double width, double height) {
/*  47 */     this.useArcs = checkForArcRendering();
/*  48 */     this.width = width;
/*  49 */     this.height = height;
/*  50 */     setLocation(x, y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(double x, double y) {
/*  64 */     double rx = this.width / 2.0D;
/*  65 */     double ry = this.height / 2.0D;
/*  66 */     if (rx == 0.0D || ry == 0.0D) return false; 
/*  67 */     double dx = x - getX() + rx;
/*  68 */     double dy = y - getY() + ry;
/*  69 */     return (dx * dx / rx * rx + dy * dy / ry * ry <= 1.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void paint(Graphics g) {
/*  79 */     Rectangle r = getAWTBounds();
/*  80 */     if (this.useArcs) {
/*  81 */       if (isFilled()) {
/*  82 */         g.setColor(getFillColor());
/*  83 */         g.fillArc(r.x, r.y, r.width, r.height, 0, 360);
/*  84 */         g.setColor(getColor());
/*     */       } 
/*  86 */       g.drawArc(r.x, r.y, r.width, r.height, 0, 360);
/*     */     } else {
/*  88 */       if (isFilled()) {
/*  89 */         g.setColor(getFillColor());
/*  90 */         g.fillOval(r.x, r.y, r.width, r.height);
/*  91 */         g.setColor(getColor());
/*     */       } 
/*  93 */       g.drawOval(r.x, r.y, r.width, r.height);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFilled(boolean fill) {
/* 105 */     this.fill = fill;
/* 106 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 117 */   public boolean isFilled() { return this.fill; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFillColor(Color c) {
/* 128 */     this.fillColor = c;
/* 129 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 142 */   public Color getFillColor() { return (this.fillColor == null) ? getColor() : this.fillColor; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSize(double width, double height) {
/* 154 */     this.width = width;
/* 155 */     this.height = height;
/* 156 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 168 */   public final void setSize(GDimension size) { setSize(size.getWidth(), size.getHeight()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 179 */   public GDimension getSize() { return new GDimension(this.width, this.height); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBounds(double x, double y, double width, double height) {
/* 193 */     this.width = width;
/* 194 */     this.height = height;
/* 195 */     setLocation(x, y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 207 */   public final void setBounds(GRectangle bounds) { setBounds(bounds.getX(), bounds.getY(), bounds.getWidth(), bounds.getHeight()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 218 */   public GRectangle getBounds() { return new GRectangle(getX(), getY(), this.width + 1.0D, this.height + 1.0D); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 230 */   public double getWidth() { return this.width; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 242 */   public double getHeight() { return this.height; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void scale(double sx, double sy) {
/* 254 */     this.width *= sx;
/* 255 */     this.height *= sy;
/* 256 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 268 */   public final void scale(double sf) { scale(sf, sf); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 423 */   protected Rectangle getAWTBounds() { return new Rectangle(GObject.round(getX()), GObject.round(getY()), GObject.round(this.width), GObject.round(this.height)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 434 */   private boolean checkForArcRendering() { return Platform.isMac(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 452 */   public static void test() { (new GOvalTest()).main(); }
/*     */ }


/* Location:              /root/karel.jar!/acm/graphics/GOval.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */