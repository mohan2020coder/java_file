/*     */ package acm.graphics;
/*     */ 
/*     */ import acm.util.ErrorException;
/*     */ import acm.util.MediaTools;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Image;
/*     */ import java.awt.Rectangle;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GPen
/*     */   extends GObject
/*     */ {
/*     */   private static final double SLOW_DELAY = 200.0D;
/*     */   private static final double FAST_DELAY = 0.0D;
/*     */   
/*     */   public GPen() {
/*  37 */     this.speed = 1.0D;
/*  38 */     this.penVisible = false;
/*  39 */     this.path = new Vector();
/*  40 */     erasePath();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GPen(double x, double y) {
/*  53 */     this();
/*  54 */     setLocation(x, y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void erasePath() {
/*  64 */     this.path = new Vector();
/*  65 */     this.sx = 1.0D;
/*  66 */     this.sy = 1.0D;
/*  67 */     this.regionOpen = false;
/*  68 */     this.regionStarted = false;
/*  69 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLocation(double x, double y) {
/*  81 */     if (this.regionStarted) {
/*  82 */       throw new ErrorException("It is illegal to move the pen while you are defining a filled region.");
/*     */     }
/*     */     
/*  85 */     super.setLocation(x, y);
/*  86 */     delay();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void drawLine(double dx, double dy) {
/* 101 */     double x = getX();
/* 102 */     double y = getY();
/* 103 */     synchronized (this.path) {
/* 104 */       if (!this.regionStarted) {
/* 105 */         this.path.addElement(new SetLocationElement(x, y));
/* 106 */         this.regionStarted = this.regionOpen;
/*     */       } 
/* 108 */       this.path.addElement(new DrawLineElement(dx, dy));
/*     */     } 
/* 110 */     super.setLocation(x + dx, y + dy);
/* 111 */     delay();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void drawPolarLine(double r, double theta) {
/* 136 */     double radians = theta * Math.PI / 180.0D;
/* 137 */     drawLine(r * Math.cos(radians), -r * Math.sin(radians));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setColor(Color color) {
/* 148 */     if (this.regionStarted) {
/* 149 */       throw new ErrorException("It is illegal to change the color while you are defining a filled region.");
/*     */     }
/*     */     
/* 152 */     synchronized (this.path) {
/* 153 */       this.path.addElement(new SetColorElement(color));
/*     */     } 
/* 155 */     super.setColor(color);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFillColor(Color color) {
/* 166 */     if (this.regionStarted) {
/* 167 */       throw new ErrorException("It is illegal to change the fill color while you are defining a filled region.");
/*     */     }
/*     */     
/* 170 */     this.fillColor = color;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 183 */   public Color getFillColor() { return (this.fillColor == null) ? getColor() : this.fillColor; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startFilledRegion() {
/* 196 */     if (this.regionOpen) {
/* 197 */       throw new ErrorException("You are already filling a region.");
/*     */     }
/* 199 */     this.regionOpen = true;
/* 200 */     this.regionStarted = false;
/* 201 */     synchronized (this.path) {
/* 202 */       this.path.addElement(new StartRegionElement(this.fillColor));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void endFilledRegion() {
/* 213 */     if (!this.regionOpen) {
/* 214 */       throw new ErrorException("You need to call startFilledRegion before you call endFilledRegion.");
/*     */     }
/*     */     
/* 217 */     this.regionOpen = false;
/* 218 */     this.regionStarted = false;
/* 219 */     synchronized (this.path) {
/* 220 */       this.path.addElement(new EndRegionElement());
/*     */     } 
/* 222 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPenVisible(boolean visible) {
/* 234 */     this.penVisible = visible;
/* 235 */     repaint();
/* 236 */     delay();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 247 */   public boolean isPenVisible() { return this.penVisible; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 260 */   public void setSpeed(double speed) { this.speed = speed; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 271 */   public double getSpeed() { return this.speed; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void scale(double sx, double sy) {
/* 286 */     this.sx = sx;
/* 287 */     this.sy = sy;
/* 288 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void paint(Graphics g) {
/* 298 */     PathState state = new PathState();
/* 299 */     state.sx = this.sx;
/* 300 */     state.sy = this.sy;
/* 301 */     synchronized (this.path) {
/* 302 */       for (Enumeration e = this.path.elements(); e.hasMoreElements(); ) {
/* 303 */         PathElement element = (PathElement)e.nextElement();
/* 304 */         element.paint(g, state);
/*     */       } 
/*     */     } 
/* 307 */     finalElement.paint(g, state);
/* 308 */     if (this.penVisible) drawPen(g);
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GRectangle getBounds() {
/* 319 */     PathState state = new PathState();
/* 320 */     GRectangle bounds = new GRectangle(-1.0D, -1.0D, -1.0D, -1.0D);
/* 321 */     state.sx = this.sx;
/* 322 */     state.sy = this.sy;
/* 323 */     synchronized (this.path) {
/* 324 */       for (Enumeration e = this.path.elements(); e.hasMoreElements(); ) {
/* 325 */         PathElement element = (PathElement)e.nextElement();
/* 326 */         element.updateBounds(bounds, state);
/*     */       } 
/*     */     } 
/* 329 */     return bounds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 340 */   public boolean contains(double x, double y) { return false; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 352 */   public void setPenImage(Image image) { this.penImage = MediaTools.loadImage(image); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Image getPenImage() {
/* 361 */     if (this.penImage == null) this.penImage = PenImage.getImage(); 
/* 362 */     return this.penImage;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void drawPen(Graphics g) {
/* 473 */     Component comp = getComponent();
/* 474 */     if (comp == null)
/* 475 */       return;  if (this.penImage == null) this.penImage = PenImage.getImage(); 
/* 476 */     int width = this.penImage.getWidth(comp);
/* 477 */     int height = this.penImage.getHeight(comp);
/* 478 */     int x = (int)Math.round(getX());
/* 479 */     int y = (int)Math.round(getY());
/* 480 */     g.drawImage(this.penImage, x - width / 2, y - height / 2, comp);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Rectangle getPenBounds() {
/* 490 */     Component comp = getComponent();
/* 491 */     if (comp == null) return new Rectangle(); 
/* 492 */     if (this.penImage == null) this.penImage = PenImage.getImage(); 
/* 493 */     int width = this.penImage.getWidth(comp);
/* 494 */     int height = this.penImage.getHeight(comp);
/* 495 */     int x = (int)Math.round(getX());
/* 496 */     int y = (int)Math.round(getY());
/* 497 */     return new Rectangle(x - width / 2, y - height / 2, width, height);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Rectangle getAWTRectangle(double x, double y, double dx, double dy) {
/* 505 */     return new Rectangle((int)Math.min(x, x + dx), (int)Math.min(y, y + dy), 
/* 506 */         (int)Math.abs(dx), (int)Math.abs(dy));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void delay() {
/* 514 */     double delay = 200.0D + Math.sqrt(this.speed) * -200.0D;
/* 515 */     if (this.speed < 0.97D) GObject.pause(delay);
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 523 */   private static PathElement finalElement = new FinalPathElement();
/*     */   private double sx;
/*     */   private double sy;
/*     */   private double speed;
/*     */   private boolean regionOpen;
/*     */   private boolean regionStarted;
/*     */   private boolean penVisible;
/*     */   private Vector path;
/*     */   private Image penImage;
/*     */   private Color fillColor;
/*     */ }


/* Location:              /root/karel.jar!/acm/graphics/GPen.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */