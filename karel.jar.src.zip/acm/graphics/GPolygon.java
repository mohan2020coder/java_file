/*     */ package acm.graphics;
/*     */ 
/*     */ import acm.util.ErrorException;
/*     */ import java.awt.Color;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Polygon;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GPolygon
/*     */   extends GObject
/*     */   implements GFillable, GScalable
/*     */ {
/*     */   private static final double EPSILON = 1.0E-5D;
/*     */   private double cx;
/*     */   private double cy;
/*     */   private double sx;
/*     */   private double sy;
/*     */   private double rotation;
/*     */   private Vector vertexList;
/*     */   private boolean cacheValid;
/*     */   private boolean complete;
/*     */   private Polygon poly;
/*     */   private Object lock;
/*     */   private boolean fill;
/*     */   private Color fillColor;
/*     */   
/*  30 */   public GPolygon() { this(0.0D, 0.0D); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GPolygon(double x, double y) {
/*  42 */     clear();
/*  43 */     this.lock = new Object();
/*  44 */     setLocation(x, y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GPolygon(GPoint[] points) {
/*  56 */     clear();
/*  57 */     synchronized (this.lock) {
/*  58 */       for (int i = 0; i < points.length; i++) {
/*  59 */         this.vertexList.addElement(new GPoint(points[i].getX(), points[i].getY()));
/*     */       }
/*     */     } 
/*  62 */     markAsComplete();
/*  63 */     this.rotation = 0.0D;
/*  64 */     this.sx = 1.0D;
/*  65 */     this.sy = 1.0D;
/*  66 */     this.lock = new Object();
/*  67 */     setLocation(0.0D, 0.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addVertex(double x, double y) {
/*  79 */     if (this.complete) {
/*  80 */       throw new ErrorException("You can't add vertices to a GPolygon that has been marked as complete.");
/*     */     }
/*     */     
/*  83 */     synchronized (this.lock) {
/*  84 */       this.vertexList.addElement(new GPoint(x, y));
/*  85 */       this.cx = x;
/*  86 */       this.cy = y;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addEdge(double dx, double dy) {
/* 100 */     if (this.complete) {
/* 101 */       throw new ErrorException("You can't add edges to a GPolygon that has been marked as complete.");
/*     */     }
/*     */     
/* 104 */     synchronized (this.lock) {
/* 105 */       this.cx += dx;
/* 106 */       this.cy += dy;
/* 107 */       this.vertexList.addElement(new GPoint(this.cx, this.cy));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void addPolarEdge(double r, double theta) {
/* 122 */     if (this.complete) {
/* 123 */       throw new ErrorException("You can't add edges to a GPolygon that has been marked as complete.");
/*     */     }
/*     */     
/* 126 */     synchronized (this.lock) {
/* 127 */       this.cx += r * GObject.cosD(theta);
/* 128 */       this.cy -= r * GObject.sinD(theta);
/* 129 */       this.vertexList.addElement(new GPoint(this.cx, this.cy));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void scale(double sx, double sy) {
/* 142 */     this.sx *= sx;
/* 143 */     this.sy *= sy;
/* 144 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 156 */   public final void scale(double sf) { scale(sf, sf); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void rotate(double theta) {
/* 167 */     this.rotation += theta;
/* 168 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFilled(boolean fill) {
/* 179 */     this.fill = fill;
/* 180 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 191 */   public boolean isFilled() { return this.fill; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFillColor(Color c) {
/* 202 */     this.fillColor = c;
/* 203 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 216 */   public Color getFillColor() { return (this.fillColor == null) ? getColor() : this.fillColor; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GRectangle getBounds() {
/* 228 */     int nPoints = this.vertexList.size();
/* 229 */     if (nPoints == 0) return new GRectangle(); 
/* 230 */     double xMin = 0.0D;
/* 231 */     double xMax = 0.0D;
/* 232 */     double yMin = 0.0D;
/* 233 */     double yMax = 0.0D;
/* 234 */     synchronized (this.lock) {
/* 235 */       double x0 = getX();
/* 236 */       double y0 = getY();
/* 237 */       GPoint last = new GPoint(0.0D, 0.0D);
/* 238 */       double sinTheta = GObject.sinD(this.rotation);
/* 239 */       double cosTheta = GObject.cosD(this.rotation);
/* 240 */       boolean first = true;
/* 241 */       for (Enumeration e = this.vertexList.elements(); e.hasMoreElements(); ) {
/* 242 */         GPoint vertex = (GPoint)e.nextElement();
/* 243 */         double x = x0 + this.sx * (cosTheta * vertex.getX() - sinTheta * vertex.getY());
/* 244 */         double y = y0 + this.sy * (sinTheta * vertex.getX() + cosTheta * vertex.getY());
/* 245 */         if (first) {
/* 246 */           xMin = x;
/* 247 */           xMax = x;
/* 248 */           yMin = y;
/* 249 */           yMax = y;
/* 250 */           first = false;
/*     */         } else {
/* 252 */           xMin = Math.min(xMin, x);
/* 253 */           xMax = Math.max(xMax, x);
/* 254 */           yMin = Math.min(yMin, y);
/* 255 */           yMax = Math.max(yMax, y);
/*     */         } 
/* 257 */         last = vertex;
/*     */       } 
/*     */     } 
/* 260 */     return new GRectangle(xMin, yMin, xMax - xMin, yMax - yMin);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 274 */   public boolean contains(double x, double y) { return getPolygon().contains(GObject.round(x), GObject.round(y)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void paint(Graphics g) {
/* 284 */     if (this.vertexList.size() == 0)
/* 285 */       return;  Polygon p = getPolygon();
/* 286 */     if (isFilled()) {
/* 287 */       g.setColor(getFillColor());
/* 288 */       g.fillPolygon(p.xpoints, p.ypoints, p.npoints);
/* 289 */       g.setColor(getColor());
/*     */     } 
/* 291 */     g.drawPolygon(p.xpoints, p.ypoints, p.npoints);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void recenter() {
/* 304 */     double xMin = 0.0D;
/* 305 */     double xMax = 0.0D;
/* 306 */     double yMin = 0.0D;
/* 307 */     double yMax = 0.0D;
/* 308 */     boolean first = true;
/* 309 */     for (Enumeration e = this.vertexList.elements(); e.hasMoreElements(); ) {
/* 310 */       GPoint vertex = (GPoint)e.nextElement();
/* 311 */       if (first) {
/* 312 */         xMin = vertex.getX();
/* 313 */         xMax = vertex.getX();
/* 314 */         yMin = vertex.getY();
/* 315 */         yMax = vertex.getY();
/* 316 */         first = false; continue;
/*     */       } 
/* 318 */       xMin = Math.min(xMin, vertex.getX());
/* 319 */       xMax = Math.max(xMax, vertex.getX());
/* 320 */       yMin = Math.min(yMin, vertex.getY());
/* 321 */       yMax = Math.max(yMax, vertex.getX());
/*     */     } 
/*     */     
/* 324 */     double xc = (xMin + xMax) / 2.0D;
/* 325 */     double yc = (yMin + yMax) / 2.0D;
/* 326 */     for (Enumeration e = this.vertexList.elements(); e.hasMoreElements(); ) {
/* 327 */       GPoint vertex = (GPoint)e.nextElement();
/* 328 */       vertex.translate(-xc, -yc);
/*     */     } 
/* 330 */     this.cacheValid = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object clone() {
/*     */     try {
/* 341 */       Object clone = super.clone();
/* 342 */       ((GPolygon)clone).copyVertexList();
/* 343 */       return clone;
/* 344 */     } catch (Exception CloneNotSupportedException) {
/* 345 */       throw new ErrorException("Impossible exception");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void repaint() {
/* 496 */     this.cacheValid = false;
/* 497 */     super.repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Polygon getPolygon() {
/* 509 */     if (this.cacheValid) return this.poly; 
/* 510 */     synchronized (this.lock) {
/* 511 */       double x0 = getX();
/* 512 */       double y0 = getY();
/* 513 */       GPoint last = new GPoint(0.0D, 0.0D);
/* 514 */       double sinTheta = GObject.sinD(this.rotation);
/* 515 */       double cosTheta = GObject.cosD(this.rotation);
/* 516 */       this.poly = new Polygon();
/* 517 */       for (Enumeration e = this.vertexList.elements(); e.hasMoreElements(); ) {
/* 518 */         GPoint vertex = (GPoint)e.nextElement();
/* 519 */         double x = x0 + this.sx * (cosTheta * vertex.getX() - sinTheta * vertex.getY());
/* 520 */         double y = y0 + this.sy * (sinTheta * vertex.getX() + cosTheta * vertex.getY());
/* 521 */         this.poly.addPoint(GObject.round(x), GObject.round(y));
/* 522 */         last = vertex;
/*     */       } 
/* 524 */       this.cacheValid = true;
/* 525 */       return this.poly;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 536 */   protected void markAsComplete() { this.complete = true; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void clear() {
/* 546 */     if (this.complete) {
/* 547 */       throw new ErrorException("You can't clear a GPolygon that has been marked as complete.");
/*     */     }
/*     */     
/* 550 */     this.vertexList = new Vector();
/* 551 */     this.cx = 0.0D;
/* 552 */     this.cy = 0.0D;
/* 553 */     this.rotation = 0.0D;
/* 554 */     this.sx = 1.0D;
/* 555 */     this.sy = 1.0D;
/* 556 */     this.cacheValid = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void copyVertexList() {
/* 565 */     Vector newList = new Vector();
/* 566 */     for (int i = 0; i < this.vertexList.size(); i++) {
/* 567 */       newList.addElement(this.vertexList.elementAt(i));
/*     */     }
/* 569 */     this.vertexList = newList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 593 */   public static void test() { (new GPolygonTest()).main(); }
/*     */ }


/* Location:              /root/karel.jar!/acm/graphics/GPolygon.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */