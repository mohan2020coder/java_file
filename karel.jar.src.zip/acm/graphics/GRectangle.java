/*     */ package acm.graphics;
/*     */ 
/*     */ import java.awt.Rectangle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GRectangle
/*     */ {
/*     */   private double x;
/*     */   private double y;
/*     */   private double width;
/*     */   private double height;
/*     */   
/*  26 */   public GRectangle() { this(0.0D, 0.0D, 0.0D, 0.0D); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GRectangle(double x, double y, double width, double height) {
/*  40 */     this.x = x;
/*  41 */     this.y = y;
/*  42 */     this.width = width;
/*  43 */     this.height = height;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  55 */   public GRectangle(double width, double height) { this(0.0D, 0.0D, width, height); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  67 */   public GRectangle(GPoint pt, GDimension size) { this(pt.getX(), pt.getY(), size.getWidth(), size.getHeight()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   public GRectangle(GPoint pt) { this(pt.getX(), pt.getY(), 0.0D, 0.0D); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  89 */   public GRectangle(GDimension size) { this(0.0D, 0.0D, size.getWidth(), size.getHeight()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 100 */   public GRectangle(GRectangle r) { this(r.x, r.y, r.width, r.height); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 111 */   public double getX() { return this.x; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 122 */   public double getY() { return this.y; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 133 */   public double getWidth() { return this.width; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 144 */   public double getHeight() { return this.height; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBounds(double x, double y, double width, double height) {
/* 158 */     this.x = x;
/* 159 */     this.y = y;
/* 160 */     this.width = width;
/* 161 */     this.height = height;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 173 */   public void setBounds(GPoint pt, GDimension size) { setBounds(pt.getX(), pt.getY(), size.getWidth(), size.getHeight()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 184 */   public void setBounds(GRectangle bounds) { setBounds(bounds.x, bounds.y, bounds.width, bounds.height); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 195 */   public GRectangle getBounds() { return new GRectangle(this); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLocation(double x, double y) {
/* 208 */     this.x = x;
/* 209 */     this.y = y;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 220 */   public void setLocation(GPoint pt) { setLocation(pt.getX(), pt.getY()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 231 */   public GPoint getLocation() { return new GPoint(this.x, this.y); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void translate(double dx, double dy) {
/* 244 */     this.x += dx;
/* 245 */     this.y += dy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSize(double width, double height) {
/* 257 */     this.width = width;
/* 258 */     this.height = height;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 269 */   public void setSize(GDimension size) { setSize(size.getWidth(), size.getHeight()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 279 */   public GDimension getSize() { return new GDimension(this.width, this.height); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void grow(double dx, double dy) {
/* 292 */     this.x -= dx;
/* 293 */     this.y -= dy;
/* 294 */     this.width += 2.0D * dx;
/* 295 */     this.height += 2.0D * dy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 306 */   public boolean isEmpty() { return !(this.width > 0.0D && this.height > 0.0D); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 320 */   public boolean contains(double x, double y) { return (x >= this.x && y >= this.y && x < this.x + this.width && y < this.y + this.height); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 333 */   public boolean contains(GPoint pt) { return contains(pt.getX(), pt.getY()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean intersects(GRectangle r) {
/* 346 */     if (this.x > r.x + r.width) return false; 
/* 347 */     if (this.y > r.y + r.height) return false; 
/* 348 */     if (r.x > this.x + this.width) return false; 
/* 349 */     if (r.y > this.y + this.height) return false; 
/* 350 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GRectangle intersection(GRectangle r) {
/* 363 */     double x1 = Math.max(this.x, r.x);
/* 364 */     double y1 = Math.max(this.y, r.y);
/* 365 */     double x2 = Math.min(this.x + this.width, r.x + r.width);
/* 366 */     double y2 = Math.min(this.y + this.height, r.y + r.height);
/* 367 */     return new GRectangle(x1, y1, x2 - x1, y2 - y1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GRectangle union(GRectangle r) {
/* 380 */     if (isEmpty()) return new GRectangle(r); 
/* 381 */     if (r.isEmpty()) return new GRectangle(this); 
/* 382 */     double x1 = Math.min(this.x, r.x);
/* 383 */     double y1 = Math.min(this.y, r.y);
/* 384 */     double x2 = Math.max(this.x + this.width, r.x + r.width);
/* 385 */     double y2 = Math.max(this.y + this.height, r.y + r.height);
/* 386 */     return new GRectangle(x1, y1, x2 - x1, y2 - y1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(GRectangle r) {
/* 398 */     if (r.isEmpty())
/* 399 */       return;  if (isEmpty()) {
/* 400 */       setBounds(r);
/*     */       return;
/*     */     } 
/* 403 */     double x2 = Math.max(this.x + this.width, r.x + r.width);
/* 404 */     double y2 = Math.max(this.y + this.height, r.y + r.height);
/* 405 */     this.x = Math.min(r.x, this.x);
/* 406 */     this.y = Math.min(r.y, this.y);
/* 407 */     this.width = x2 - this.x;
/* 408 */     this.height = y2 - this.y;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(double x, double y) {
/* 420 */     if (isEmpty()) {
/* 421 */       setBounds(x, y, 0.0D, 0.0D);
/*     */       return;
/*     */     } 
/* 424 */     double x2 = Math.max(x + this.width, x);
/* 425 */     double y2 = Math.max(y + this.height, y);
/* 426 */     this.x = Math.min(x, this.x);
/* 427 */     this.y = Math.min(y, this.y);
/* 428 */     this.width = x2 - this.x;
/* 429 */     this.height = y2 - this.y;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Rectangle toRectangle() {
/* 440 */     return new Rectangle((int)Math.round(this.x), (int)Math.round(this.y), 
/* 441 */         (int)Math.round(this.width), (int)Math.round(this.height));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 456 */     return (new Float((float)this.x)).hashCode() ^ (new Float((float)this.y)).hashCode() ^ (
/* 457 */       new Float((float)this.width)).hashCode() ^ (new Float((float)this.height)).hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 474 */     if (!(obj instanceof GRectangle)) return false; 
/* 475 */     GRectangle r = (GRectangle)obj;
/* 476 */     if ((float)this.x != (float)r.x) return false; 
/* 477 */     if ((float)this.y != (float)r.y) return false; 
/* 478 */     if ((float)this.width != (float)r.width) return false; 
/* 479 */     if ((float)this.height != (float)r.height) return false; 
/* 480 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 492 */     return "[" + (float)this.x + ", " + (float)this.y + ", " + 
/* 493 */       (float)this.width + "x" + (float)this.height + "]";
/*     */   }
/*     */ }


/* Location:              /root/karel.jar!/acm/graphics/GRectangle.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */