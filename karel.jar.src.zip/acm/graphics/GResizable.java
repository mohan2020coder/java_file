package acm.graphics;

public interface GResizable {
  void setSize(double paramDouble1, double paramDouble2);
  
  void setSize(GDimension paramGDimension);
  
  void setBounds(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);
  
  void setBounds(GRectangle paramGRectangle);
}


/* Location:              /root/karel.jar!/acm/graphics/GResizable.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */