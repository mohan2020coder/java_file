package acm.graphics;

public interface GScalable {
  void scale(double paramDouble1, double paramDouble2);
  
  void scale(double paramDouble);
}


/* Location:              /root/karel.jar!/acm/graphics/GScalable.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */