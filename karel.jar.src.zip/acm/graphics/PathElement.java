package acm.graphics;

import java.awt.Graphics;

abstract class PathElement {
  public void paint(Graphics g, PathState state) {}
  
  public void updateBounds(GRectangle bounds, PathState state) {}
}


/* Location:              /root/karel.jar!/acm/graphics/PathElement.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */