package acm.graphics;

import java.awt.Color;
import java.awt.Polygon;

class PathState {
  double cx;
  
  double cy;
  
  double sx;
  
  double sy;
  
  Polygon region;
  
  Color fillColor;
}


/* Location:              /root/karel.jar!/acm/graphics/PathState.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */