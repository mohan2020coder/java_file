/*      */ package acm.io;
/*      */ 
/*      */ import acm.util.ErrorException;
/*      */ import java.awt.Color;
/*      */ import java.awt.Component;
/*      */ import java.awt.PrintJob;
/*      */ import java.awt.event.KeyEvent;
/*      */ import java.awt.event.KeyListener;
/*      */ import java.io.BufferedReader;
/*      */ import java.io.IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ abstract class BufferedConsoleModel
/*      */   implements KeyListener, ConsoleModel
/*      */ {
/* 1237 */   private CharacterQueue buffer = new CharacterQueue();
/* 1238 */   private Object lock = new Object(); private BufferedReader inputScript;
/* 1239 */   private int base = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void print(String str, int style) {
/* 1249 */     synchronized (this.lock) {
/* 1250 */       int dot = getLength();
/* 1251 */       insert(str, dot, style);
/* 1252 */       this.base = getLength();
/* 1253 */       setCaretPosition(this.base);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String readLine() { // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield lock : Ljava/lang/Object;
/*      */     //   4: dup
/*      */     //   5: astore_1
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: aload_0
/*      */     //   9: invokevirtual getLength : ()I
/*      */     //   12: putfield base : I
/*      */     //   15: aload_0
/*      */     //   16: getfield inputScript : Ljava/io/BufferedReader;
/*      */     //   19: ifnull -> 95
/*      */     //   22: aconst_null
/*      */     //   23: astore_2
/*      */     //   24: aload_0
/*      */     //   25: getfield inputScript : Ljava/io/BufferedReader;
/*      */     //   28: invokevirtual readLine : ()Ljava/lang/String;
/*      */     //   31: astore_2
/*      */     //   32: goto -> 45
/*      */     //   35: astore_3
/*      */     //   36: new acm/util/ErrorException
/*      */     //   39: dup
/*      */     //   40: aload_3
/*      */     //   41: invokespecial <init> : (Ljava/lang/Exception;)V
/*      */     //   44: athrow
/*      */     //   45: aload_2
/*      */     //   46: ifnull -> 79
/*      */     //   49: aload_0
/*      */     //   50: aload_2
/*      */     //   51: aload_0
/*      */     //   52: getfield base : I
/*      */     //   55: iconst_1
/*      */     //   56: invokevirtual insert : (Ljava/lang/String;II)V
/*      */     //   59: aload_0
/*      */     //   60: ldc '\\n'
/*      */     //   62: aload_0
/*      */     //   63: getfield base : I
/*      */     //   66: aload_2
/*      */     //   67: invokevirtual length : ()I
/*      */     //   70: iadd
/*      */     //   71: iconst_0
/*      */     //   72: invokevirtual insert : (Ljava/lang/String;II)V
/*      */     //   75: aload_2
/*      */     //   76: aload_1
/*      */     //   77: monitorexit
/*      */     //   78: areturn
/*      */     //   79: aload_0
/*      */     //   80: getfield inputScript : Ljava/io/BufferedReader;
/*      */     //   83: invokevirtual close : ()V
/*      */     //   86: goto -> 90
/*      */     //   89: astore_3
/*      */     //   90: aload_0
/*      */     //   91: aconst_null
/*      */     //   92: putfield inputScript : Ljava/io/BufferedReader;
/*      */     //   95: aload_0
/*      */     //   96: aload_0
/*      */     //   97: getfield base : I
/*      */     //   100: invokevirtual setCaretPosition : (I)V
/*      */     //   103: goto -> 297
/*      */     //   106: aload_0
/*      */     //   107: invokevirtual getCaretPosition : ()I
/*      */     //   110: aload_0
/*      */     //   111: getfield base : I
/*      */     //   114: if_icmpge -> 125
/*      */     //   117: aload_0
/*      */     //   118: aload_0
/*      */     //   119: invokevirtual getLength : ()I
/*      */     //   122: invokevirtual setCaretPosition : (I)V
/*      */     //   125: iload_3
/*      */     //   126: lookupswitch default -> 245, 2 -> 211, 6 -> 228, 8 -> 168, 127 -> 168
/*      */     //   168: aload_0
/*      */     //   169: invokevirtual getSelectionStart : ()I
/*      */     //   172: istore_2
/*      */     //   173: iload_2
/*      */     //   174: aload_0
/*      */     //   175: invokevirtual getSelectionEnd : ()I
/*      */     //   178: if_icmpne -> 203
/*      */     //   181: iload_2
/*      */     //   182: aload_0
/*      */     //   183: getfield base : I
/*      */     //   186: if_icmple -> 286
/*      */     //   189: aload_0
/*      */     //   190: iload_2
/*      */     //   191: iconst_1
/*      */     //   192: isub
/*      */     //   193: iconst_1
/*      */     //   194: invokevirtual delete : (II)V
/*      */     //   197: iinc #2, -1
/*      */     //   200: goto -> 286
/*      */     //   203: aload_0
/*      */     //   204: invokevirtual deleteSelection : ()I
/*      */     //   207: istore_2
/*      */     //   208: goto -> 286
/*      */     //   211: aload_0
/*      */     //   212: invokevirtual getSelectionStart : ()I
/*      */     //   215: iconst_1
/*      */     //   216: isub
/*      */     //   217: aload_0
/*      */     //   218: getfield base : I
/*      */     //   221: invokestatic max : (II)I
/*      */     //   224: istore_2
/*      */     //   225: goto -> 286
/*      */     //   228: aload_0
/*      */     //   229: invokevirtual getSelectionEnd : ()I
/*      */     //   232: iconst_1
/*      */     //   233: iadd
/*      */     //   234: aload_0
/*      */     //   235: invokevirtual getLength : ()I
/*      */     //   238: invokestatic min : (II)I
/*      */     //   241: istore_2
/*      */     //   242: goto -> 286
/*      */     //   245: aload_0
/*      */     //   246: invokevirtual getSelectionStart : ()I
/*      */     //   249: istore_2
/*      */     //   250: iload_2
/*      */     //   251: aload_0
/*      */     //   252: invokevirtual getSelectionEnd : ()I
/*      */     //   255: if_icmpeq -> 263
/*      */     //   258: aload_0
/*      */     //   259: invokevirtual deleteSelection : ()I
/*      */     //   262: istore_2
/*      */     //   263: aload_0
/*      */     //   264: new java/lang/StringBuffer
/*      */     //   267: dup
/*      */     //   268: invokespecial <init> : ()V
/*      */     //   271: iload_3
/*      */     //   272: invokevirtual append : (C)Ljava/lang/StringBuffer;
/*      */     //   275: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   278: iload_2
/*      */     //   279: iconst_1
/*      */     //   280: invokevirtual insert : (Ljava/lang/String;II)V
/*      */     //   283: iinc #2, 1
/*      */     //   286: aload_0
/*      */     //   287: iload_2
/*      */     //   288: iload_2
/*      */     //   289: invokevirtual select : (II)V
/*      */     //   292: aload_0
/*      */     //   293: iload_2
/*      */     //   294: invokevirtual setCaretPosition : (I)V
/*      */     //   297: aload_0
/*      */     //   298: getfield buffer : Lacm/io/CharacterQueue;
/*      */     //   301: invokevirtual dequeue : ()C
/*      */     //   304: dup
/*      */     //   305: istore_3
/*      */     //   306: bipush #10
/*      */     //   308: if_icmpeq -> 317
/*      */     //   311: iload_3
/*      */     //   312: bipush #13
/*      */     //   314: if_icmpne -> 106
/*      */     //   317: aload_0
/*      */     //   318: invokevirtual getLength : ()I
/*      */     //   321: aload_0
/*      */     //   322: getfield base : I
/*      */     //   325: isub
/*      */     //   326: istore #4
/*      */     //   328: aload_0
/*      */     //   329: ldc '\\n'
/*      */     //   331: aload_0
/*      */     //   332: getfield base : I
/*      */     //   335: iload #4
/*      */     //   337: iadd
/*      */     //   338: iconst_0
/*      */     //   339: invokevirtual insert : (Ljava/lang/String;II)V
/*      */     //   342: aload_0
/*      */     //   343: aload_0
/*      */     //   344: getfield base : I
/*      */     //   347: aload_0
/*      */     //   348: getfield base : I
/*      */     //   351: iload #4
/*      */     //   353: iadd
/*      */     //   354: invokevirtual getText : (II)Ljava/lang/String;
/*      */     //   357: aload_1
/*      */     //   358: monitorexit
/*      */     //   359: areturn
/*      */     //   360: aload_1
/*      */     //   361: monitorexit
/*      */     //   362: athrow
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #1262	-> 0
/*      */     //   #1263	-> 7
/*      */     //   #1264	-> 15
/*      */     //   #1265	-> 22
/*      */     //   #1267	-> 24
/*      */     //   #1268	-> 35
/*      */     //   #1269	-> 36
/*      */     //   #1271	-> 45
/*      */     //   #1272	-> 49
/*      */     //   #1273	-> 59
/*      */     //   #1274	-> 75
/*      */     //   #1277	-> 79
/*      */     //   #1278	-> 89
/*      */     //   #1281	-> 90
/*      */     //   #1285	-> 95
/*      */     //   #1286	-> 103
/*      */     //   #1287	-> 106
/*      */     //   #1288	-> 117
/*      */     //   #1290	-> 125
/*      */     //   #1292	-> 168
/*      */     //   #1293	-> 173
/*      */     //   #1294	-> 181
/*      */     //   #1295	-> 189
/*      */     //   #1296	-> 197
/*      */     //   #1299	-> 203
/*      */     //   #1301	-> 208
/*      */     //   #1303	-> 211
/*      */     //   #1304	-> 225
/*      */     //   #1306	-> 228
/*      */     //   #1307	-> 242
/*      */     //   #1309	-> 245
/*      */     //   #1310	-> 250
/*      */     //   #1311	-> 258
/*      */     //   #1313	-> 263
/*      */     //   #1314	-> 283
/*      */     //   #1316	-> 286
/*      */     //   #1317	-> 292
/*      */     //   #1286	-> 297
/*      */     //   #1319	-> 317
/*      */     //   #1320	-> 328
/*      */     //   #1321	-> 342
/*      */     //   #1262	-> 360
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	363	0	this	Lacm/io/BufferedConsoleModel;
/*      */     //   24	71	2	line	Ljava/lang/String;
/*      */     //   36	9	3	ex	Ljava/io/IOException;
/*      */     //   173	38	2	dot	I
/*      */     //   225	3	2	dot	I
/*      */     //   242	3	2	dot	I
/*      */     //   250	47	2	dot	I
/*      */     //   106	191	3	ch	C
/*      */     //   306	57	3	ch	C
/*      */     //   328	35	4	len	I
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	78	360	finally
/*      */     //   24	35	35	java/io/IOException
/*      */     //   79	89	89	java/io/IOException
/*      */     //   79	359	360	finally }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setInputScript(BufferedReader rd) {
/* 1331 */     this.inputScript = rd;
/* 1332 */     if (this.buffer.isWaiting()) {
/*      */       try {
/* 1334 */         String line = this.inputScript.readLine();
/* 1335 */         this.buffer.enqueue(String.valueOf(line) + "\n");
/* 1336 */       } catch (IOException ex) {
/* 1337 */         throw new ErrorException(ex);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1348 */   public BufferedReader getInputScript() { return this.inputScript; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int deleteSelection() {
/* 1356 */     int start = Math.max(this.base, getSelectionStart());
/* 1357 */     int end = getSelectionEnd();
/* 1358 */     if (end <= this.base) return getLength(); 
/* 1359 */     delete(start, end);
/* 1360 */     return start;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void clear();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract String getText();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract int getLength();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract Component getConsolePane();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract Component getTextPane();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void cut();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void copy();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void paste();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void selectAll();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void print(PrintJob paramPrintJob);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void setInputStyle(int paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void setInputColor(Color paramColor);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void setErrorStyle(int paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void setErrorColor(Color paramColor);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void keyTyped(KeyEvent e) {
/* 1463 */     this.buffer.enqueue(e.getKeyChar());
/* 1464 */     e.consume();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void keyPressed(KeyEvent e) {
/* 1473 */     switch (e.getKeyCode()) {
/*      */       case 37:
/* 1475 */         this.buffer.enqueue('\002');
/*      */         break;
/*      */       case 39:
/* 1478 */         this.buffer.enqueue('\006');
/*      */         break;
/*      */     } 
/* 1481 */     e.consume();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1490 */   public void keyReleased(KeyEvent e) { e.consume(); }
/*      */   
/*      */   protected abstract void insert(String paramString, int paramInt1, int paramInt2);
/*      */   
/*      */   protected abstract void delete(int paramInt1, int paramInt2);
/*      */   
/*      */   protected abstract void setCaretPosition(int paramInt);
/*      */   
/*      */   protected abstract int getCaretPosition();
/*      */   
/*      */   protected abstract void select(int paramInt1, int paramInt2);
/*      */   
/*      */   protected abstract int getSelectionStart();
/*      */   
/*      */   protected abstract int getSelectionEnd();
/*      */ }


/* Location:              /root/karel.jar!/acm/io/BufferedConsoleModel.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */