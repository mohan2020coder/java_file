/*     */ package acm.io;
/*     */ 
/*     */ import acm.util.AppletMenuBar;
/*     */ import acm.util.ErrorException;
/*     */ import acm.util.Platform;
/*     */ import java.awt.FileDialog;
/*     */ import java.awt.Frame;
/*     */ import java.awt.Menu;
/*     */ import java.awt.PrintJob;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConsoleMenuBar
/*     */   extends AppletMenuBar
/*     */ {
/*     */   private IOConsole console;
/*     */   
/*  32 */   public ConsoleMenuBar(IOConsole console) { this.console = console; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initMenus() {
/*  42 */     add(createFileMenu());
/*  43 */     add(createEditMenu());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Menu createFileMenu() {
/*  51 */     Menu menu = new Menu("File");
/*  52 */     setMnemonic(menu, 70);
/*  53 */     menu.add(createMenuItem("Save", 83));
/*  54 */     menu.add(createMenuItem("Save As..."));
/*  55 */     menu.addSeparator();
/*  56 */     menu.add(createMenuItem("Print", 80));
/*  57 */     menu.add(createMenuItem("Script..."));
/*  58 */     menu.addSeparator();
/*  59 */     addQuitItem(menu);
/*  60 */     return menu;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Menu createEditMenu() {
/*  69 */     Menu menu = new Menu("Edit");
/*  70 */     setMnemonic(menu, 69);
/*  71 */     addCutCopyPaste(menu);
/*  72 */     menu.add(createMenuItem("Select All", 65));
/*  73 */     return menu;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void menuAction(String cmd) {
/*  94 */     if (cmd.equals("Save")) {
/*  95 */       this.console.save();
/*  96 */     } else if (cmd.equals("Save As...")) {
/*  97 */       this.console.saveAs();
/*  98 */     } else if (cmd.equals("Print")) {
/*  99 */       Frame frame = Platform.getEnclosingFrame(this.console);
/* 100 */       if (frame == null)
/* 101 */         return;  PrintJob pj = this.console.getToolkit().getPrintJob(frame, "Console", null);
/* 102 */       if (pj == null)
/* 103 */         return;  this.console.print(pj);
/* 104 */       pj.end();
/* 105 */     } else if (cmd.equals("Script...")) {
/* 106 */       setInputScript();
/* 107 */     } else if (cmd.equals("Cut")) {
/* 108 */       this.console.cut();
/* 109 */     } else if (cmd.equals("Copy")) {
/* 110 */       this.console.copy();
/* 111 */     } else if (cmd.equals("Paste")) {
/* 112 */       this.console.paste();
/* 113 */     } else if (cmd.equals("Select All")) {
/* 114 */       this.console.selectAll();
/*     */     } else {
/* 116 */       super.menuAction(cmd);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setInputScript() {
/* 125 */     Frame frame = Platform.getEnclosingFrame(this.console);
/* 126 */     FileDialog dialog = new FileDialog(frame, "Input Script", 0);
/* 127 */     dialog.setDirectory(System.getProperty("user.dir"));
/* 128 */     dialog.setVisible(true);
/* 129 */     String dirname = dialog.getDirectory();
/* 130 */     String filename = dialog.getFile();
/* 131 */     if (filename != null)
/*     */       try {
/* 133 */         FileReader rd = new FileReader(new File(new File(dirname), filename));
/* 134 */         this.console.setInputScript(new BufferedReader(rd));
/* 135 */       } catch (IOException ex) {
/* 136 */         throw new ErrorException(ex);
/*     */       }  
/*     */   }
/*     */ }


/* Location:              /root/karel.jar!/acm/io/ConsoleMenuBar.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */