package acm.io;

import java.awt.Color;
import java.awt.Component;
import java.awt.PrintJob;
import java.io.BufferedReader;

interface ConsoleModel {
  public static final int OUTPUT_STYLE = 0;
  
  public static final int INPUT_STYLE = 1;
  
  public static final int ERROR_STYLE = 2;
  
  void print(String paramString, int paramInt);
  
  String readLine();
  
  void clear();
  
  String getText();
  
  String getText(int paramInt1, int paramInt2);
  
  int getLength();
  
  Component getConsolePane();
  
  Component getTextPane();
  
  void cut();
  
  void copy();
  
  void paste();
  
  void selectAll();
  
  void print(PrintJob paramPrintJob);
  
  void setInputStyle(int paramInt);
  
  void setInputColor(Color paramColor);
  
  void setErrorStyle(int paramInt);
  
  void setErrorColor(Color paramColor);
  
  void setInputScript(BufferedReader paramBufferedReader);
  
  BufferedReader getInputScript();
}


/* Location:              /root/karel.jar!/acm/io/ConsoleModel.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */