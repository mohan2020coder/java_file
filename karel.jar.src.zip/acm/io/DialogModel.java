package acm.io;

interface DialogModel {
  void popupMessage(String paramString);
  
  void popupErrorMessage(String paramString);
  
  String popupLineInputDialog(String paramString, boolean paramBoolean);
  
  Boolean popupBooleanInputDialog(String paramString1, String paramString2, String paramString3, boolean paramBoolean);
}


/* Location:              /root/karel.jar!/acm/io/DialogModel.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */