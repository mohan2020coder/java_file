/*     */ package acm.io;
/*     */ 
/*     */ import acm.util.ErrorException;
/*     */ import acm.util.Platform;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.FileDialog;
/*     */ import java.awt.Font;
/*     */ import java.awt.Frame;
/*     */ import java.awt.MenuBar;
/*     */ import java.awt.PrintJob;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.Writer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IOConsole
/*     */   extends Container
/*     */   implements IOModel
/*     */ {
/*  75 */   public static final IOConsole SYSTEM_CONSOLE = new SystemConsole();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IOConsole() {
/*  84 */     this.model = createConsoleModel();
/*  85 */     setLayout(new BorderLayout());
/*  86 */     this.consolePane = this.model.getConsolePane();
/*  87 */     this.textPane = this.model.getTextPane();
/*  88 */     if (this.consolePane != null) {
/*  89 */       this.textPane.addFocusListener(new ConsoleFocusListener(this));
/*  90 */       add("Center", this.consolePane);
/*     */     } 
/*  92 */     this.rd = new BufferedReader(new ConsoleReader(this.model));
/*  93 */     this.wr = new PrintWriter(new ConsoleWriter(this.model));
/*  94 */     this.exceptionOnError = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 104 */   public void clear() { this.model.clear(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 117 */   public void print(String value) { this.wr.print(value); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void print(boolean x) { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: new java/lang/StringBuffer
/*     */     //   4: dup
/*     */     //   5: invokespecial <init> : ()V
/*     */     //   8: iload_1
/*     */     //   9: invokevirtual append : (Z)Ljava/lang/StringBuffer;
/*     */     //   12: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   15: invokevirtual print : (Ljava/lang/String;)V
/*     */     //   18: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #125	-> 0
/*     */     //   #126	-> 18
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	19	0	this	Lacm/io/IOConsole;
/*     */     //   0	19	1	x	Z }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void print(char x) { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: new java/lang/StringBuffer
/*     */     //   4: dup
/*     */     //   5: invokespecial <init> : ()V
/*     */     //   8: iload_1
/*     */     //   9: invokevirtual append : (C)Ljava/lang/StringBuffer;
/*     */     //   12: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   15: invokevirtual print : (Ljava/lang/String;)V
/*     */     //   18: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #133	-> 0
/*     */     //   #134	-> 18
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	19	0	this	Lacm/io/IOConsole;
/*     */     //   0	19	1	x	C }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void print(double x) { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: new java/lang/StringBuffer
/*     */     //   4: dup
/*     */     //   5: invokespecial <init> : ()V
/*     */     //   8: dload_1
/*     */     //   9: invokevirtual append : (D)Ljava/lang/StringBuffer;
/*     */     //   12: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   15: invokevirtual print : (Ljava/lang/String;)V
/*     */     //   18: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #141	-> 0
/*     */     //   #142	-> 18
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	19	0	this	Lacm/io/IOConsole;
/*     */     //   0	19	1	x	D }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void print(float x) { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: new java/lang/StringBuffer
/*     */     //   4: dup
/*     */     //   5: invokespecial <init> : ()V
/*     */     //   8: fload_1
/*     */     //   9: invokevirtual append : (F)Ljava/lang/StringBuffer;
/*     */     //   12: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   15: invokevirtual print : (Ljava/lang/String;)V
/*     */     //   18: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #149	-> 0
/*     */     //   #150	-> 18
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	19	0	this	Lacm/io/IOConsole;
/*     */     //   0	19	1	x	F }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void print(int x) { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: new java/lang/StringBuffer
/*     */     //   4: dup
/*     */     //   5: invokespecial <init> : ()V
/*     */     //   8: iload_1
/*     */     //   9: invokevirtual append : (I)Ljava/lang/StringBuffer;
/*     */     //   12: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   15: invokevirtual print : (Ljava/lang/String;)V
/*     */     //   18: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #157	-> 0
/*     */     //   #158	-> 18
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	19	0	this	Lacm/io/IOConsole;
/*     */     //   0	19	1	x	I }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void print(long x) { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: new java/lang/StringBuffer
/*     */     //   4: dup
/*     */     //   5: invokespecial <init> : ()V
/*     */     //   8: lload_1
/*     */     //   9: invokevirtual append : (J)Ljava/lang/StringBuffer;
/*     */     //   12: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   15: invokevirtual print : (Ljava/lang/String;)V
/*     */     //   18: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #165	-> 0
/*     */     //   #166	-> 18
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	19	0	this	Lacm/io/IOConsole;
/*     */     //   0	19	1	x	J }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 173 */   public final void print(Object x) { print(x); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 183 */   public void println() { this.wr.println(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 196 */   public void println(String value) { this.wr.println(value); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void println(boolean x) { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: new java/lang/StringBuffer
/*     */     //   4: dup
/*     */     //   5: invokespecial <init> : ()V
/*     */     //   8: iload_1
/*     */     //   9: invokevirtual append : (Z)Ljava/lang/StringBuffer;
/*     */     //   12: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   15: invokevirtual println : (Ljava/lang/String;)V
/*     */     //   18: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #204	-> 0
/*     */     //   #205	-> 18
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	19	0	this	Lacm/io/IOConsole;
/*     */     //   0	19	1	x	Z }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void println(char x) { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: new java/lang/StringBuffer
/*     */     //   4: dup
/*     */     //   5: invokespecial <init> : ()V
/*     */     //   8: iload_1
/*     */     //   9: invokevirtual append : (C)Ljava/lang/StringBuffer;
/*     */     //   12: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   15: invokevirtual println : (Ljava/lang/String;)V
/*     */     //   18: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #212	-> 0
/*     */     //   #213	-> 18
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	19	0	this	Lacm/io/IOConsole;
/*     */     //   0	19	1	x	C }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void println(double x) { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: new java/lang/StringBuffer
/*     */     //   4: dup
/*     */     //   5: invokespecial <init> : ()V
/*     */     //   8: dload_1
/*     */     //   9: invokevirtual append : (D)Ljava/lang/StringBuffer;
/*     */     //   12: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   15: invokevirtual println : (Ljava/lang/String;)V
/*     */     //   18: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #220	-> 0
/*     */     //   #221	-> 18
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	19	0	this	Lacm/io/IOConsole;
/*     */     //   0	19	1	x	D }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void println(float x) { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: new java/lang/StringBuffer
/*     */     //   4: dup
/*     */     //   5: invokespecial <init> : ()V
/*     */     //   8: fload_1
/*     */     //   9: invokevirtual append : (F)Ljava/lang/StringBuffer;
/*     */     //   12: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   15: invokevirtual println : (Ljava/lang/String;)V
/*     */     //   18: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #228	-> 0
/*     */     //   #229	-> 18
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	19	0	this	Lacm/io/IOConsole;
/*     */     //   0	19	1	x	F }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void println(int x) { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: new java/lang/StringBuffer
/*     */     //   4: dup
/*     */     //   5: invokespecial <init> : ()V
/*     */     //   8: iload_1
/*     */     //   9: invokevirtual append : (I)Ljava/lang/StringBuffer;
/*     */     //   12: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   15: invokevirtual println : (Ljava/lang/String;)V
/*     */     //   18: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #236	-> 0
/*     */     //   #237	-> 18
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	19	0	this	Lacm/io/IOConsole;
/*     */     //   0	19	1	x	I }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void println(long x) { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: new java/lang/StringBuffer
/*     */     //   4: dup
/*     */     //   5: invokespecial <init> : ()V
/*     */     //   8: lload_1
/*     */     //   9: invokevirtual append : (J)Ljava/lang/StringBuffer;
/*     */     //   12: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   15: invokevirtual println : (Ljava/lang/String;)V
/*     */     //   18: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #244	-> 0
/*     */     //   #245	-> 18
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	19	0	this	Lacm/io/IOConsole;
/*     */     //   0	19	1	x	J }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 252 */   public final void println(Object x) { println(x); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 263 */   public void showErrorMessage(String msg) { this.model.print(String.valueOf(msg) + "\n", 2); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 275 */   public final String readLine() { return readLine(null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String readLine(String prompt) {
/* 289 */     if (prompt != null) print(prompt); 
/* 290 */     if (this.textPane != null) this.textPane.requestFocus(); 
/*     */     try {
/* 292 */       return this.rd.readLine();
/*     */     }
/* 294 */     catch (IOException ex) {
/* 295 */       throw new ErrorException(ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 311 */   public final int readInt() { return readInt(null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int readInt(String prompt) {
/*     */     while (true) {
/* 328 */       String line = readLine(prompt);
/*     */       try {
/* 330 */         return Integer.parseInt(line);
/* 331 */       } catch (NumberFormatException ex) {
/* 332 */         if (this.exceptionOnError) {
/* 333 */           throw new ErrorException("Illegal integer format");
/*     */         }
/* 335 */         showErrorMessage("Illegal integer format");
/* 336 */         if (prompt == null) prompt = "Retry: ";
/*     */       
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 353 */   public final double readDouble() { return readDouble(null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final double readDouble(String prompt) {
/*     */     while (true) {
/* 370 */       String line = readLine(prompt);
/*     */       try {
/* 372 */         return Double.valueOf(line).doubleValue();
/* 373 */       } catch (NumberFormatException ex) {
/* 374 */         if (this.exceptionOnError) {
/* 375 */           throw new ErrorException("Illegal numeric format");
/*     */         }
/* 377 */         showErrorMessage("Illegal numeric format");
/* 378 */         if (prompt == null) prompt = "Retry: ";
/*     */       
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 396 */   public final boolean readBoolean() { return readBoolean(null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 412 */   public final boolean readBoolean(String prompt) { return readBoolean(prompt, "true", "false"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean readBoolean(String prompt, String trueLabel, String falseLabel) {
/*     */     while (true) {
/* 432 */       String line = readLine(prompt);
/* 433 */       if (line == null)
/* 434 */         throw new ErrorException("End of file encountered"); 
/* 435 */       if (line.equalsIgnoreCase(trueLabel))
/* 436 */         return true; 
/* 437 */       if (line.equalsIgnoreCase(falseLabel)) {
/* 438 */         return false;
/*     */       }
/* 440 */       if (this.exceptionOnError) {
/* 441 */         throw new ErrorException("Illegal boolean format");
/*     */       }
/* 443 */       showErrorMessage("Illegal boolean format");
/* 444 */       if (prompt == null) prompt = "Retry: ";
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 458 */   public BufferedReader getReader() { return this.rd; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 470 */   public PrintWriter getWriter() { return this.wr; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 485 */   public void setExceptionOnError(boolean flag) { this.exceptionOnError = flag; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 497 */   public boolean getExceptionOnError() { return this.exceptionOnError; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInputStyle(int style) {
/* 511 */     this.inputStyle = style;
/* 512 */     this.model.setInputStyle(style);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 524 */   public int getInputStyle() { return this.inputStyle; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInputColor(Color color) {
/* 536 */     this.inputColor = color;
/* 537 */     this.model.setInputColor(color);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 549 */   public Color getInputColor() { return this.inputColor; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setErrorStyle(int style) {
/* 563 */     this.errorStyle = style;
/* 564 */     this.model.setErrorStyle(style);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 576 */   public int getErrorStyle() { return this.errorStyle; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setErrorColor(Color color) {
/* 588 */     this.errorColor = color;
/* 589 */     this.model.setErrorColor(color);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 601 */   public Color getErrorColor() { return this.errorColor; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MenuBar getMenuBar() {
/* 612 */     if (!this.menuBarInitialized) {
/* 613 */       this.menuBar = createMenuBar();
/* 614 */       this.menuBarInitialized = true;
/*     */     } 
/* 616 */     return this.menuBar;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFont(Font font) {
/* 627 */     if (this.textPane != null) this.textPane.setFont(font); 
/* 628 */     super.setFont(font);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setForeground(Color color) {
/* 639 */     if (this.textPane != null) this.textPane.setForeground(color); 
/* 640 */     super.setForeground(color);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 656 */   public void setInputScript(BufferedReader rd) { this.model.setInputScript(rd); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 668 */   public BufferedReader getInputScript() { return this.model.getInputScript(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 680 */   protected MenuBar createMenuBar() { return new ConsoleMenuBar(this); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void save(Writer wr) {
/*     */     try {
/* 693 */       wr.write(this.model.getText());
/* 694 */     } catch (IOException ex) {
/* 695 */       throw new ErrorException(ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 710 */   public void print(PrintJob pj) { this.model.print(pj); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ConsoleModel createConsoleModel() {
/* 722 */     if (Platform.isSwingAvailable()) {
/*     */       try {
/* 724 */         return (ConsoleModel)Class.forName("acm.io.SwingConsoleModel").newInstance();
/* 725 */       } catch (Exception ex) {
/* 726 */         return new AWTConsoleModel();
/*     */       } 
/*     */     }
/* 729 */     return new AWTConsoleModel();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 738 */   protected void cut() { this.model.cut(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 746 */   protected void copy() { this.model.copy(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 754 */   protected void paste() { this.model.paste(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 762 */   protected void selectAll() { this.model.selectAll(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void save() {
/* 770 */     Writer wr = null;
/* 771 */     while (wr == null) {
/*     */       try {
/* 773 */         if (this.file == null) {
/* 774 */           Frame frame = Platform.getEnclosingFrame(this);
/* 775 */           if (frame == null)
/* 776 */             return;  String dir = System.getProperty("user.dir");
/* 777 */           FileDialog dialog = new FileDialog(frame, "Save Console As", 1);
/* 778 */           dialog.setDirectory(dir);
/* 779 */           dialog.setVisible(true);
/* 780 */           String filename = dialog.getFile();
/* 781 */           if (filename == null)
/* 782 */             return;  this.file = new File(new File(dir), filename);
/*     */         } 
/* 784 */         wr = new FileWriter(this.file);
/* 785 */         save(wr);
/* 786 */         wr.close();
/* 787 */         Platform.setFileTypeAndCreator(this.file, "TEXT", "ttxt");
/* 788 */       } catch (IOException ex) {
/* 789 */         IODialog dialog = new IODialog(this);
/* 790 */         dialog.showErrorMessage(ex.getMessage());
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void saveAs() {
/* 800 */     this.file = null;
/* 801 */     save();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 813 */   protected Component getConsolePane() { return this.consolePane; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 825 */   protected Component getTextPane() { return this.textPane; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 832 */   protected static final Font DEFAULT_FONT = new Font("Monospaced", 0, 12);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 838 */   protected static final String LINE_SEPARATOR = System.getProperty("line.separator");
/*     */   
/*     */   private ConsoleModel model;
/*     */   
/*     */   private Component consolePane;
/*     */   
/*     */   private Component textPane;
/*     */   
/*     */   private boolean exceptionOnError;
/*     */   
/*     */   private BufferedReader rd;
/*     */   
/*     */   private PrintWriter wr;
/*     */   
/*     */   private MenuBar menuBar;
/*     */   
/*     */   private boolean menuBarInitialized;
/*     */   
/*     */   private File file;
/*     */   
/*     */   private Color inputColor;
/*     */   private int inputStyle;
/*     */   private Color errorColor;
/*     */   private int errorStyle;
/*     */   
/*     */   public static void test() {
/* 864 */     frame = new Frame("IOConsole Test");
/* 865 */     IOConsole console = new IOConsole();
/* 866 */     frame.setLayout(new BorderLayout());
/* 867 */     frame.add("Center", console);
/* 868 */     frame.setBounds(50, 50, 400, 170);
/* 869 */     frame.show();
/* 870 */     (new ConsoleTest()).test(console);
/*     */   }
/*     */ }


/* Location:              /root/karel.jar!/acm/io/IOConsole.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */