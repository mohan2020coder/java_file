/*     */ package acm.io;
/*     */ 
/*     */ import acm.util.CancelledException;
/*     */ import acm.util.ErrorException;
/*     */ import acm.util.Platform;
/*     */ import java.awt.Component;
/*     */ import java.lang.reflect.Constructor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IODialog
/*     */   implements IOModel
/*     */ {
/*     */   private boolean exceptionOnError;
/*     */   private boolean allowCancel;
/*     */   private DialogModel model;
/*     */   private Component owner;
/*     */   private IOConsole console;
/*     */   private String outputLine;
/*     */   
/*  73 */   public IODialog() { this(null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IODialog(Component owner) {
/*  85 */     this.owner = owner;
/*  86 */     this.model = createModel();
/*  87 */     this.outputLine = "";
/*  88 */     this.exceptionOnError = false;
/*  89 */     this.allowCancel = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 102 */   public void print(String value) { this.outputLine = String.valueOf(this.outputLine) + value; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void print(boolean x) { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: new java/lang/StringBuffer
/*     */     //   4: dup
/*     */     //   5: invokespecial <init> : ()V
/*     */     //   8: iload_1
/*     */     //   9: invokevirtual append : (Z)Ljava/lang/StringBuffer;
/*     */     //   12: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   15: invokevirtual print : (Ljava/lang/String;)V
/*     */     //   18: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #110	-> 0
/*     */     //   #111	-> 18
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	19	0	this	Lacm/io/IODialog;
/*     */     //   0	19	1	x	Z }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void print(char x) { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: new java/lang/StringBuffer
/*     */     //   4: dup
/*     */     //   5: invokespecial <init> : ()V
/*     */     //   8: iload_1
/*     */     //   9: invokevirtual append : (C)Ljava/lang/StringBuffer;
/*     */     //   12: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   15: invokevirtual print : (Ljava/lang/String;)V
/*     */     //   18: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #118	-> 0
/*     */     //   #119	-> 18
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	19	0	this	Lacm/io/IODialog;
/*     */     //   0	19	1	x	C }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void print(double x) { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: new java/lang/StringBuffer
/*     */     //   4: dup
/*     */     //   5: invokespecial <init> : ()V
/*     */     //   8: dload_1
/*     */     //   9: invokevirtual append : (D)Ljava/lang/StringBuffer;
/*     */     //   12: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   15: invokevirtual print : (Ljava/lang/String;)V
/*     */     //   18: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #126	-> 0
/*     */     //   #127	-> 18
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	19	0	this	Lacm/io/IODialog;
/*     */     //   0	19	1	x	D }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void print(float x) { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: new java/lang/StringBuffer
/*     */     //   4: dup
/*     */     //   5: invokespecial <init> : ()V
/*     */     //   8: fload_1
/*     */     //   9: invokevirtual append : (F)Ljava/lang/StringBuffer;
/*     */     //   12: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   15: invokevirtual print : (Ljava/lang/String;)V
/*     */     //   18: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #134	-> 0
/*     */     //   #135	-> 18
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	19	0	this	Lacm/io/IODialog;
/*     */     //   0	19	1	x	F }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void print(int x) { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: new java/lang/StringBuffer
/*     */     //   4: dup
/*     */     //   5: invokespecial <init> : ()V
/*     */     //   8: iload_1
/*     */     //   9: invokevirtual append : (I)Ljava/lang/StringBuffer;
/*     */     //   12: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   15: invokevirtual print : (Ljava/lang/String;)V
/*     */     //   18: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #142	-> 0
/*     */     //   #143	-> 18
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	19	0	this	Lacm/io/IODialog;
/*     */     //   0	19	1	x	I }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void print(long x) { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: new java/lang/StringBuffer
/*     */     //   4: dup
/*     */     //   5: invokespecial <init> : ()V
/*     */     //   8: lload_1
/*     */     //   9: invokevirtual append : (J)Ljava/lang/StringBuffer;
/*     */     //   12: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   15: invokevirtual print : (Ljava/lang/String;)V
/*     */     //   18: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #150	-> 0
/*     */     //   #151	-> 18
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	19	0	this	Lacm/io/IODialog;
/*     */     //   0	19	1	x	J }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 158 */   public final void print(Object x) { print(x); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void println() {
/* 168 */     this.model.popupMessage(this.outputLine);
/* 169 */     this.outputLine = "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void println(String value) {
/* 182 */     print(value);
/* 183 */     println();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void println(boolean x) { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: new java/lang/StringBuffer
/*     */     //   4: dup
/*     */     //   5: invokespecial <init> : ()V
/*     */     //   8: iload_1
/*     */     //   9: invokevirtual append : (Z)Ljava/lang/StringBuffer;
/*     */     //   12: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   15: invokevirtual println : (Ljava/lang/String;)V
/*     */     //   18: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #191	-> 0
/*     */     //   #192	-> 18
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	19	0	this	Lacm/io/IODialog;
/*     */     //   0	19	1	x	Z }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void println(char x) { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: new java/lang/StringBuffer
/*     */     //   4: dup
/*     */     //   5: invokespecial <init> : ()V
/*     */     //   8: iload_1
/*     */     //   9: invokevirtual append : (C)Ljava/lang/StringBuffer;
/*     */     //   12: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   15: invokevirtual println : (Ljava/lang/String;)V
/*     */     //   18: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #199	-> 0
/*     */     //   #200	-> 18
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	19	0	this	Lacm/io/IODialog;
/*     */     //   0	19	1	x	C }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void println(double x) { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: new java/lang/StringBuffer
/*     */     //   4: dup
/*     */     //   5: invokespecial <init> : ()V
/*     */     //   8: dload_1
/*     */     //   9: invokevirtual append : (D)Ljava/lang/StringBuffer;
/*     */     //   12: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   15: invokevirtual println : (Ljava/lang/String;)V
/*     */     //   18: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #207	-> 0
/*     */     //   #208	-> 18
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	19	0	this	Lacm/io/IODialog;
/*     */     //   0	19	1	x	D }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void println(float x) { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: new java/lang/StringBuffer
/*     */     //   4: dup
/*     */     //   5: invokespecial <init> : ()V
/*     */     //   8: fload_1
/*     */     //   9: invokevirtual append : (F)Ljava/lang/StringBuffer;
/*     */     //   12: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   15: invokevirtual println : (Ljava/lang/String;)V
/*     */     //   18: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #215	-> 0
/*     */     //   #216	-> 18
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	19	0	this	Lacm/io/IODialog;
/*     */     //   0	19	1	x	F }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void println(int x) { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: new java/lang/StringBuffer
/*     */     //   4: dup
/*     */     //   5: invokespecial <init> : ()V
/*     */     //   8: iload_1
/*     */     //   9: invokevirtual append : (I)Ljava/lang/StringBuffer;
/*     */     //   12: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   15: invokevirtual println : (Ljava/lang/String;)V
/*     */     //   18: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #223	-> 0
/*     */     //   #224	-> 18
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	19	0	this	Lacm/io/IODialog;
/*     */     //   0	19	1	x	I }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void println(long x) { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: new java/lang/StringBuffer
/*     */     //   4: dup
/*     */     //   5: invokespecial <init> : ()V
/*     */     //   8: lload_1
/*     */     //   9: invokevirtual append : (J)Ljava/lang/StringBuffer;
/*     */     //   12: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   15: invokevirtual println : (Ljava/lang/String;)V
/*     */     //   18: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #231	-> 0
/*     */     //   #232	-> 18
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	19	0	this	Lacm/io/IODialog;
/*     */     //   0	19	1	x	J }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 239 */   public final void println(Object x) { println(x); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 250 */   public void showErrorMessage(String msg) { this.model.popupErrorMessage(msg); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 262 */   public final String readLine() { return readLine(null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 276 */   public String readLine(String prompt) { return readDialogLine(prompt, "Illegal input line"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 291 */   public final int readInt() { return readInt(null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int readInt(String prompt) {
/*     */     while (true) {
/* 308 */       String line = readDialogLine(prompt, "Illegal integer format");
/*     */       try {
/* 310 */         return Integer.parseInt(line);
/* 311 */       } catch (NumberFormatException ex) {
/* 312 */         signalError("Illegal integer format");
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 329 */   public final double readDouble() { return readDouble(null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double readDouble(String prompt) {
/*     */     while (true) {
/* 346 */       String line = readDialogLine(prompt, "Illegal numeric format");
/*     */       try {
/* 348 */         return Double.valueOf(line).doubleValue();
/* 349 */       } catch (NumberFormatException ex) {
/* 350 */         signalError("Illegal numeric format");
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 368 */   public final boolean readBoolean() { return readBoolean(null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 384 */   public final boolean readBoolean(String prompt) { return readBoolean(prompt, "true", "false"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean readBoolean(String prompt, String trueLabel, String falseLabel) {
/* 403 */     if (this.console != null && this.console.getInputScript() != null) {
/* 404 */       return this.console.readBoolean(prompt, trueLabel, falseLabel);
/*     */     }
/* 406 */     prompt = (prompt == null) ? this.outputLine : (String.valueOf(this.outputLine) + prompt);
/* 407 */     this.outputLine = "";
/*     */     Boolean choice;
/* 409 */     while ((choice = this.model.popupBooleanInputDialog(prompt, trueLabel, falseLabel, this.allowCancel)) == null) {
/* 410 */       if (this.allowCancel) throw new CancelledException(); 
/*     */     } 
/* 412 */     return choice.booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 427 */   public void setExceptionOnError(boolean flag) { this.exceptionOnError = flag; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 439 */   public boolean getExceptionOnError() { return this.exceptionOnError; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 455 */   public void setAllowCancel(boolean flag) { this.allowCancel = flag; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 467 */   public boolean getAllowCancel() { return this.allowCancel; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 481 */   public void setAssociatedConsole(IOConsole console) { this.console = console; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 493 */   public IOConsole getAssociatedConsole() { return this.console; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DialogModel createModel() {
/* 501 */     if (Platform.isSwingAvailable()) {
/*     */       try {
/* 503 */         Class swingDialogModelClass = Class.forName("acm.io.SwingDialogModel");
/* 504 */         Class[] types = { Class.forName("java.awt.Component") };
/* 505 */         Object[] args = { this.owner };
/* 506 */         Constructor con = swingDialogModelClass.getConstructor(types);
/* 507 */         return (DialogModel)con.newInstance(args);
/* 508 */       } catch (Exception ex) {
/* 509 */         return new AWTDialogModel(this.owner);
/*     */       } 
/*     */     }
/* 512 */     return new AWTDialogModel(this.owner);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String readDialogLine(String prompt, String message) {
/* 523 */     if (this.console != null && this.console.getInputScript() != null) {
/* 524 */       return this.console.readLine(prompt);
/*     */     }
/* 526 */     prompt = (prompt == null) ? this.outputLine : (String.valueOf(this.outputLine) + prompt);
/* 527 */     this.outputLine = "";
/*     */     String line;
/* 529 */     while ((line = this.model.popupLineInputDialog(prompt, this.allowCancel)) == null) {
/* 530 */       if (this.allowCancel) throw new CancelledException(); 
/*     */     } 
/* 532 */     return line;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void signalError(String msg) {
/* 542 */     if (this.exceptionOnError) throw new ErrorException(msg); 
/* 543 */     this.model.popupErrorMessage(msg);
/*     */   }
/*     */ }


/* Location:              /root/karel.jar!/acm/io/IODialog.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */