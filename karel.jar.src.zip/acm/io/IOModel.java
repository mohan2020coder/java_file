package acm.io;

public interface IOModel {
  void print(String paramString);
  
  void print(boolean paramBoolean);
  
  void print(char paramChar);
  
  void print(double paramDouble);
  
  void print(float paramFloat);
  
  void print(int paramInt);
  
  void print(long paramLong);
  
  void print(Object paramObject);
  
  void println();
  
  void println(String paramString);
  
  void println(boolean paramBoolean);
  
  void println(char paramChar);
  
  void println(double paramDouble);
  
  void println(float paramFloat);
  
  void println(int paramInt);
  
  void println(long paramLong);
  
  void println(Object paramObject);
  
  void showErrorMessage(String paramString);
  
  String readLine();
  
  String readLine(String paramString);
  
  int readInt();
  
  int readInt(String paramString);
  
  double readDouble();
  
  double readDouble(String paramString);
  
  boolean readBoolean();
  
  boolean readBoolean(String paramString);
  
  boolean readBoolean(String paramString1, String paramString2, String paramString3);
}


/* Location:              /root/karel.jar!/acm/io/IOModel.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */