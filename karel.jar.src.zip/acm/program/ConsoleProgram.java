/*    */ package acm.program;
/*    */ 
/*    */ import acm.io.IOConsole;
/*    */ import java.awt.BorderLayout;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ConsoleProgram
/*    */   extends Program
/*    */ {
/*    */   public ConsoleProgram() {
/* 28 */     setLayout(new BorderLayout());
/* 29 */     add("Center", getConsole());
/* 30 */     validate();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void run() {}
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 52 */   protected IOConsole createConsole() { return new IOConsole(); }
/*    */ }


/* Location:              /root/karel.jar!/acm/program/ConsoleProgram.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */