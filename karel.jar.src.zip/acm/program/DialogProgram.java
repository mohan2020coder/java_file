/*    */ package acm.program;
/*    */ 
/*    */ import acm.io.IOModel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class DialogProgram
/*    */   extends Program
/*    */ {
/*    */   public void run() {}
/*    */   
/* 49 */   public IOModel getInputModel() { return getDialog(); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 60 */   public IOModel getOutputModel() { return getDialog(); }
/*    */ }


/* Location:              /root/karel.jar!/acm/program/DialogProgram.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */