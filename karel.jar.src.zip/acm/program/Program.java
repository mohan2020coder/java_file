/*      */ package acm.program;
/*      */ 
/*      */ import acm.io.IOConsole;
/*      */ import acm.io.IODialog;
/*      */ import acm.io.IOModel;
/*      */ import acm.util.ErrorException;
/*      */ import acm.util.MediaTools;
/*      */ import acm.util.Platform;
/*      */ import java.applet.Applet;
/*      */ import java.applet.AppletStub;
/*      */ import java.awt.BorderLayout;
/*      */ import java.awt.Color;
/*      */ import java.awt.Component;
/*      */ import java.awt.Container;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.Frame;
/*      */ import java.awt.LayoutManager;
/*      */ import java.awt.MenuBar;
/*      */ import java.awt.Toolkit;
/*      */ import java.io.BufferedReader;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStreamReader;
/*      */ import java.io.PrintWriter;
/*      */ import java.util.Hashtable;
/*      */ import java.util.StringTokenizer;
/*      */ import java.util.Vector;
/*      */ import java.util.zip.ZipEntry;
/*      */ import java.util.zip.ZipFile;
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class Program
/*      */   extends Applet
/*      */   implements IOModel, Runnable
/*      */ {
/*      */   private static final int STARTUP_DELAY = 1000;
/*      */   private static final int STARTUP_CYCLE = 300;
/*      */   private static final int DEFAULT_X = 16;
/*      */   private static final int DEFAULT_Y = 40;
/*      */   private static final int DEFAULT_WIDTH = 754;
/*      */   private static final int DEFAULT_HEIGHT = 492;
/*      */   
/*      */   protected Program() {
/*   44 */     this.shown = false;
/*   45 */     this.parameterTable = null;
/*   46 */     this.title = getClass().getName();
/*   47 */     this.title = this.title.substring(this.title.lastIndexOf(".") + 1);
/*   48 */     this.stub = new ProgramAppletStub(this);
/*   49 */     setAppletStub(this.stub);
/*   50 */     setVisible(false);
/*   51 */     setLayout(new BorderLayout());
/*   52 */     initContentPane();
/*   53 */     initRootPane();
/*   54 */     this.console = createConsole();
/*   55 */     this.dialog = createDialogIO();
/*   56 */     this.dialog.setAssociatedConsole(this.console);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void run() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   79 */   public void print(String value) { getOutputModel().print(value); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void print(boolean x) { // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: new java/lang/StringBuffer
/*      */     //   4: dup
/*      */     //   5: invokespecial <init> : ()V
/*      */     //   8: iload_1
/*      */     //   9: invokevirtual append : (Z)Ljava/lang/StringBuffer;
/*      */     //   12: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   15: invokevirtual print : (Ljava/lang/String;)V
/*      */     //   18: return
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #87	-> 0
/*      */     //   #88	-> 18
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	19	0	this	Lacm/program/Program;
/*      */     //   0	19	1	x	Z }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void print(char x) { // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: new java/lang/StringBuffer
/*      */     //   4: dup
/*      */     //   5: invokespecial <init> : ()V
/*      */     //   8: iload_1
/*      */     //   9: invokevirtual append : (C)Ljava/lang/StringBuffer;
/*      */     //   12: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   15: invokevirtual print : (Ljava/lang/String;)V
/*      */     //   18: return
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #95	-> 0
/*      */     //   #96	-> 18
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	19	0	this	Lacm/program/Program;
/*      */     //   0	19	1	x	C }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void print(double x) { // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: new java/lang/StringBuffer
/*      */     //   4: dup
/*      */     //   5: invokespecial <init> : ()V
/*      */     //   8: dload_1
/*      */     //   9: invokevirtual append : (D)Ljava/lang/StringBuffer;
/*      */     //   12: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   15: invokevirtual print : (Ljava/lang/String;)V
/*      */     //   18: return
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #103	-> 0
/*      */     //   #104	-> 18
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	19	0	this	Lacm/program/Program;
/*      */     //   0	19	1	x	D }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void print(float x) { // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: new java/lang/StringBuffer
/*      */     //   4: dup
/*      */     //   5: invokespecial <init> : ()V
/*      */     //   8: fload_1
/*      */     //   9: invokevirtual append : (F)Ljava/lang/StringBuffer;
/*      */     //   12: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   15: invokevirtual print : (Ljava/lang/String;)V
/*      */     //   18: return
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #111	-> 0
/*      */     //   #112	-> 18
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	19	0	this	Lacm/program/Program;
/*      */     //   0	19	1	x	F }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void print(int x) { // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: new java/lang/StringBuffer
/*      */     //   4: dup
/*      */     //   5: invokespecial <init> : ()V
/*      */     //   8: iload_1
/*      */     //   9: invokevirtual append : (I)Ljava/lang/StringBuffer;
/*      */     //   12: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   15: invokevirtual print : (Ljava/lang/String;)V
/*      */     //   18: return
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #119	-> 0
/*      */     //   #120	-> 18
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	19	0	this	Lacm/program/Program;
/*      */     //   0	19	1	x	I }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void print(long x) { // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: new java/lang/StringBuffer
/*      */     //   4: dup
/*      */     //   5: invokespecial <init> : ()V
/*      */     //   8: lload_1
/*      */     //   9: invokevirtual append : (J)Ljava/lang/StringBuffer;
/*      */     //   12: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   15: invokevirtual print : (Ljava/lang/String;)V
/*      */     //   18: return
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #127	-> 0
/*      */     //   #128	-> 18
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	19	0	this	Lacm/program/Program;
/*      */     //   0	19	1	x	J }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  135 */   public final void print(Object x) { print(x); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  145 */   public void println() { getOutputModel().println(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  158 */   public void println(String value) { getOutputModel().println(value); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void println(boolean x) { // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: new java/lang/StringBuffer
/*      */     //   4: dup
/*      */     //   5: invokespecial <init> : ()V
/*      */     //   8: iload_1
/*      */     //   9: invokevirtual append : (Z)Ljava/lang/StringBuffer;
/*      */     //   12: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   15: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   18: return
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #166	-> 0
/*      */     //   #167	-> 18
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	19	0	this	Lacm/program/Program;
/*      */     //   0	19	1	x	Z }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void println(char x) { // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: new java/lang/StringBuffer
/*      */     //   4: dup
/*      */     //   5: invokespecial <init> : ()V
/*      */     //   8: iload_1
/*      */     //   9: invokevirtual append : (C)Ljava/lang/StringBuffer;
/*      */     //   12: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   15: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   18: return
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #174	-> 0
/*      */     //   #175	-> 18
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	19	0	this	Lacm/program/Program;
/*      */     //   0	19	1	x	C }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void println(double x) { // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: new java/lang/StringBuffer
/*      */     //   4: dup
/*      */     //   5: invokespecial <init> : ()V
/*      */     //   8: dload_1
/*      */     //   9: invokevirtual append : (D)Ljava/lang/StringBuffer;
/*      */     //   12: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   15: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   18: return
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #182	-> 0
/*      */     //   #183	-> 18
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	19	0	this	Lacm/program/Program;
/*      */     //   0	19	1	x	D }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void println(float x) { // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: new java/lang/StringBuffer
/*      */     //   4: dup
/*      */     //   5: invokespecial <init> : ()V
/*      */     //   8: fload_1
/*      */     //   9: invokevirtual append : (F)Ljava/lang/StringBuffer;
/*      */     //   12: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   15: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   18: return
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #190	-> 0
/*      */     //   #191	-> 18
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	19	0	this	Lacm/program/Program;
/*      */     //   0	19	1	x	F }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void println(int x) { // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: new java/lang/StringBuffer
/*      */     //   4: dup
/*      */     //   5: invokespecial <init> : ()V
/*      */     //   8: iload_1
/*      */     //   9: invokevirtual append : (I)Ljava/lang/StringBuffer;
/*      */     //   12: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   15: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   18: return
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #198	-> 0
/*      */     //   #199	-> 18
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	19	0	this	Lacm/program/Program;
/*      */     //   0	19	1	x	I }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void println(long x) { // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: new java/lang/StringBuffer
/*      */     //   4: dup
/*      */     //   5: invokespecial <init> : ()V
/*      */     //   8: lload_1
/*      */     //   9: invokevirtual append : (J)Ljava/lang/StringBuffer;
/*      */     //   12: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   15: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   18: return
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #206	-> 0
/*      */     //   #207	-> 18
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	19	0	this	Lacm/program/Program;
/*      */     //   0	19	1	x	J }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  214 */   public final void println(Object x) { println(x); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  225 */   public void showErrorMessage(String msg) { getDialog().showErrorMessage(msg); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  238 */   public final String readLine() { return readLine(null); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  251 */   public String readLine(String prompt) { return getInputModel().readLine(prompt); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  266 */   public final int readInt() { return readInt(null); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  282 */   public int readInt(String prompt) { return getInputModel().readInt(prompt); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  297 */   public final double readDouble() { return readDouble(null); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  313 */   public double readDouble(String prompt) { return getInputModel().readDouble(prompt); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  329 */   public final boolean readBoolean() { return readBoolean(null); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  345 */   public final boolean readBoolean(String prompt) { return readBoolean(prompt, "true", "false"); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  363 */   public boolean readBoolean(String prompt, String trueLabel, String falseLabel) { return getInputModel().readBoolean(prompt, trueLabel, falseLabel); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isAppletMode() {
/*  375 */     if (!this.started) {
/*  376 */       throw new ErrorException("You can't call isAppletMode from the constructor");
/*      */     }
/*  378 */     return this.isAppletMode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  389 */   public IOConsole getConsole() { return this.console; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  400 */   public IODialog getDialog() { return this.dialog; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  412 */   public IOModel getInputModel() { return getConsole(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  424 */   public IOModel getOutputModel() { return getConsole(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  435 */   public BufferedReader getReader() { return getConsole().getReader(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  446 */   public PrintWriter getWriter() { return getConsole().getWriter(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  458 */   public void setInputScript(BufferedReader rd) { getConsole().setInputScript(rd); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTitle(String title) {
/*  470 */     this.title = title;
/*  471 */     if (this.programFrame != null) this.programFrame.setTitle(title);
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  482 */   public String getTitle() { return this.title; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void pause(double milliseconds) {
/*      */     try {
/*  500 */       int millis = (int)milliseconds;
/*  501 */       int nanos = (int)Math.round((milliseconds - millis) * 1000000.0D);
/*  502 */       Thread.sleep(millis, nanos);
/*  503 */     } catch (InterruptedException interruptedException) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Frame createProgramFrame() {
/*  520 */     Frame frame = new ProgramFrame(getTitle());
/*  521 */     frame.setLayout(new BorderLayout());
/*  522 */     return frame;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  534 */   protected IOConsole createConsole() { return IOConsole.SYSTEM_CONSOLE; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  546 */   protected IODialog createDialogIO() { return new IODialog(getContentPane()); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  564 */   protected Component createBorder(String side) { return isAppletMode() ? new ProgramBorder(side, 1) : null; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  580 */   public int getWidth() { return (this.contentPane.getSize()).width; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  592 */   public int getHeight() { return (this.contentPane.getSize()).height; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getParameter(String name) {
/*  605 */     String value = null;
/*  606 */     if (this.parameterTable != null) {
/*  607 */       value = (String)this.parameterTable.get(name.toLowerCase());
/*      */     }
/*  609 */     if (value != null) return value; 
/*  610 */     return super.getParameter(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLayout(LayoutManager layout) {
/*  622 */     if (this.contentPane == null) {
/*  623 */       super.setLayout(layout);
/*      */     } else {
/*  625 */       this.contentPane.setLayout(layout);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  638 */   public LayoutManager getLayout() { return this.contentPane.getLayout(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Component add(Component comp) {
/*  650 */     this.contentPane.add(comp);
/*  651 */     if (!this.shown && this.programFrame != null) {
/*  652 */       this.programFrame.show();
/*  653 */       this.shown = true;
/*      */     } 
/*  655 */     return comp;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Component add(String name, Component comp) {
/*  668 */     this.contentPane.add(name, comp);
/*  669 */     if (!this.shown && this.programFrame != null) {
/*  670 */       this.programFrame.show();
/*  671 */       this.shown = true;
/*      */     } 
/*  673 */     return comp;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Component add(Component comp, int index) {
/*  687 */     this.contentPane.add(comp, index);
/*  688 */     if (!this.shown && this.programFrame != null) {
/*  689 */       this.programFrame.show();
/*  690 */       this.shown = true;
/*      */     } 
/*  692 */     return comp;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void add(Component comp, Object constraints) {
/*  705 */     this.contentPane.add(comp, constraints);
/*  706 */     if (!this.shown && this.programFrame != null) {
/*  707 */       this.programFrame.show();
/*  708 */       this.shown = true;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void add(Component comp, Object constraints, int index) {
/*  724 */     this.contentPane.add(comp, constraints, index);
/*  725 */     if (!this.shown && this.programFrame != null) {
/*  726 */       this.programFrame.show();
/*  727 */       this.shown = true;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  740 */   public void remove(int index) { this.contentPane.remove(index); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  752 */   public void remove(Component comp) { this.contentPane.remove(comp); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  763 */   public void removeAll() { this.contentPane.removeAll(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBackground(Color color) {
/*  774 */     if (this.backgroundPane != null) this.backgroundPane.setBackground(color); 
/*  775 */     super.setBackground(color);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void validate() {
/*  786 */     if (this.contentPane != null) this.contentPane.validate(); 
/*  787 */     this.rootPane.validate();
/*  788 */     super.validate();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMenuBar(MenuBar menuBar) {
/*  800 */     this.menuBar = menuBar;
/*  801 */     if (this.programFrame != null) this.programFrame.setMenuBar(menuBar);
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  813 */   public MenuBar getMenuBar() { return this.menuBar; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void init() {
/*  826 */     this.isAppletMode = (getParent() != null);
/*  827 */     if (this.isAppletMode) {
/*  828 */       this.started = true;
/*  829 */       addBorders();
/*  830 */       initAppletFrame();
/*  831 */       validate();
/*  832 */       MediaTools.setCodeBase(getCodeBase());
/*  833 */       setVisible(true);
/*  834 */       startRun();
/*      */     } else {
/*  836 */       throw new ErrorException("Programs cannot make explicit calls to init()");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  850 */   public final void start() { if (!this.isAppletMode) start(null);
/*      */      }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void main(String[] args) {
/*  873 */     Hashtable ht = createParameterTable(args);
/*  874 */     String className = (String)ht.get("code");
/*  875 */     Class mainClass = null;
/*  876 */     Program program = null;
/*  877 */     if (className == null) {
/*  878 */       className = readMainClassFromCommandLine(getCommandLine());
/*      */     }
/*  880 */     if (className != null) {
/*  881 */       if (className.endsWith(".class")) {
/*  882 */         className = className.substring(0, className.length() - 6);
/*      */       }
/*  884 */       className = className.replace('/', '.');
/*      */       try {
/*  886 */         mainClass = Class.forName(className);
/*  887 */       } catch (ClassNotFoundException classNotFoundException) {}
/*      */     } 
/*      */ 
/*      */     
/*  891 */     if (mainClass != null) {
/*      */       try {
/*  893 */         Object obj = mainClass.newInstance();
/*  894 */         if (obj instanceof Program) {
/*  895 */           program = (Program)obj;
/*  896 */           program.setStartupObject(null);
/*      */         } else {
/*  898 */           className = (String)ht.get("program");
/*  899 */           if (className == null) {
/*  900 */             throw new ErrorException("Main class does not specify a program");
/*      */           }
/*  902 */           program = (Program)Class.forName(className).newInstance();
/*  903 */           program.setStartupObject(obj);
/*      */         } 
/*  905 */       } catch (IllegalAccessException illegalAccessException) {
/*      */       
/*  907 */       } catch (InstantiationException instantiationException) {
/*      */       
/*  909 */       } catch (ClassNotFoundException classNotFoundException) {}
/*      */ 
/*      */       
/*  912 */       if (program == null) {
/*  913 */         throw new ErrorException("You need to specify a static main method in your program if you want to run it as an application.");
/*      */       }
/*      */     } 
/*      */     
/*  917 */     program.setParameterTable(ht);
/*  918 */     program.start();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Component getBorder(String side) {
/*  938 */     if (side.equalsIgnoreCase("North")) return this.northBorder; 
/*  939 */     if (side.equalsIgnoreCase("South")) return this.southBorder; 
/*  940 */     if (side.equalsIgnoreCase("East")) return this.eastBorder; 
/*  941 */     if (side.equalsIgnoreCase("West")) return this.westBorder; 
/*  942 */     throw new ErrorException("Illegal border specification - " + side);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  955 */   protected String[] getArgumentArray() { return (this.parameterTable == null) ? null : (String[])this.parameterTable.get("ARGS"); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  967 */   protected Container getContentPane() { return this.contentPane; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  979 */   protected Container getRootPane() { return this.rootPane; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  991 */   protected Container getGlassPane() { return this.glassPane; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1003 */   protected Component getBackgroundPane() { return this.backgroundPane; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isStarted() {
/* 1014 */     IOConsole console = getConsole();
/* 1015 */     if (console == null) return false; 
/* 1016 */     if (console.getParent() == null) return true; 
/* 1017 */     Dimension size = console.getSize();
/* 1018 */     return (console.isShowing() && size.width != 0 && size.height != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void startHook() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void endHook() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setAppletStub(AppletStub stub) {
/* 1050 */     this.stub = stub;
/* 1051 */     setStub(stub);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1062 */   protected AppletStub getAppletStub() { return this.stub; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1073 */   protected void setParameterTable(Hashtable ht) { this.parameterTable = ht; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1084 */   protected Hashtable getParameterTable() { return this.parameterTable; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1096 */   protected void setStartupObject(Object obj) { this.startupObject = obj; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1110 */   protected Object getStartupObject() { return this.startupObject; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void start(String[] args) {
/* 1119 */     if (this.parameterTable == null) this.parameterTable = createParameterTable(args); 
/* 1120 */     if (getParent() == null) initApplicationFrame(); 
/* 1121 */     this.started = true;
/* 1122 */     addBorders();
/* 1123 */     validate();
/* 1124 */     this.programFrame.validate();
/* 1125 */     setVisible(true);
/* 1126 */     startRun();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static String getCommandLine() {
/* 1139 */     switch (Platform.getPlatform()) { case 1:
/*      */       case 2:
/* 1141 */         return getShellCommandLine();
/*      */       case 3:
/* 1143 */         return getDOSCommandLine(); }
/*      */     
/* 1145 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void startRun() {
/* 1154 */     ProgramStartupListener listener = new ProgramStartupListener();
/* 1155 */     this.rootPane.addComponentListener(listener);
/* 1156 */     this.rootPane.validate();
/* 1157 */     pause(1000.0D);
/* 1158 */     synchronized (listener) {
/* 1159 */       while (!isStarted()) {
/*      */         try {
/* 1161 */           wait(300L);
/* 1162 */         } catch (InterruptedException interruptedException) {}
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1167 */     this.rootPane.update(this.rootPane.getGraphics());
/* 1168 */     startHook();
/* 1169 */     runHook();
/* 1170 */     endHook();
/* 1171 */     if (this.contentPane.getComponentCount() == 0 && !this.isAppletMode) {
/* 1172 */       System.exit(0);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1182 */   protected void runHook() { run(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static Hashtable createParameterTable(String[] args) {
/* 1203 */     if (args == null) return null; 
/* 1204 */     Hashtable ht = new Hashtable();
/* 1205 */     Vector v = new Vector();
/* 1206 */     for (int i = 0; i < args.length; i++) {
/* 1207 */       String arg = args[i];
/* 1208 */       int equals = arg.indexOf('=');
/* 1209 */       if (equals > 0) {
/* 1210 */         String name = arg.substring(0, equals).toLowerCase();
/* 1211 */         String value = arg.substring(equals + 1);
/* 1212 */         ht.put(name, value);
/*      */       } else {
/* 1214 */         v.addElement(arg);
/*      */       } 
/*      */     } 
/* 1217 */     String[] newArgs = new String[v.size()];
/* 1218 */     for (int i = 0; i < v.size(); i++) {
/* 1219 */       newArgs[i] = (String)v.elementAt(i);
/*      */     }
/* 1221 */     ht.put("ARGS", newArgs);
/* 1222 */     return ht;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static String readMainClassFromCommandLine(String line) {
/* 1239 */     if (line == null) return null; 
/* 1240 */     boolean jarFlag = false;
/* 1241 */     StringTokenizer tokenizer = new StringTokenizer(line);
/* 1242 */     if (!tokenizer.hasMoreTokens()) return null; 
/* 1243 */     String token = tokenizer.nextToken();
/* 1244 */     if (!token.endsWith("java")) return null; 
/* 1245 */     while (tokenizer.hasMoreTokens()) {
/* 1246 */       token = tokenizer.nextToken();
/* 1247 */       if (token.startsWith("-")) {
/* 1248 */         if (token.equals("-jar")) {
/* 1249 */           jarFlag = true; continue;
/* 1250 */         }  if (token.equals("-cp") || token.equals("-classpath"))
/* 1251 */           tokenizer.nextToken(); 
/*      */         continue;
/*      */       } 
/* 1254 */       if (jarFlag) {
/* 1255 */         return readMainClassFromManifest(token);
/*      */       }
/* 1257 */       return token;
/*      */     } 
/*      */     
/* 1260 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void initAppletFrame() {
/* 1273 */     super.add("Center", this.rootPane);
/* 1274 */     validate();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void initApplicationFrame() {
/* 1282 */     this.programFrame = createProgramFrame();
/* 1283 */     ((ProgramAppletStub)this.stub).setFrame(this.programFrame);
/* 1284 */     setFrameBounds(this.programFrame);
/* 1285 */     this.programFrame.add("Center", this.rootPane);
/* 1286 */     this.programFrame.addWindowListener(new ProgramWindowListener());
/* 1287 */     if (this.contentPane.getComponentCount() != 0) {
/* 1288 */       this.programFrame.show();
/* 1289 */       this.shown = true;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void addBorders() {
/* 1299 */     this.northBorder = createBorder("North");
/* 1300 */     if (this.northBorder != null) super.add("North", this.northBorder); 
/* 1301 */     this.southBorder = createBorder("South");
/* 1302 */     if (this.southBorder != null) super.add("South", this.southBorder); 
/* 1303 */     this.eastBorder = createBorder("East");
/* 1304 */     if (this.eastBorder != null) super.add("East", this.eastBorder); 
/* 1305 */     this.westBorder = createBorder("West");
/* 1306 */     if (this.westBorder != null) super.add("West", this.westBorder);
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void initContentPane() {
/* 1314 */     this.contentPane = new ProgramContentPane();
/* 1315 */     this.contentPane.setLayout(new BorderLayout());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void initRootPane() {
/* 1323 */     this.backgroundPane = new ProgramBackgroundPane();
/* 1324 */     String colorName = getParameter("bgcolor");
/* 1325 */     Color bgColor = (colorName == null) ? DEFAULT_BGCOLOR : decodeColor(colorName);
/* 1326 */     this.backgroundPane.setBackground(bgColor);
/* 1327 */     this.glassPane = new ProgramGlassPane();
/* 1328 */     this.rootPane = new ProgramRootPane(this, this.backgroundPane, this.contentPane, this.glassPane);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setFrameBounds(Frame frame) {
/* 1336 */     Dimension size = Toolkit.getDefaultToolkit().getScreenSize();
/* 1337 */     int width = decodeSizeParameter("WIDTH", 754, size.width);
/* 1338 */     int height = decodeSizeParameter("HEIGHT", 492, size.height);
/* 1339 */     int x = decodeSizeParameter("X", (width >= size.width) ? 0 : 16, size.width);
/* 1340 */     int y = decodeSizeParameter("Y", (height >= size.height) ? 0 : 40, size.height);
/* 1341 */     frame.setBounds(x, y, width, height);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Color decodeColor(String name) {
/* 1353 */     if (name.equalsIgnoreCase("black")) return Color.black; 
/* 1354 */     if (name.equalsIgnoreCase("blue")) return Color.blue; 
/* 1355 */     if (name.equalsIgnoreCase("cyan")) return Color.cyan; 
/* 1356 */     if (name.equalsIgnoreCase("darkGray")) return Color.darkGray; 
/* 1357 */     if (name.equalsIgnoreCase("gray")) return Color.gray; 
/* 1358 */     if (name.equalsIgnoreCase("green")) return Color.green; 
/* 1359 */     if (name.equalsIgnoreCase("lightGray")) return Color.lightGray; 
/* 1360 */     if (name.equalsIgnoreCase("magenta")) return Color.magenta; 
/* 1361 */     if (name.equalsIgnoreCase("orange")) return Color.orange; 
/* 1362 */     if (name.equalsIgnoreCase("pink")) return Color.pink; 
/* 1363 */     if (name.equalsIgnoreCase("red")) return Color.red; 
/* 1364 */     if (name.equalsIgnoreCase("white")) return Color.white; 
/* 1365 */     if (name.equalsIgnoreCase("yellow")) return Color.yellow; 
/* 1366 */     return Color.decode(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int decodeSizeParameter(String name, int value, int max) {
/* 1380 */     String str = getParameter(name);
/* 1381 */     if (str == null) return value; 
/* 1382 */     if (str.equals("*")) str = "100%"; 
/* 1383 */     if (str.endsWith("%")) {
/* 1384 */       int percent = Integer.parseInt(str.substring(0, str.length() - 1));
/* 1385 */       return (int)Math.round(percent / 100.0D * max);
/*      */     } 
/* 1387 */     return Integer.parseInt(str);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String readMainClassFromManifest(String jarName) {
/*      */     try {
/* 1402 */       ZipFile jarFile = new ZipFile(jarName);
/* 1403 */       ZipEntry entry = jarFile.getEntry("META-INF/MANIFEST.MF");
/* 1404 */       if (entry == null) return null; 
/* 1405 */       BufferedReader rd = new BufferedReader(new InputStreamReader(jarFile.getInputStream(entry)));
/* 1406 */       for (String line = rd.readLine(); line != null; line = rd.readLine()) {
/* 1407 */         if (line.startsWith("Main-Class:")) {
/* 1408 */           return line.substring("Main-Class:".length()).trim();
/*      */         }
/*      */       } 
/* 1411 */       return null;
/* 1412 */     } catch (IOException ex) {
/* 1413 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String getShellCommandLine() {
/*      */     try {
/* 1429 */       option = Platform.isMac() ? "command" : "args";
/* 1430 */       String[] argv = { "bash", "-c", "ps -p $PPID -o " + option };
/* 1431 */       Process p = Runtime.getRuntime().exec(argv);
/* 1432 */       p.waitFor();
/* 1433 */       if (p.getErrorStream().read() != -1) return null; 
/* 1434 */       BufferedReader rd = new BufferedReader(new InputStreamReader(p.getInputStream()));
/* 1435 */       String header = rd.readLine();
/* 1436 */       return rd.readLine();
/* 1437 */     } catch (Exception ex) {
/* 1438 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1455 */   private static String getDOSCommandLine() { return null; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1466 */   private static final Color DEFAULT_BGCOLOR = Color.white;
/*      */   private Frame programFrame;
/*      */   private Hashtable optionTable;
/*      */   private AppletStub stub;
/*      */   private String title;
/*      */   private MenuBar menuBar;
/*      */   private Hashtable parameterTable;
/*      */   private ProgramRootPane rootPane;
/*      */   private ProgramBackgroundPane backgroundPane;
/*      */   private ProgramGlassPane glassPane;
/*      */   private Container contentPane;
/*      */   private Component northBorder;
/*      */   private Component southBorder;
/*      */   private Component eastBorder;
/*      */   private Component westBorder;
/*      */   private IOConsole console;
/*      */   private IODialog dialog;
/*      */   private Object startupObject;
/*      */   private boolean started;
/*      */   private boolean shown;
/*      */   private boolean isAppletMode;
/*      */ }


/* Location:              /root/karel.jar!/acm/program/Program.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */