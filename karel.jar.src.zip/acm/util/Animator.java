/*    */ package acm.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Animator
/*    */   extends Thread
/*    */ {
/*    */   private boolean terminationRequested;
/*    */   
/*    */   public Animator() {}
/*    */   
/* 39 */   public Animator(ThreadGroup group) { super(group, null); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void pause(double milliseconds) {
/* 52 */     if (this.terminationRequested) throw new ThreadDeath(); 
/*    */     try {
/* 54 */       int millis = (int)milliseconds;
/* 55 */       int nanos = (int)Math.round((milliseconds - millis) * 1000000.0D);
/* 56 */       Thread.sleep(millis, nanos);
/* 57 */     } catch (InterruptedException interruptedException) {}
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 74 */   public void requestTermination() { this.terminationRequested = true; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void checkForTermination() {
/* 88 */     if (this.terminationRequested) throw new ThreadDeath(); 
/* 89 */     Thread.yield();
/*    */   }
/*    */ }


/* Location:              /root/karel.jar!/acm/util/Animator.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */