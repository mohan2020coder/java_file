/*     */ package acm.util;
/*     */ 
/*     */ import java.applet.Applet;
/*     */ import java.awt.Component;
/*     */ import java.awt.Frame;
/*     */ import java.awt.Menu;
/*     */ import java.awt.MenuBar;
/*     */ import java.awt.MenuItem;
/*     */ import java.awt.MenuShortcut;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AppletMenuBar
/*     */   extends MenuBar
/*     */   implements ActionListener
/*     */ {
/*     */   private Hashtable mnemonics;
/*     */   private int shortcutMask;
/*     */   
/*     */   public AppletMenuBar() {
/*  43 */     this.shortcutMask = Toolkit.getDefaultToolkit().getMenuShortcutKeyMask();
/*  44 */     this.mnemonics = new Hashtable();
/*  45 */     initMenus();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  57 */   public void initMenus() { add(createFileMenu()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Menu add(Menu menu) {
/*  71 */     menu.addActionListener(this);
/*  72 */     return super.add(menu);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  83 */   public MenuItem createMenuItem(String text) { return createMenuItem(text, 0, 0); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  95 */   public MenuItem createMenuItem(String text, int accelerator) { return (accelerator > 0) ? new MenuItem(text, new MenuShortcut(accelerator)) : new MenuItem(text); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MenuItem createMenuItem(String text, int accelerator, int mnemonic) {
/* 108 */     MenuItem item = createMenuItem(text, accelerator);
/* 109 */     setMnemonic(item, mnemonic);
/* 110 */     return item;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 123 */   public void setMnemonic(MenuItem item, int mnemonic) { if (mnemonic > 0) this.mnemonics.put(item, new Integer(mnemonic));
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void update() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void installInFrame(Component comp) {
/* 146 */     Applet applet = null;
/* 147 */     while (comp != null && !(comp instanceof Frame)) {
/* 148 */       if (comp instanceof Applet) applet = (Applet)comp; 
/* 149 */       comp = comp.getParent();
/*     */     } 
/* 151 */     if (comp == null)
/* 152 */       return;  Frame frame = (Frame)comp;
/* 153 */     update();
/* 154 */     if (applet != null) {
/*     */       try {
/* 156 */         Class programClass = Class.forName("acm.program.Program");
/* 157 */         if (programClass.isInstance(applet)) {
/* 158 */           Class[] types = { Class.forName("java.awt.MenuBar") };
/* 159 */           Object[] args = { this };
/* 160 */           Method setMenuBar = programClass.getMethod("setMenuBar", types);
/* 161 */           setMenuBar.invoke(applet, args);
/*     */         } 
/*     */         return;
/* 164 */       } catch (Exception exception) {}
/*     */     }
/*     */ 
/*     */     
/* 168 */     frame.setMenuBar(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 180 */   public void actionPerformed(ActionEvent e) { menuAction(e.getActionCommand()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Menu createFileMenu() {
/* 192 */     Menu menu = new Menu("File");
/* 193 */     addQuitItem(menu);
/* 194 */     return menu;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Menu createEditMenu() {
/* 206 */     Menu menu = new Menu("Edit");
/* 207 */     addCutCopyPaste(menu);
/* 208 */     return menu;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addQuitItem(Menu menu) {
/* 220 */     if (Platform.isMac()) {
/* 221 */       menu.add(createMenuItem("Quit", 81));
/*     */     } else {
/* 223 */       MenuItem item = createMenuItem("Exit", 0, 88);
/* 224 */       item.setActionCommand("Quit");
/* 225 */       menu.add(item);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addCutCopyPaste(Menu menu) {
/* 238 */     if (Platform.isMac()) {
/* 239 */       menu.add(createMenuItem("Cut", 88));
/* 240 */       menu.add(createMenuItem("Copy", 67));
/* 241 */       menu.add(createMenuItem("Paste", 86));
/*     */     } else {
/* 243 */       MenuItem item = createMenuItem("Cut (x)", 0, 88);
/* 244 */       item.setActionCommand("Cut");
/* 245 */       menu.add(item);
/* 246 */       item = createMenuItem("Copy (c)", 0, 67);
/* 247 */       item.setActionCommand("Copy");
/* 248 */       menu.add(item);
/* 249 */       item = createMenuItem("Paste (v)", 0, 86);
/* 250 */       item.setActionCommand("Paste");
/* 251 */       menu.add(item);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 273 */   public void menuAction(String cmd) { if ("Quit".equals(cmd)) System.exit(0);  }
/*     */ }


/* Location:              /root/karel.jar!/acm/util/AppletMenuBar.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */