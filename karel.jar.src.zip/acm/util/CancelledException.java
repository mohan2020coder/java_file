package acm.util;

public class CancelledException extends RuntimeException {}


/* Location:              /root/karel.jar!/acm/util/CancelledException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */