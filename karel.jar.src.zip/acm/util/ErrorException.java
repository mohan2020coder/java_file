/*    */ package acm.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ErrorException
/*    */   extends RuntimeException
/*    */ {
/* 33 */   public ErrorException(String msg) { super(msg); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 44 */   public ErrorException(Exception ex) { super(String.valueOf(ex.getClass().getName()) + ": " + ex.getMessage()); }
/*    */ }


/* Location:              /root/karel.jar!/acm/util/ErrorException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */