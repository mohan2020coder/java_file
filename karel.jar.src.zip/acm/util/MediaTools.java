/*     */ package acm.util;
/*     */ 
/*     */ import java.applet.AudioClip;
/*     */ import java.awt.Component;
/*     */ import java.awt.Image;
/*     */ import java.awt.MediaTracker;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.image.ImageProducer;
/*     */ import java.awt.image.MemoryImageSource;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.util.Hashtable;
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MediaTools
/*     */ {
/*     */   public static final String DEFAULT_IMAGE_PATH = ".:images";
/*     */   public static final String DEFAULT_AUDIO_PATH = ".:sounds";
/*     */   
/*  74 */   public static Image loadImage(String name) { return loadImage(name, ".:images"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Image loadImage(String name, String path) {
/*  92 */     Image image = (Image)imageTable.get(name);
/*  93 */     if (image != null) return image; 
/*  94 */     Toolkit toolkit = Toolkit.getDefaultToolkit();
/*  95 */     StringTokenizer tokenizer = new StringTokenizer(path, ":");
/*  96 */     while (image == null && tokenizer.hasMoreTokens()) {
/*  97 */       String prefix = tokenizer.nextToken();
/*  98 */       prefix = prefix.equals(".") ? "" : (String.valueOf(prefix) + "/");
/*  99 */       URL url = null;
/*     */       try {
/* 101 */         url = RESOURCE_CLASS.getResource("/" + prefix + name);
/* 102 */       } catch (Exception exception) {}
/*     */ 
/*     */       
/* 105 */       if (url == null) {
/*     */         try {
/* 107 */           if (codeBase != null) url = new URL(codeBase, String.valueOf(prefix) + name); 
/* 108 */         } catch (MalformedURLException malformedURLException) {}
/*     */       }
/*     */ 
/*     */       
/* 112 */       if (url == null) {
/*     */         try {
/* 114 */           if ((new File(String.valueOf(prefix) + name)).canRead())
/* 115 */             image = toolkit.getImage(String.valueOf(prefix) + name); 
/*     */           continue;
/* 117 */         } catch (SecurityException ex) {
/*     */           continue;
/*     */         } 
/*     */       }
/*     */       try {
/* 122 */         URLConnection connection = url.openConnection();
/* 123 */         if (connection.getContentLength() > 0) {
/* 124 */           Object content = connection.getContent();
/* 125 */           if (content instanceof ImageProducer) {
/* 126 */             image = toolkit.createImage((ImageProducer)content); continue;
/* 127 */           }  if (content != null) {
/* 128 */             image = toolkit.getImage(url);
/*     */           }
/*     */         } 
/* 131 */       } catch (IOException iOException) {}
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 136 */     if (image == null) throw new ErrorException("Cannot find an image named " + name); 
/* 137 */     loadImage(image);
/* 138 */     imageTable.put(name, image);
/* 139 */     return image;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Image loadImage(Image image) {
/* 151 */     MediaTracker tracker = new MediaTracker(new TrackerComponent());
/* 152 */     tracker.addImage(image, 0);
/*     */     try {
/* 154 */       tracker.waitForID(0);
/* 155 */     } catch (InterruptedException ex) {
/* 156 */       throw new ErrorException("Image loading process interrupted");
/*     */     } 
/* 158 */     return image;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 170 */   public static void defineImage(String name, Image image) { imageTable.put(name, image); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 182 */   public static void flushImage(String name) { imageTable.remove(name); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 196 */   public static Image createImage(int[] pixels, int width, int height) { return Toolkit.getDefaultToolkit().createImage(new MemoryImageSource(width, height, pixels, 0, width)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Image createImage(InputStream in) {
/*     */     try {
/* 210 */       URLConnection connection = new LocalGIFConnection(in, getDummyURL());
/* 211 */       Object content = connection.getContent();
/* 212 */       return Toolkit.getDefaultToolkit().createImage((ImageProducer)content);
/*     */     }
/* 214 */     catch (Exception ex) {
/* 215 */       throw new ErrorException("Exception: " + ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 228 */   public static Image createImage(String[] hexData) { return createImage(new HexInputStream(hexData)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 239 */   public static Component getImageObserver() { return new TrackerComponent(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 268 */   public static AudioClip loadAudioClip(String name) { return loadAudioClip(name, ".:sounds"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AudioClip loadAudioClip(String name, String path) {
/* 286 */     AudioClip clip = (AudioClip)audioClipTable.get(name);
/* 287 */     if (clip != null) return clip; 
/* 288 */     StringTokenizer tokenizer = new StringTokenizer(path, ":");
/* 289 */     while (clip == null && tokenizer.hasMoreTokens()) {
/* 290 */       String prefix = tokenizer.nextToken();
/* 291 */       prefix = prefix.equals(".") ? "" : (String.valueOf(prefix) + "/");
/* 292 */       URL url = null;
/*     */       try {
/* 294 */         url = RESOURCE_CLASS.getResource("/" + prefix + name);
/* 295 */       } catch (Exception exception) {}
/*     */ 
/*     */       
/* 298 */       if (url == null) {
/*     */         try {
/* 300 */           if (codeBase != null) url = new URL(codeBase, String.valueOf(prefix) + name); 
/* 301 */         } catch (MalformedURLException malformedURLException) {}
/*     */       }
/*     */ 
/*     */       
/* 305 */       if (url == null) {
/*     */         try {
/* 307 */           File file = new File(String.valueOf(prefix) + name);
/* 308 */           if (file.canRead())
/* 309 */             clip = createAudioClip(new FileInputStream(file)); 
/*     */           continue;
/* 311 */         } catch (Exception ex) {
/*     */           continue;
/*     */         } 
/*     */       }
/*     */       try {
/* 316 */         URLConnection connection = url.openConnection();
/* 317 */         if (connection.getContentLength() > 0) {
/* 318 */           Object content = connection.getContent();
/* 319 */           if (content instanceof AudioClip) {
/* 320 */             clip = (AudioClip)content; continue;
/* 321 */           }  if (content instanceof InputStream) {
/* 322 */             clip = createAudioClip((InputStream)content);
/*     */           }
/*     */         } 
/* 325 */       } catch (IOException iOException) {}
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 330 */     if (clip == null) throw new ErrorException("Cannot find an audio clip named " + name); 
/* 331 */     audioClipTable.put(name, clip);
/* 332 */     return clip;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 344 */   public static void defineAudioClip(String name, AudioClip clip) { audioClipTable.put(name, clip); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 356 */   public static void flushAudioClip(String name) { audioClipTable.remove(name); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AudioClip createAudioClip(InputStream in) {
/*     */     try {
/* 370 */       return new SunAudioClip(in);
/* 371 */     } catch (Exception ex) {
/* 372 */       return new NullAudioClip();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 385 */   public static AudioClip createAudioClip(String[] hexData) { return createAudioClip(new HexInputStream(hexData)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 398 */   public static InputStream getHexInputStream(String[] hexData) { return new HexInputStream(hexData); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 413 */   public static void setCodeBase(URL url) { codeBase = url; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 424 */   public static URL getCodeBase() { return codeBase; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static URL getDummyURL() {
/*     */     try {
/* 433 */       if (codeBase != null) return codeBase; 
/* 434 */       return new URL("verbatim://dummy");
/* 435 */     } catch (Exception ex) {
/* 436 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 442 */   private static URL codeBase = null;
/* 443 */   private static Hashtable imageTable = new Hashtable();
/* 444 */   private static Hashtable audioClipTable = new Hashtable();
/* 445 */   private static final Class RESOURCE_CLASS = (new MediaTools()).getClass();
/*     */ }


/* Location:              /root/karel.jar!/acm/util/MediaTools.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */