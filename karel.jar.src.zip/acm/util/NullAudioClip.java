package acm.util;

import java.applet.AudioClip;

class NullAudioClip implements AudioClip {
  public void play() {}
  
  public void loop() {}
  
  public void stop() {}
}


/* Location:              /root/karel.jar!/acm/util/NullAudioClip.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */