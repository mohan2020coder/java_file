/*     */ package acm.util;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.Frame;
/*     */ import java.io.File;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Platform
/*     */ {
/*     */   public static final int UNKNOWN = 0;
/*     */   public static final int MAC = 1;
/*     */   public static final int UNIX = 2;
/*     */   public static final int WINDOWS = 3;
/*     */   
/*     */   public static int getPlatform() {
/*  46 */     if (platform != -1) return platform; 
/*  47 */     name = System.getProperty("os.name", "").toLowerCase();
/*  48 */     if (name.startsWith("mac")) return platform = 1; 
/*  49 */     if (name.startsWith("windows")) return platform = 3; 
/*  50 */     if (name.startsWith("microsoft")) return platform = 3; 
/*  51 */     if (name.startsWith("ms")) return platform = 3; 
/*  52 */     if (name.startsWith("unix")) return platform = 2; 
/*  53 */     if (name.startsWith("linux")) return platform = 2; 
/*  54 */     return platform = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  65 */   public static boolean isMac() { return (getPlatform() == 1); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  76 */   public static boolean isWindows() { return (getPlatform() == 3); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  87 */   public static boolean isUnix() { return (getPlatform() == 2); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setFileTypeAndCreator(String filename, String type, String creator) {
/* 101 */     if (!isMac())
/*     */       return;  try {
/* 103 */       setFileTypeAndCreator(new File(filename), type, creator);
/* 104 */     } catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setFileTypeAndCreator(File file, String type, String creator) {
/* 120 */     if (!isMac())
/*     */       return;  try {
/* 122 */       Class mrjOSTypeClass = Class.forName("com.apple.mrj.MRJOSType");
/* 123 */       Class mrjFileUtilsClass = Class.forName("com.apple.mrj.MRJFileUtils");
/* 124 */       Class[] sig1 = { Class.forName("java.lang.String") };
/* 125 */       Constructor constructor = mrjOSTypeClass.getConstructor(sig1);
/* 126 */       Class[] sig2 = { Class.forName("java.io.File"), mrjOSTypeClass, mrjOSTypeClass };
/* 127 */       Method fn = mrjFileUtilsClass.getMethod("setFileTypeAndCreator", sig2);
/* 128 */       Object[] args1 = { (String.valueOf(type) + "    ").substring(0, 4) };
/* 129 */       Object osType = constructor.newInstance(args1);
/* 130 */       Object[] args2 = { (String.valueOf(creator) + "    ").substring(0, 4) };
/* 131 */       Object creatorType = constructor.newInstance(args2);
/* 132 */       Object[] args3 = { file, osType, creatorType };
/* 133 */       fn.invoke(null, args3);
/* 134 */     } catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isSwingAvailable() {
/* 149 */     if (!swingChecked) {
/* 150 */       swingChecked = true;
/*     */       try {
/* 152 */         isSwingAvailable = (Class.forName("javax.swing.JComponent") != null);
/* 153 */       } catch (Exception ex) {
/* 154 */         isSwingAvailable = false;
/*     */       } 
/*     */     } 
/* 157 */     return isSwingAvailable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isSunAudioAvailable() {
/* 169 */     if (!sunAudioChecked) {
/* 170 */       sunAudioChecked = true;
/*     */       try {
/* 172 */         isSunAudioAvailable = (Class.forName("sun.audio.AudioPlayer") != null);
/* 173 */       } catch (Exception ex) {
/* 174 */         isSunAudioAvailable = false;
/*     */       } 
/*     */     } 
/* 177 */     return isSunAudioAvailable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isJMFAvailable() {
/* 188 */     if (!jmfChecked) {
/* 189 */       jmfChecked = true;
/*     */       try {
/* 191 */         isJMFAvailable = (Class.forName("javax.media.Player") != null);
/* 192 */       } catch (Exception ex) {
/* 193 */         isJMFAvailable = false;
/*     */       } 
/*     */     } 
/* 196 */     return isJMFAvailable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean areCollectionsAvailable() {
/* 210 */     if (!collectionsChecked) {
/* 211 */       collectionsChecked = true;
/*     */       try {
/* 213 */         areCollectionsAvailable = (Class.forName("java.util.ArrayList") != null);
/* 214 */       } catch (Exception ex) {
/* 215 */         areCollectionsAvailable = false;
/*     */       } 
/*     */     } 
/* 218 */     return areCollectionsAvailable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Frame getEnclosingFrame(Component comp) {
/* 230 */     while (comp != null && !(comp instanceof Frame)) {
/* 231 */       comp = comp.getParent();
/*     */     }
/* 233 */     return (Frame)comp;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 238 */   private static int platform = -1;
/*     */   private static boolean isSwingAvailable;
/*     */   private static boolean swingChecked;
/*     */   private static boolean areCollectionsAvailable;
/*     */   private static boolean collectionsChecked;
/*     */   private static boolean isSunAudioAvailable;
/*     */   private static boolean sunAudioChecked;
/*     */   private static boolean isJMFAvailable;
/*     */   private static boolean jmfChecked;
/*     */ }


/* Location:              /root/karel.jar!/acm/util/Platform.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */