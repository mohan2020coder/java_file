/*    */ package acm.util;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RandomGenerator
/*    */   extends Random
/*    */ {
/* 45 */   public int nextInt(int n) { return nextInt(0, n - 1); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 58 */   public int nextInt(int low, int high) { return low + (int)((high - low + 1) * nextDouble()); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 71 */   public double nextDouble(double low, double high) { return low + (high - low) * nextDouble(); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 83 */   public boolean nextBoolean(double p) { return (nextDouble() < p); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 95 */   public Color nextColor() { return new Color(nextInt(256), nextInt(256), nextInt(256)); }
/*    */ }


/* Location:              /root/karel.jar!/acm/util/RandomGenerator.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */