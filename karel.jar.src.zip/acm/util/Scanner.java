/*     */ package acm.util;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Scanner
/*     */ {
/*     */   private static final String RADIX_DIGITS = "0123456789abcdefghijklmnopqrstuvwxyz";
/*     */   private Reader source;
/*     */   private String saved;
/*     */   private String delimiter;
/*     */   private int radix;
/*     */   
/*     */   public Scanner(File file) {
/*     */     try {
/*  36 */       initScanner(new FileReader(file));
/*  37 */     } catch (IOException ex) {
/*  38 */       throw new ErrorException(ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  50 */   public Scanner(InputStream in) { initScanner(new InputStreamReader(in)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  61 */   public Scanner(String str) { initScanner(new StringReader(str)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  72 */   public Scanner(Reader rd) { initScanner(rd); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasNext() {
/*  83 */     skipDelimiters();
/*  84 */     int ch = read();
/*  85 */     if (ch == -1) {
/*  86 */       return false;
/*     */     }
/*  88 */     save(ch);
/*  89 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasNextBoolean() {
/* 101 */     skipDelimiters();
/* 102 */     String token = scanBoolean();
/* 103 */     if (token != null) save(token); 
/* 104 */     return (token != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasNextDouble() {
/* 115 */     skipDelimiters();
/* 116 */     String token = scanDouble();
/* 117 */     if (token != null) save(token); 
/* 118 */     return (token != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasNextInt() {
/* 129 */     skipDelimiters();
/* 130 */     String token = scanInt();
/* 131 */     if (token != null) save(token); 
/* 132 */     return (token != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 145 */   public Object next() { return nextToken(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String nextToken() {
/* 156 */     int ch = 0;
/* 157 */     String token = "";
/* 158 */     skipDelimiters();
/* 159 */     while (!isDelimiter(ch = read())) {
/* 160 */       token = String.valueOf(token) + (char)ch;
/*     */     }
/* 162 */     save(ch);
/* 163 */     return token;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean nextBoolean() {
/* 174 */     String token = scanBoolean();
/* 175 */     if (token == null) {
/* 176 */       throw new ErrorException("nextBoolean: No boolean value found");
/*     */     }
/* 178 */     return token.equalsIgnoreCase("true");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double nextDouble() {
/* 189 */     String token = scanDouble();
/* 190 */     if (token == null) {
/* 191 */       throw new ErrorException("nextDouble: No double value found");
/*     */     }
/* 193 */     if (token.startsWith("+")) token = token.substring(1); 
/* 194 */     return Double.valueOf(token).doubleValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int nextInt() {
/* 205 */     String token = scanInt();
/* 206 */     if (token == null) {
/* 207 */       throw new ErrorException("nextInt: No integer value found");
/*     */     }
/* 209 */     if (token.startsWith("+")) token = token.substring(1); 
/* 210 */     return Integer.parseInt(token, this.radix);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String nextLine() {
/* 221 */     int ch = 0;
/* 222 */     String token = "";
/* 223 */     while ((ch = read()) != -1 && ch != 13 && ch != 10) {
/* 224 */       token = String.valueOf(token) + (char)ch;
/*     */     }
/* 226 */     if (ch == 13) {
/* 227 */       ch = read();
/* 228 */       if (ch != 10) save(ch); 
/*     */     } 
/* 230 */     return token;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 251 */   public String getDelimiter() { return this.delimiter; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDelimiter(String pattern) {
/* 264 */     checkDelimiterPattern(pattern);
/* 265 */     this.delimiter = pattern;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 277 */   public void useDelimiter(String pattern) { setDelimiter(pattern); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 288 */   public int getRadix() { return this.radix; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 299 */   public void setRadix(int radix) { this.radix = radix; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 311 */   public void useRadix(int radix) { setRadix(radix); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initScanner(Reader source) {
/* 319 */     this.source = source;
/* 320 */     this.saved = "";
/* 321 */     this.delimiter = null;
/* 322 */     this.radix = 10;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int read() {
/* 330 */     int ch = 0;
/* 331 */     if (this.saved.length() == 0) {
/*     */       try {
/* 333 */         ch = this.source.read();
/* 334 */       } catch (IOException ex) {
/* 335 */         throw new ErrorException(ex);
/*     */       } 
/*     */     } else {
/* 338 */       ch = this.saved.charAt(0);
/* 339 */       this.saved = this.saved.substring(1);
/*     */     } 
/* 341 */     return ch;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 350 */   private void save(int ch) { if (ch != -1) this.saved = String.valueOf((char)ch) + this.saved;
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 359 */   private void save(String str) { this.saved = String.valueOf(str) + this.saved; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkDelimiterPattern(String pattern) {
/* 368 */     if (pattern == null)
/* 369 */       return;  if (!pattern.startsWith("[") || !pattern.endsWith("]")) {
/* 370 */       throw new ErrorException("The only legal delimiter patterns for this implementation of the Scanner abstraction are a list of characters or character ranges enclosed in brackets.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void skipDelimiters() {
/* 381 */     int ch = 0; do {  }
/* 382 */     while ((ch = read()) != -1 && isDelimiter(ch));
/*     */ 
/*     */     
/* 385 */     save(ch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 393 */   private boolean isDelimiter(int ch) { return isDelimiter(ch, this.delimiter); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isDelimiter(int ch, String pattern) {
/* 401 */     if (ch == -1) return true; 
/* 402 */     if (pattern == null) {
/* 403 */       return Character.isWhitespace((char)ch);
/*     */     }
/* 405 */     boolean matched = false;
/* 406 */     boolean negate = false;
/* 407 */     char startChar = Character.MIN_VALUE;
/* 408 */     for (int i = 1; !matched && i < pattern.length() - 1; i++) {
/* 409 */       char pch = pattern.charAt(i);
/* 410 */       if (pch == '^' && i == 1) {
/* 411 */         negate = true;
/*     */       }
/* 413 */       else if (pch == '-' && startChar > '\000' && i != pattern.length() - 2) {
/* 414 */         matched = (startChar <= ch && ch <= pattern.charAt(++i));
/* 415 */         startChar = Character.MIN_VALUE;
/*     */       } else {
/* 417 */         matched = (ch == pch);
/* 418 */         startChar = pch;
/*     */       } 
/*     */     } 
/*     */     
/* 422 */     return (matched != negate);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String scanBoolean() {
/* 431 */     String token = "";
/* 432 */     String match = "";
/* 433 */     int ch = read();
/* 434 */     save(ch);
/* 435 */     switch (ch) { case 84: case 116:
/* 436 */         match = "true"; break;
/* 437 */       case 70: case 102: match = "false"; break;
/* 438 */       default: return null; }
/*     */     
/* 440 */     for (int i = 0; i < match.length(); i++) {
/* 441 */       ch = read();
/* 442 */       if (ch == -1 || Character.toLowerCase((char)ch) != match.charAt(i)) {
/* 443 */         save(ch);
/* 444 */         save(token);
/* 445 */         return null;
/*     */       } 
/* 447 */       token = String.valueOf(token) + (char)ch;
/*     */     } 
/* 449 */     return token;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String scanInt() {
/* 457 */     int ch = 0;
/* 458 */     String token = "";
/* 459 */     boolean valid = false;
/* 460 */     while ((ch = read()) != -1) {
/* 461 */       if ((ch == 45 || ch == 43) && token.length() == 0) {
/* 462 */         token = String.valueOf(token) + (char)ch; continue;
/* 463 */       }  if (isLegalDigit(ch, this.radix)) {
/* 464 */         token = String.valueOf(token) + (char)ch;
/* 465 */         valid = true;
/*     */         continue;
/*     */       } 
/*     */       break;
/*     */     } 
/* 470 */     save(ch);
/* 471 */     if (valid) return token; 
/* 472 */     save(token);
/* 473 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String scanDouble() { // Byte code:
/*     */     //   0: iconst_0
/*     */     //   1: istore_1
/*     */     //   2: ldc ''
/*     */     //   4: astore_2
/*     */     //   5: ldc ''
/*     */     //   7: astore_3
/*     */     //   8: iconst_0
/*     */     //   9: istore #4
/*     */     //   11: iconst_0
/*     */     //   12: istore #5
/*     */     //   14: goto -> 133
/*     */     //   17: iload_1
/*     */     //   18: bipush #45
/*     */     //   20: if_icmpeq -> 29
/*     */     //   23: iload_1
/*     */     //   24: bipush #43
/*     */     //   26: if_icmpne -> 59
/*     */     //   29: aload_2
/*     */     //   30: invokevirtual length : ()I
/*     */     //   33: ifne -> 59
/*     */     //   36: new java/lang/StringBuffer
/*     */     //   39: dup
/*     */     //   40: aload_2
/*     */     //   41: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   44: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   47: iload_1
/*     */     //   48: i2c
/*     */     //   49: invokevirtual append : (C)Ljava/lang/StringBuffer;
/*     */     //   52: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   55: astore_2
/*     */     //   56: goto -> 133
/*     */     //   59: iload_1
/*     */     //   60: bipush #46
/*     */     //   62: if_icmpne -> 96
/*     */     //   65: iload #5
/*     */     //   67: ifne -> 96
/*     */     //   70: new java/lang/StringBuffer
/*     */     //   73: dup
/*     */     //   74: aload_2
/*     */     //   75: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   78: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   81: iload_1
/*     */     //   82: i2c
/*     */     //   83: invokevirtual append : (C)Ljava/lang/StringBuffer;
/*     */     //   86: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   89: astore_2
/*     */     //   90: iconst_1
/*     */     //   91: istore #5
/*     */     //   93: goto -> 133
/*     */     //   96: iload_1
/*     */     //   97: i2c
/*     */     //   98: invokestatic isDigit : (C)Z
/*     */     //   101: ifeq -> 143
/*     */     //   104: new java/lang/StringBuffer
/*     */     //   107: dup
/*     */     //   108: aload_2
/*     */     //   109: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   112: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   115: iload_1
/*     */     //   116: i2c
/*     */     //   117: invokevirtual append : (C)Ljava/lang/StringBuffer;
/*     */     //   120: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   123: astore_2
/*     */     //   124: iconst_1
/*     */     //   125: istore #4
/*     */     //   127: goto -> 133
/*     */     //   130: goto -> 143
/*     */     //   133: aload_0
/*     */     //   134: invokespecial read : ()I
/*     */     //   137: dup
/*     */     //   138: istore_1
/*     */     //   139: iconst_m1
/*     */     //   140: if_icmpne -> 17
/*     */     //   143: iload #4
/*     */     //   145: ifne -> 160
/*     */     //   148: aload_0
/*     */     //   149: iload_1
/*     */     //   150: invokespecial save : (I)V
/*     */     //   153: aload_0
/*     */     //   154: aload_2
/*     */     //   155: invokespecial save : (Ljava/lang/String;)V
/*     */     //   158: aconst_null
/*     */     //   159: areturn
/*     */     //   160: iload_1
/*     */     //   161: bipush #101
/*     */     //   163: if_icmpeq -> 179
/*     */     //   166: iload_1
/*     */     //   167: bipush #69
/*     */     //   169: if_icmpeq -> 179
/*     */     //   172: aload_0
/*     */     //   173: iload_1
/*     */     //   174: invokespecial save : (I)V
/*     */     //   177: aload_2
/*     */     //   178: areturn
/*     */     //   179: new java/lang/StringBuffer
/*     */     //   182: dup
/*     */     //   183: invokespecial <init> : ()V
/*     */     //   186: iload_1
/*     */     //   187: i2c
/*     */     //   188: invokevirtual append : (C)Ljava/lang/StringBuffer;
/*     */     //   191: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   194: astore_3
/*     */     //   195: iconst_0
/*     */     //   196: istore #4
/*     */     //   198: goto -> 281
/*     */     //   201: iload_1
/*     */     //   202: bipush #45
/*     */     //   204: if_icmpeq -> 213
/*     */     //   207: iload_1
/*     */     //   208: bipush #43
/*     */     //   210: if_icmpne -> 244
/*     */     //   213: aload_3
/*     */     //   214: invokevirtual length : ()I
/*     */     //   217: iconst_1
/*     */     //   218: if_icmpne -> 244
/*     */     //   221: new java/lang/StringBuffer
/*     */     //   224: dup
/*     */     //   225: aload_3
/*     */     //   226: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   229: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   232: iload_1
/*     */     //   233: i2c
/*     */     //   234: invokevirtual append : (C)Ljava/lang/StringBuffer;
/*     */     //   237: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   240: astore_3
/*     */     //   241: goto -> 281
/*     */     //   244: iload_1
/*     */     //   245: i2c
/*     */     //   246: invokestatic isDigit : (C)Z
/*     */     //   249: ifeq -> 291
/*     */     //   252: new java/lang/StringBuffer
/*     */     //   255: dup
/*     */     //   256: aload_3
/*     */     //   257: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   260: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   263: iload_1
/*     */     //   264: i2c
/*     */     //   265: invokevirtual append : (C)Ljava/lang/StringBuffer;
/*     */     //   268: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   271: astore_3
/*     */     //   272: iconst_1
/*     */     //   273: istore #4
/*     */     //   275: goto -> 281
/*     */     //   278: goto -> 291
/*     */     //   281: aload_0
/*     */     //   282: invokespecial read : ()I
/*     */     //   285: dup
/*     */     //   286: istore_1
/*     */     //   287: iconst_m1
/*     */     //   288: if_icmpne -> 201
/*     */     //   291: aload_0
/*     */     //   292: iload_1
/*     */     //   293: invokespecial save : (I)V
/*     */     //   296: iload #4
/*     */     //   298: ifeq -> 323
/*     */     //   301: new java/lang/StringBuffer
/*     */     //   304: dup
/*     */     //   305: aload_2
/*     */     //   306: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   309: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   312: aload_3
/*     */     //   313: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*     */     //   316: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   319: astore_2
/*     */     //   320: goto -> 328
/*     */     //   323: aload_0
/*     */     //   324: aload_3
/*     */     //   325: invokespecial save : (Ljava/lang/String;)V
/*     */     //   328: aload_2
/*     */     //   329: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #481	-> 0
/*     */     //   #482	-> 2
/*     */     //   #483	-> 5
/*     */     //   #484	-> 8
/*     */     //   #485	-> 11
/*     */     //   #486	-> 14
/*     */     //   #487	-> 17
/*     */     //   #488	-> 36
/*     */     //   #489	-> 59
/*     */     //   #490	-> 70
/*     */     //   #491	-> 90
/*     */     //   #492	-> 96
/*     */     //   #493	-> 104
/*     */     //   #494	-> 124
/*     */     //   #496	-> 130
/*     */     //   #486	-> 133
/*     */     //   #499	-> 143
/*     */     //   #500	-> 148
/*     */     //   #501	-> 153
/*     */     //   #502	-> 158
/*     */     //   #504	-> 160
/*     */     //   #505	-> 172
/*     */     //   #506	-> 177
/*     */     //   #508	-> 179
/*     */     //   #509	-> 195
/*     */     //   #510	-> 198
/*     */     //   #511	-> 201
/*     */     //   #512	-> 221
/*     */     //   #513	-> 244
/*     */     //   #514	-> 252
/*     */     //   #515	-> 272
/*     */     //   #517	-> 278
/*     */     //   #510	-> 281
/*     */     //   #520	-> 291
/*     */     //   #521	-> 296
/*     */     //   #522	-> 301
/*     */     //   #524	-> 323
/*     */     //   #526	-> 328
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	330	0	this	Lacm/util/Scanner;
/*     */     //   2	328	1	ch	I
/*     */     //   5	325	2	token	Ljava/lang/String;
/*     */     //   8	322	3	exp	Ljava/lang/String;
/*     */     //   11	319	4	valid	Z
/*     */     //   14	316	5	dotSeen	Z }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isLegalDigit(int ch, int radix) {
/* 535 */     if (ch == -1) return false; 
/* 536 */     int index = "0123456789abcdefghijklmnopqrstuvwxyz".indexOf(Character.toLowerCase((char)ch));
/* 537 */     return (index >= 0 && index < radix);
/*     */   }
/*     */ }


/* Location:              /root/karel.jar!/acm/util/Scanner.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */