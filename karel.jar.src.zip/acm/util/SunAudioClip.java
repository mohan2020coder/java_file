/*     */ package acm.util;
/*     */ 
/*     */ import java.applet.AudioClip;
/*     */ import java.io.InputStream;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SunAudioClip
/*     */   implements AudioClip
/*     */ {
/*     */   private static boolean initialized;
/*     */   private static Class audioPlayerClass;
/*     */   private static Class audioStreamClass;
/*     */   private static Class audioDataClass;
/*     */   private static Class audioDataStreamClass;
/*     */   private static Class continuousAudioDataStreamClass;
/*     */   private static Constructor audioDataConstructor;
/*     */   private static Constructor audioDataStreamConstructor;
/*     */   private static Constructor continuousAudioDataStreamConstructor;
/*     */   private static Method getData;
/*     */   private Object player;
/*     */   private Object audioData;
/*     */   private Object audioDataStream;
/*     */   private Object continuousAudioDataStream;
/*     */   private Method audioPlayerStart;
/*     */   private Method audioPlayerStop;
/*     */   
/*     */   public SunAudioClip(InputStream in) {
/* 570 */     if (!initialized) {
/* 571 */       initStaticData();
/* 572 */       initialized = true;
/*     */     } 
/*     */     try {
/* 575 */       Object[] args = { in };
/* 576 */       Object audioStream = audioDataConstructor.newInstance(args);
/* 577 */       this.audioData = getData.invoke(audioStream, new Object[0]);
/* 578 */       this.player = audioPlayerClass.getField("player").get(null);
/* 579 */       Class[] inputStreamTypes = { Class.forName("java.io.InputStream") };
/* 580 */       this.audioPlayerStart = this.player.getClass().getMethod("start", inputStreamTypes);
/* 581 */       this.audioPlayerStop = this.player.getClass().getMethod("stop", inputStreamTypes);
/* 582 */     } catch (Exception ex) {
/* 583 */       throw new RuntimeException("Error: " + ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void play() {
/*     */     try {
/* 589 */       Object[] args = { this.audioData };
/* 590 */       this.audioDataStream = audioDataStreamConstructor.newInstance(args);
/* 591 */       args[0] = this.audioDataStream;
/* 592 */       this.audioPlayerStart.invoke(this.player, args);
/* 593 */     } catch (Exception ex) {
/* 594 */       throw new RuntimeException("Error: " + ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void loop() {
/*     */     try {
/* 600 */       Object[] args = { this.audioData };
/* 601 */       this.continuousAudioDataStream = continuousAudioDataStreamConstructor.newInstance(args);
/* 602 */       args[0] = this.continuousAudioDataStream;
/* 603 */       this.audioPlayerStart.invoke(this.player, args);
/* 604 */     } catch (Exception ex) {
/* 605 */       throw new RuntimeException("Error: " + ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void stop() {
/*     */     try {
/* 611 */       Object[] args = new Object[1];
/* 612 */       if (this.continuousAudioDataStream != null) {
/* 613 */         args[0] = this.audioDataStream;
/* 614 */         this.audioPlayerStop.invoke(this.player, args);
/*     */       } 
/* 616 */       if (this.audioDataStream != null) {
/* 617 */         args[0] = this.continuousAudioDataStream;
/* 618 */         this.audioPlayerStop.invoke(this.player, args);
/*     */       } 
/* 620 */     } catch (Exception ex) {
/* 621 */       throw new RuntimeException("Error: " + ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void initStaticData() {
/*     */     try {
/* 627 */       audioPlayerClass = Class.forName("sun.audio.AudioPlayer");
/* 628 */       audioStreamClass = Class.forName("sun.audio.AudioStream");
/* 629 */       audioDataClass = Class.forName("sun.audio.AudioData");
/* 630 */       audioDataStreamClass = Class.forName("sun.audio.AudioDataStream");
/* 631 */       continuousAudioDataStreamClass = Class.forName("sun.audio.ContinuousAudioDataStream");
/* 632 */       inputStreamTypes = new Class[] { Class.forName("java.io.InputStream") };
/* 633 */       audioDataConstructor = audioStreamClass.getConstructor(inputStreamTypes);
/* 634 */       getData = audioStreamClass.getMethod("getData", new Class[0]);
/* 635 */       Class[] audioDataTypes = { audioDataClass };
/* 636 */       audioDataStreamConstructor = audioDataStreamClass.getConstructor(audioDataTypes);
/* 637 */       continuousAudioDataStreamConstructor = continuousAudioDataStreamClass.getConstructor(audioDataTypes);
/* 638 */     } catch (Exception ex) {
/* 639 */       throw new RuntimeException("Error: " + ex);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /root/karel.jar!/acm/util/SunAudioClip.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */