package acm.util;

import java.awt.Component;

class TrackerComponent extends Component {}


/* Location:              /root/karel.jar!/acm/util/TrackerComponent.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */