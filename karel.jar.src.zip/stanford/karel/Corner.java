package stanford.karel;

import java.awt.Color;

class Corner {
  public Color color;
  
  public boolean wallSouth;
  
  public boolean wallWest;
  
  public int nBeepers;
}


/* Location:              /root/karel.jar!/stanford/karel/Corner.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */