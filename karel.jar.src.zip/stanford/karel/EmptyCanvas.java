package stanford.karel;

import java.awt.Component;

class EmptyCanvas extends Component {}


/* Location:              /root/karel.jar!/stanford/karel/EmptyCanvas.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */