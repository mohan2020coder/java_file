/*    */ package stanford.karel;
/*    */ 
/*    */ import java.awt.Component;
/*    */ import java.awt.Panel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class HPanel
/*    */   extends Panel
/*    */ {
/* 35 */   public HPanel() { setLayout(new HVLayout(2)); }
/*    */ 
/*    */ 
/*    */   
/* 39 */   public Component add(String constraint) { return add(constraint, null); }
/*    */ 
/*    */ 
/*    */   
/* 43 */   public Component add(Component comp) { return add("", comp); }
/*    */ 
/*    */   
/*    */   public Component add(String constraint, Component comp) {
/* 47 */     if (comp == null) comp = new EmptyCanvas(); 
/* 48 */     return super.add(constraint, comp);
/*    */   }
/*    */ }


/* Location:              /root/karel.jar!/stanford/karel/HPanel.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */