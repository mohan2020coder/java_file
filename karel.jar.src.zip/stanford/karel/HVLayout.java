/*     */ package stanford.karel;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Insets;
/*     */ import java.awt.LayoutManager;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class HVLayout
/*     */   implements LayoutManager
/*     */ {
/*     */   public static final int DEFAULT_SPACE = 5;
/*     */   public static final int HORIZONTAL = 2;
/*     */   public static final int VERTICAL = 3;
/*     */   private static final int MINIMUM = 0;
/*     */   private static final int PREFERRED = 1;
/*     */   private static final int CENTER = 10;
/*     */   private static final int NORTH = 11;
/*     */   private static final int NORTHEAST = 12;
/*     */   private static final int EAST = 13;
/*     */   private static final int SOUTHEAST = 14;
/*     */   private static final int SOUTH = 15;
/*     */   private static final int SOUTHWEST = 16;
/*     */   private static final int WEST = 17;
/*     */   private static final int NORTHWEST = 18;
/*     */   private static final int NONE = 0;
/*     */   private static final int BOTH = 1;
/*     */   private int orientation;
/*     */   private Hashtable constraintTable;
/*     */   
/*     */   public HVLayout(int orientation) {
/*  72 */     this.orientation = orientation;
/*  73 */     this.constraintTable = new Hashtable();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addLayoutComponent(String constraints, Component comp) {
/*  87 */     synchronized (comp.getTreeLock()) {
/*  88 */       this.constraintTable.put(comp, new OptionTable(constraints.toLowerCase()));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 100 */   public void removeLayoutComponent(Component comp) { this.constraintTable.remove(comp); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dimension preferredLayoutSize(Container parent) {
/* 112 */     synchronized (parent.getTreeLock()) {
/* 113 */       return getContainerSize(parent, 1);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dimension minimumLayoutSize(Container parent) {
/* 126 */     synchronized (parent.getTreeLock()) {
/* 127 */       return getContainerSize(parent, 0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void layoutContainer(Container parent) {
/* 140 */     synchronized (parent.getTreeLock()) {
/* 141 */       int nComponents = parent.getComponentCount();
/* 142 */       Dimension psize = parent.getSize();
/* 143 */       Dimension tsize = preferredLayoutSize(parent);
/* 144 */       int nStretch = getStretchCount(parent);
/* 145 */       int extra = getExtraSpace(psize, tsize, nStretch);
/* 146 */       Point origin = new Point(0, 0);
/* 147 */       if (nStretch == 0) origin = getInitialOrigin(parent, psize, tsize); 
/* 148 */       for (int i = 0; i < nComponents; i++) {
/* 149 */         Component comp = parent.getComponent(i);
/* 150 */         OptionTable options = (OptionTable)this.constraintTable.get(comp);
/* 151 */         Dimension csize = getLayoutSize(comp, options, 1);
/* 152 */         Dimension lsize = applyStretching(getStretchOption(options), csize, psize, extra);
/* 153 */         Dimension vsize = applyStretching(1, csize, psize, extra);
/* 154 */         Rectangle bounds = getLayoutBounds(options, lsize, vsize, origin);
/* 155 */         comp.setBounds(bounds);
/* 156 */         if (this.orientation == 2) {
/* 157 */           origin.x += lsize.width;
/*     */         } else {
/* 159 */           origin.y += lsize.height;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Dimension getContainerSize(Container parent, int type) {
/* 176 */     Dimension result = new Dimension(0, 0);
/* 177 */     int nComponents = parent.getComponentCount();
/* 178 */     for (int i = 0; i < nComponents; i++) {
/* 179 */       Component comp = parent.getComponent(i);
/* 180 */       OptionTable options = (OptionTable)this.constraintTable.get(comp);
/* 181 */       Dimension size = getLayoutSize(comp, options, type);
/* 182 */       if (this.orientation == 2) {
/* 183 */         result.width += size.width;
/* 184 */         result.height = Math.max(result.height, size.height);
/*     */       } else {
/* 186 */         result.width = Math.max(result.width, size.width);
/* 187 */         result.height += size.height;
/*     */       } 
/*     */     } 
/* 190 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Dimension getLayoutSize(Component comp, OptionTable options, int type) {
/* 205 */     Dimension size = new Dimension(0, 0);
/* 206 */     if (type == 1) size = new Dimension(comp.getPreferredSize()); 
/* 207 */     size.width = options.getIntOption("width", size.width);
/* 208 */     size.height = options.getIntOption("height", size.height);
/* 209 */     size = limitSize(size, comp);
/* 210 */     Insets insets = getInsetOption(options);
/* 211 */     size.width += insets.left + insets.right;
/* 212 */     size.height += insets.top + insets.bottom;
/* 213 */     return size;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Dimension limitSize(Dimension size, Component comp) {
/* 225 */     Dimension minSize = comp.getMinimumSize();
/* 226 */     Dimension maxSize = comp.getMaximumSize();
/* 227 */     int width = Math.max(minSize.width, Math.min(size.width, maxSize.width));
/* 228 */     int height = Math.max(minSize.height, Math.min(size.height, maxSize.height));
/* 229 */     return new Dimension(width, height);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Insets getInsetOption(OptionTable options) {
/* 241 */     Insets insets = new Insets(0, 0, 0, 0);
/* 242 */     if (options.isSpecified("space"))
/* 243 */       switch (this.orientation) { case 2:
/* 244 */           insets.left = options.getIntOption("space"); break;
/* 245 */         case 3: insets.top = options.getIntOption("space");
/*     */           break; }
/*     */        
/* 248 */     if (options.isSpecified("left")) insets.left = options.getIntOption("left"); 
/* 249 */     if (options.isSpecified("right")) insets.right = options.getIntOption("right"); 
/* 250 */     if (options.isSpecified("top")) insets.top = options.getIntOption("top"); 
/* 251 */     if (options.isSpecified("bottom")) insets.bottom = options.getIntOption("bottom"); 
/* 252 */     return insets;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int getStretchOption(OptionTable options) {
/* 264 */     if (options.isSpecified("fill")) return this.orientation; 
/* 265 */     if (options.isSpecified("stretch")) {
/* 266 */       String value = options.getOption("stretch", "both");
/* 267 */       if (value.equals("none")) return 0; 
/* 268 */       if (value.equals("horizontal")) return 2; 
/* 269 */       if (value.equals("vertical")) return 3; 
/* 270 */       if (value.equals("both")) return 1; 
/*     */     } 
/* 272 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int getAnchorOption(OptionTable options) {
/* 285 */     int anchor = 10;
/* 286 */     if (options.isSpecified("anchor")) {
/* 287 */       String value = options.getOption("anchor", "northwest");
/* 288 */       if (value.equals("center")) {
/* 289 */         anchor = 10;
/* 290 */       } else if (value.equals("north")) {
/* 291 */         anchor = 11;
/* 292 */       } else if (value.equals("northeast") || value.equals("ne")) {
/* 293 */         anchor = 12;
/* 294 */       } else if (value.equals("east")) {
/* 295 */         anchor = 13;
/* 296 */       } else if (value.equals("southeast") || value.equals("se")) {
/* 297 */         anchor = 14;
/* 298 */       } else if (value.equals("south")) {
/* 299 */         anchor = 15;
/* 300 */       } else if (value.equals("southwest") || value.equals("sw")) {
/* 301 */         anchor = 16;
/* 302 */       } else if (value.equals("west")) {
/* 303 */         anchor = 17;
/* 304 */       } else if (value.equals("northwest") || value.equals("nw")) {
/* 305 */         anchor = 18;
/*     */       }
/*     */     
/* 308 */     } else if (options.isSpecified("center")) {
/* 309 */       anchor = 10;
/* 310 */     } else if (options.isSpecified("north")) {
/* 311 */       anchor = 11;
/* 312 */     } else if (options.isSpecified("northeast") || options.isSpecified("ne")) {
/* 313 */       anchor = 12;
/* 314 */     } else if (options.isSpecified("east")) {
/* 315 */       anchor = 13;
/* 316 */     } else if (options.isSpecified("southeast") || options.isSpecified("se")) {
/* 317 */       anchor = 14;
/* 318 */     } else if (options.isSpecified("south")) {
/* 319 */       anchor = 15;
/* 320 */     } else if (options.isSpecified("southwest") || options.isSpecified("sw")) {
/* 321 */       anchor = 16;
/* 322 */     } else if (options.isSpecified("west")) {
/* 323 */       anchor = 17;
/* 324 */     } else if (options.isSpecified("northwest") || options.isSpecified("nw")) {
/* 325 */       anchor = 18;
/*     */     } 
/*     */     
/* 328 */     return anchor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int getStretchCount(Container parent) {
/* 341 */     int nComponents = parent.getComponentCount();
/* 342 */     int nStretch = 0;
/* 343 */     for (int i = 0; i < nComponents; i++) {
/* 344 */       Component comp = parent.getComponent(i);
/* 345 */       OptionTable options = (OptionTable)this.constraintTable.get(comp);
/* 346 */       int stretch = getStretchOption(options);
/* 347 */       if (this.orientation == 2)
/* 348 */       { if (stretch == 2 || stretch == 1) nStretch++;
/*     */          }
/* 350 */       else if (stretch == 3 || stretch == 1) { nStretch++; }
/*     */     
/*     */     } 
/* 353 */     return nStretch;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int getExtraSpace(Dimension psize, Dimension tsize, int nStretch) {
/* 368 */     if (nStretch == 0) {
/* 369 */       return 0;
/*     */     }
/* 371 */     if (this.orientation == 2) {
/* 372 */       return (psize.width - tsize.width) / nStretch;
/*     */     }
/* 374 */     return (psize.height - tsize.height) / nStretch;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Dimension applyStretching(int stretch, Dimension csize, Dimension psize, int extra) {
/* 388 */     int width = csize.width;
/* 389 */     int height = csize.height;
/* 390 */     if (stretch == 2 || stretch == 1) {
/* 391 */       if (this.orientation == 2) {
/* 392 */         width += extra;
/*     */       } else {
/* 394 */         width = psize.width;
/*     */       } 
/*     */     }
/* 397 */     if (stretch == 3 || stretch == 1) {
/* 398 */       if (this.orientation == 3) {
/* 399 */         height += extra;
/*     */       } else {
/* 401 */         height = psize.height;
/*     */       } 
/*     */     }
/* 404 */     return new Dimension(width, height);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Rectangle getLayoutBounds(OptionTable options, Dimension lsize, Dimension vsize, Point origin) {
/* 417 */     Insets insets = getInsetOption(options);
/* 418 */     int anchor = getAnchorOption(options);
/* 419 */     int dx = insets.left;
/* 420 */     int dy = insets.top;
/* 421 */     int width = lsize.width - insets.left - insets.right;
/* 422 */     int height = lsize.height - insets.top - insets.bottom;
/* 423 */     if (this.orientation == 2) {
/* 424 */       switch (anchor) { case 11: case 12:
/*     */         case 18:
/* 426 */           dy = insets.top; break;
/*     */         case 10: case 13:
/*     */         case 17:
/* 429 */           dy = insets.top + (vsize.height - lsize.height) / 2; break;
/*     */         case 14: case 15:
/*     */         case 16:
/* 432 */           dy = vsize.height - insets.bottom - lsize.height;
/*     */           break; }
/*     */     
/*     */     } else {
/* 436 */       switch (anchor) { case 16: case 17:
/*     */         case 18:
/* 438 */           dx = insets.left; break;
/*     */         case 10: case 11:
/*     */         case 15:
/* 441 */           dx = insets.left + (vsize.width - lsize.width) / 2; break;
/*     */         case 12: case 13:
/*     */         case 14:
/* 444 */           dx = vsize.width - insets.right - lsize.width;
/*     */           break; }
/*     */     
/*     */     } 
/* 448 */     return new Rectangle(origin.x + dx, origin.y + dy, width, height);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Point getInitialOrigin(Container parent, Dimension psize, Dimension tsize) {
/* 462 */     int x = 0;
/* 463 */     int y = 0;
/* 464 */     if (parent.getComponentCount() > 0) {
/* 465 */       OptionTable options = (OptionTable)this.constraintTable.get(parent.getComponent(0));
/* 466 */       int anchor = getAnchorOption(options);
/* 467 */       if (this.orientation == 2) {
/* 468 */         switch (anchor) { case 16: case 17:
/*     */           case 18:
/* 470 */             x = 0; break;
/*     */           case 10: case 11:
/*     */           case 15:
/* 473 */             x = (psize.width - tsize.width) / 2; break;
/*     */           case 12: case 13:
/*     */           case 14:
/* 476 */             x = psize.width - tsize.width;
/*     */             break; }
/*     */       
/*     */       } else {
/* 480 */         switch (anchor) { case 11: case 12:
/*     */           case 18:
/* 482 */             y = 0; break;
/*     */           case 10: case 13:
/*     */           case 17:
/* 485 */             y = (psize.height - tsize.height) / 2; break;
/*     */           case 14: case 15:
/*     */           case 16:
/* 488 */             y = psize.height - tsize.height;
/*     */             break; }
/*     */       
/*     */       } 
/*     */     } 
/* 493 */     return new Point(x, y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String anchorName(int anchor) {
/* 504 */     switch (anchor) { case 10:
/* 505 */         return "CENTER";
/* 506 */       case 11: return "NORTH";
/* 507 */       case 12: return "NORTHEAST";
/* 508 */       case 13: return "EAST";
/* 509 */       case 14: return "SOUTHEAST";
/* 510 */       case 15: return "SOUTH";
/* 511 */       case 16: return "SOUTHWEST";
/* 512 */       case 17: return "WEST";
/* 513 */       case 18: return "NORTHWEST"; }
/* 514 */      return "undefined";
/*     */   }
/*     */ }


/* Location:              /root/karel.jar!/stanford/karel/HVLayout.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */