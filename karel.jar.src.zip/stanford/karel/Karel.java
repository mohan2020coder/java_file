/*     */ package stanford.karel;
/*     */ 
/*     */ import acm.util.ErrorException;
/*     */ import java.awt.Point;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Karel
/*     */   implements Runnable
/*     */ {
/*  63 */   private int x = 1;
/*  64 */   private int y = 1;
/*  65 */   private int dir = 1;
/*  66 */   private KarelWorld world = null;
/*     */   
/*     */   private static final int NORTH = 0;
/*     */   
/*     */   private static final int EAST = 1;
/*     */   private static final int SOUTH = 2;
/*     */   
/*     */   public void move() {
/*  74 */     checkWorld("move");
/*  75 */     if (this.world.checkWall(this.x, this.y, this.dir)) throw new ErrorException("Karel is blocked"); 
/*  76 */     setLocation(KarelWorld.adjacentPoint(this.x, this.y, this.dir));
/*  77 */     this.world.trace();
/*     */   } private static final int WEST = 3; private static final int INFINITE = 99999999; private int beepers;
/*     */   public void run() {}
/*     */   public void turnLeft() {
/*  81 */     checkWorld("turnLeft");
/*  82 */     setDirection(KarelWorld.leftFrom(this.dir));
/*  83 */     this.world.trace();
/*     */   }
/*     */   
/*     */   public void pickBeeper() {
/*  87 */     checkWorld("pickBeeper");
/*  88 */     int nb = this.world.getBeepersOnCorner(this.x, this.y);
/*  89 */     if (nb < 1) throw new ErrorException("pickBeeper: No beepers on this corner"); 
/*  90 */     this.world.setBeepersOnCorner(this.x, this.y, KarelWorld.adjustBeepers(nb, -1));
/*  91 */     setBeepersInBag(KarelWorld.adjustBeepers(getBeepersInBag(), 1));
/*  92 */     this.world.trace();
/*     */   }
/*     */   
/*     */   public void putBeeper() {
/*  96 */     checkWorld("putBeeper");
/*  97 */     int nb = getBeepersInBag();
/*  98 */     if (nb < 1) throw new ErrorException("putBeeper: No beepers in bag"); 
/*  99 */     this.world.setBeepersOnCorner(this.x, this.y, KarelWorld.adjustBeepers(this.world.getBeepersOnCorner(this.x, this.y), 1));
/* 100 */     setBeepersInBag(KarelWorld.adjustBeepers(nb, -1));
/* 101 */     this.world.trace();
/*     */   }
/*     */   
/*     */   public boolean frontIsClear() {
/* 105 */     checkWorld("frontIsClear");
/* 106 */     return !this.world.checkWall(this.x, this.y, this.dir);
/*     */   }
/*     */   
/*     */   public boolean frontIsBlocked() {
/* 110 */     checkWorld("frontIsBlocked");
/* 111 */     return this.world.checkWall(this.x, this.y, this.dir);
/*     */   }
/*     */   
/*     */   public boolean leftIsClear() {
/* 115 */     checkWorld("leftIsClear");
/* 116 */     return !this.world.checkWall(this.x, this.y, KarelWorld.leftFrom(this.dir));
/*     */   }
/*     */   
/*     */   public boolean leftIsBlocked() {
/* 120 */     checkWorld("leftIsBlocked");
/* 121 */     return this.world.checkWall(this.x, this.y, KarelWorld.leftFrom(this.dir));
/*     */   }
/*     */   
/*     */   public boolean rightIsClear() {
/* 125 */     checkWorld("rightIsClear");
/* 126 */     return !this.world.checkWall(this.x, this.y, KarelWorld.rightFrom(this.dir));
/*     */   }
/*     */   
/*     */   public boolean rightIsBlocked() {
/* 130 */     checkWorld("rightIsBlocked");
/* 131 */     return this.world.checkWall(this.x, this.y, KarelWorld.rightFrom(this.dir));
/*     */   }
/*     */   
/*     */   public boolean beepersPresent() {
/* 135 */     checkWorld("beepersPresent");
/* 136 */     return (this.world.getBeepersOnCorner(this.x, this.y) > 0);
/*     */   }
/*     */   
/*     */   public boolean noBeepersPresent() {
/* 140 */     checkWorld("noBeepersPresent");
/* 141 */     return (this.world.getBeepersOnCorner(this.x, this.y) == 0);
/*     */   }
/*     */   
/*     */   public boolean beepersInBag() {
/* 145 */     checkWorld("beepersInBag");
/* 146 */     return (getBeepersInBag() > 0);
/*     */   }
/*     */   
/*     */   public boolean noBeepersInBag() {
/* 150 */     checkWorld("noBeepersInBag");
/* 151 */     return (getBeepersInBag() == 0);
/*     */   }
/*     */   
/*     */   public boolean facingNorth() {
/* 155 */     checkWorld("facingNorth");
/* 156 */     return (this.dir == 0);
/*     */   }
/*     */   
/*     */   public boolean facingEast() {
/* 160 */     checkWorld("facingEast");
/* 161 */     return (this.dir == 1);
/*     */   }
/*     */   
/*     */   public boolean facingSouth() {
/* 165 */     checkWorld("facingSouth");
/* 166 */     return (this.dir == 2);
/*     */   }
/*     */   
/*     */   public boolean facingWest() {
/* 170 */     checkWorld("facingWest");
/* 171 */     return (this.dir == 3);
/*     */   }
/*     */   
/*     */   public boolean notFacingNorth() {
/* 175 */     checkWorld("notFacingNorth");
/* 176 */     return (this.dir != 0);
/*     */   }
/*     */   
/*     */   public boolean notFacingEast() {
/* 180 */     checkWorld("notFacingEast");
/* 181 */     return (this.dir != 1);
/*     */   }
/*     */   
/*     */   public boolean notFacingSouth() {
/* 185 */     checkWorld("notFacingSouth");
/* 186 */     return (this.dir != 2);
/*     */   }
/*     */   
/*     */   public boolean notFacingWest() {
/* 190 */     checkWorld("notFacingWest");
/* 191 */     return (this.dir != 3);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/* 197 */     String[] newArgs = new String[args.length + 1];
/* 198 */     for (int i = 0; i < args.length; i++) {
/* 199 */       newArgs[i] = args[i];
/*     */     }
/* 201 */     newArgs[args.length] = "program=stanford.karel.KarelProgram";
/* 202 */     KarelProgram.main(newArgs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 210 */   protected void start() { start(null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void start(String[] args) {
/* 219 */     KarelProgram program = new KarelProgram();
/* 220 */     program.setStartupObject(this);
/* 221 */     program.start(args);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 227 */   protected Point getLocation() { return new Point(this.x, this.y); }
/*     */ 
/*     */ 
/*     */   
/* 231 */   protected void setLocation(Point pt) { setLocation(pt.x, pt.y); }
/*     */ 
/*     */   
/*     */   protected void setLocation(int x, int y) {
/* 235 */     if (this.world != null) {
/* 236 */       if (this.world.outOfBounds(x, y)) throw new ErrorException("setLocation: Out of bounds"); 
/* 237 */       Karel occupant = this.world.getKarelOnSquare(x, y);
/* 238 */       if (occupant == this)
/* 239 */         return;  if (occupant != null) throw new ErrorException("setLocation: Square is already occupied"); 
/*     */     } 
/* 241 */     int x0 = this.x;
/* 242 */     int y0 = this.y;
/* 243 */     this.x = x;
/* 244 */     this.y = y;
/* 245 */     if (this.world != null) {
/* 246 */       this.world.updateCorner(x, y);
/* 247 */       this.world.updateCorner(x0, y0);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/* 252 */   protected int getDirection() { return this.dir; }
/*     */ 
/*     */   
/*     */   protected void setDirection(int dir) {
/* 256 */     this.dir = dir;
/* 257 */     if (this.world != null) this.world.updateCorner(this.x, this.y);
/*     */   
/*     */   }
/*     */   
/* 261 */   protected int getBeepersInBag() { return this.beepers; }
/*     */ 
/*     */ 
/*     */   
/* 265 */   protected void setBeepersInBag(int nBeepers) { this.beepers = nBeepers; }
/*     */ 
/*     */ 
/*     */   
/* 269 */   protected KarelWorld getWorld() { return this.world; }
/*     */ 
/*     */ 
/*     */   
/* 273 */   protected void setWorld(KarelWorld world) { this.world = world; }
/*     */ 
/*     */ 
/*     */   
/* 277 */   protected void checkWorld(String caller) { if (this.world == null) throw new ErrorException(String.valueOf(caller) + ": Karel is not living in a world");  }
/*     */ }


/* Location:              /root/karel.jar!/stanford/karel/Karel.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */