/*     */ package stanford.karel;
/*     */ 
/*     */ class KarelControlPanel extends CardPanel implements KarelWorldMonitor, ActionListener, AdjustmentListener {
/*     */   private static final int BUTTON_WIDTH = 100;
/*     */   private static final int BUTTON_HEIGHT = 18;
/*     */   private static final int BUTTON_SEP = 8;
/*     */   private static final int SPEEDBAR_WIDTH = 100;
/*     */   private static final int MAX_WIDTH = 50;
/*     */   private static final int MAX_HEIGHT = 50;
/*     */   private static final int SMALL_BUTTON_WIDTH = 60;
/*     */   private static final int MARGIN = 8;
/*     */   private static final int GAP = 5;
/*     */   private static final double SLOW_DELAY = 200.0D;
/*     */   private static final double FAST_DELAY = 0.0D;
/*     */   private KarelProgram program;
/*     */   private KarelWorld world;
/*     */   private KarelWorldEditor editor;
/*     */   
/*     */   public KarelControlPanel(KarelProgram program) {
/*  20 */     this.program = program;
/*  21 */     this.world = program.getWorld();
/*  22 */     this.editor = createEditor();
/*  23 */     this.resizer = createResizer();
/*  24 */     this.editorPanel = createEditorPanel();
/*  25 */     add("editor", this.editorPanel);
/*  26 */     this.resizePanel = createResizePanel();
/*  27 */     add("resize", this.resizePanel);
/*  28 */     this.buttonPanel = createButtonPanel();
/*  29 */     add("buttons", this.buttonPanel);
/*  30 */     setView("buttons");
/*     */   }
/*     */   private KarelResizer resizer; private Component buttonPanel; private Component editorPanel; private Component resizePanel; private Button startButton; private Button loadWorldButton; private Button newWorldButton; private Button editWorldButton; private Button saveWorldButton; private Button dontSaveButton; private Button okButton; private Button cancelButton; private Scrollbar speedBar; private double speed;
/*     */   
/*  34 */   public KarelWorld getWorld() { return this.world; }
/*     */ 
/*     */ 
/*     */   
/*  38 */   public KarelProgram getProgram() { return this.program; }
/*     */ 
/*     */ 
/*     */   
/*  42 */   public KarelWorldEditor getEditor() { return this.editor; }
/*     */ 
/*     */ 
/*     */   
/*  46 */   public KarelResizer getResizer() { return this.resizer; }
/*     */ 
/*     */ 
/*     */   
/*  50 */   public Dimension getPreferredSize() { return new Dimension(250, 1); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startWorldEdit() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void endWorldEdit() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  74 */   public void wallAction(Point pt, int dir) { this.editor.wallAction(pt, dir); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  83 */   public void cornerAction(Point pt) { this.editor.cornerAction(pt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void trace() {
/*  91 */     double delay = 200.0D + Math.sqrt(this.speed) * -200.0D;
/*  92 */     if (this.speed < 0.98D) Program.pause(delay);
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSpeed(double speed) {
/* 101 */     this.speed = speed;
/* 102 */     this.speedBar.setValue((int)Math.round(100.0D * speed));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 111 */   public double getSpeed() { return this.speed; }
/*     */ 
/*     */ 
/*     */   
/* 115 */   protected KarelWorldEditor createEditor() { return new KarelWorldEditor(getWorld()); }
/*     */ 
/*     */   
/*     */   protected Component createEditorPanel() {
/* 119 */     VPanel vbox = new VPanel();
/* 120 */     vbox.add("", this.editor);
/* 121 */     this.saveWorldButton = new Button("Save World");
/* 122 */     this.saveWorldButton.addActionListener(this);
/* 123 */     vbox.add("/width:100/height:18/top:8", this.saveWorldButton);
/* 124 */     this.dontSaveButton = new Button("Don't Save");
/* 125 */     this.dontSaveButton.addActionListener(this);
/* 126 */     vbox.add("/width:100/height:18/top:8", this.dontSaveButton);
/* 127 */     return vbox;
/*     */   }
/*     */   
/*     */   protected Component createButtonPanel() {
/* 131 */     VPanel vbox = new VPanel();
/* 132 */     this.startButton = new Button("Start Program");
/* 133 */     this.startButton.addActionListener(this);
/* 134 */     vbox.add("/center/width:100/height:18", this.startButton);
/* 135 */     this.loadWorldButton = new Button("Load World");
/* 136 */     this.loadWorldButton.addActionListener(this);
/* 137 */     vbox.add("/center/width:100/height:18/top:8", this.loadWorldButton);
/* 138 */     this.newWorldButton = new Button("New World");
/* 139 */     this.newWorldButton.addActionListener(this);
/* 140 */     vbox.add("/center/width:100/height:18/top:8", this.newWorldButton);
/* 141 */     this.editWorldButton = new Button("Edit World");
/* 142 */     this.editWorldButton.addActionListener(this);
/* 143 */     vbox.add("/center/width:100/height:18/top:8", this.editWorldButton);
/* 144 */     HPanel hbox = new HPanel();
/* 145 */     this.speedBar = new Scrollbar(0);
/* 146 */     this.speedBar.addAdjustmentListener(this);
/* 147 */     this.speedBar.setBlockIncrement(10);
/* 148 */     this.speedBar.setValues(0, 1, 0, 100);
/* 149 */     hbox.add("/center", new Label("Slow "));
/* 150 */     hbox.add("/center/width:100", this.speedBar);
/* 151 */     hbox.add("/center", new Label(" Fast"));
/* 152 */     vbox.add("/center/top:8", hbox);
/* 153 */     return vbox;
/*     */   }
/*     */   
/*     */   protected Component createResizePanel() {
/* 157 */     VPanel vbox = new VPanel();
/* 158 */     this.cancelButton = new Button("Cancel");
/* 159 */     this.cancelButton.addActionListener(this);
/* 160 */     this.okButton = new Button("OK");
/* 161 */     this.okButton.addActionListener(this);
/* 162 */     vbox.add("", getResizer());
/* 163 */     vbox.add("/center/width:60/space:5", this.okButton);
/* 164 */     vbox.add("/center/width:60/space:5", this.cancelButton);
/* 165 */     return vbox;
/*     */   }
/*     */ 
/*     */   
/* 169 */   protected KarelResizer createResizer() { return new KarelResizer(); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void actionPerformed(ActionEvent e) {
/* 175 */     Component source = (Component)e.getSource();
/* 176 */     if (source == this.startButton) {
/* 177 */       this.program.signalStarted();
/* 178 */     } else if (source == this.loadWorldButton) {
/* 179 */       FileDialog dialog = new LoadWorldDialog(this.world);
/* 180 */       dialog.setVisible(true);
/* 181 */       String fileName = dialog.getFile();
/* 182 */       if (fileName != null) this.world.load(String.valueOf(dialog.getDirectory()) + "/" + fileName); 
/* 183 */     } else if (source == this.newWorldButton) {
/* 184 */       setView("resize");
/* 185 */     } else if (source == this.editWorldButton) {
/* 186 */       this.world.setEditMode(true);
/* 187 */       this.editor.initEditorCanvas();
/* 188 */       setView("editor");
/* 189 */     } else if (source == this.saveWorldButton) {
/* 190 */       if (this.world.getPathname() == null) {
/* 191 */         FileDialog dialog = new NewWorldDialog(this.world);
/* 192 */         dialog.setVisible(true);
/* 193 */         String fileName = dialog.getFile();
/* 194 */         if (fileName != null) this.world.setPathName(String.valueOf(dialog.getDirectory()) + "/" + fileName); 
/*     */       } 
/* 196 */       this.world.save();
/* 197 */       this.world.setEditMode(false);
/* 198 */       setView("buttons");
/* 199 */     } else if (source == this.dontSaveButton) {
/* 200 */       this.world.setEditMode(false);
/* 201 */       setView("buttons");
/* 202 */     } else if (source == this.cancelButton) {
/* 203 */       setView("buttons");
/* 204 */     } else if (source == this.okButton) {
/* 205 */       FileDialog dialog = new NewWorldDialog(this.world);
/* 206 */       dialog.setVisible(true);
/* 207 */       String fileName = dialog.getFile();
/* 208 */       if (fileName == null) {
/* 209 */         setView("buttons");
/*     */       } else {
/* 211 */         this.world.init(this.resizer.getColumns(), this.resizer.getRows());
/* 212 */         this.world.setPathName(String.valueOf(dialog.getDirectory()) + "/" + fileName);
/* 213 */         this.world.setEditMode(true);
/* 214 */         if (this.world.getKarelCount() == 1) {
/* 215 */           Karel karel = this.world.getKarel();
/* 216 */           karel.setLocation(1, 1);
/* 217 */           karel.setDirection(1);
/* 218 */           karel.setBeepersInBag(99999999);
/* 219 */           this.world.repaint();
/*     */         } 
/* 221 */         this.editor.initEditorCanvas();
/* 222 */         setView("editor");
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void adjustmentValueChanged(AdjustmentEvent e) {
/* 230 */     Component source = (Component)e.getSource();
/* 231 */     if (source == this.speedBar)
/* 232 */       this.speed = this.speedBar.getValue() / 100.0D; 
/*     */   }
/*     */ }


/* Location:              /root/karel.jar!/stanford/karel/KarelControlPanel.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */