/*     */ package stanford.karel;
/*     */ 
/*     */ import acm.util.Platform;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Button;
/*     */ import java.awt.Canvas;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dialog;
/*     */ import java.awt.Font;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.WindowEvent;
/*     */ import java.awt.event.WindowListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class KarelErrorDialog
/*     */   extends Dialog
/*     */   implements WindowListener, ActionListener
/*     */ {
/*     */   private static final int DIALOG_WIDTH = 330;
/*     */   private static final int DIALOG_HEIGHT = 170;
/*     */   private static final int LOGO_WIDTH = 100;
/*     */   private static final int LOGO_HEIGHT = 100;
/*     */   private static final int BUTTON_WIDTH = 60;
/*     */   
/*     */   public KarelErrorDialog(KarelProgram program) {
/* 295 */     super(Platform.getEnclosingFrame(program.getWorld()), true);
/* 296 */     setLayout(new BorderLayout());
/* 297 */     this.program = program;
/* 298 */     init();
/*     */   }
/*     */   
/*     */   private void init() {
/* 302 */     setSize(330, 170);
/* 303 */     setFont(DIALOG_FONT);
/* 304 */     setBackground(DIALOG_BGCOLOR);
/* 305 */     setResizable(false);
/* 306 */     addWindowListener(this);
/* 307 */     setLayout(new BorderLayout());
/* 308 */     HPanel hbox = new HPanel();
/* 309 */     VPanel vbox = new VPanel();
/* 310 */     this.bugIcon = new KarelBugIcon();
/* 311 */     this.okButton = new Button("OK");
/* 312 */     this.okButton.addActionListener(this);
/* 313 */     this.errorDisplay = new KarelErrorCanvas();
/* 314 */     this.errorDisplay.setFont(DIALOG_FONT);
/* 315 */     hbox.add("/width:100/height:100", this.bugIcon);
/* 316 */     hbox.add("/stretch:both", this.errorDisplay);
/* 317 */     vbox.add("/stretch:both", hbox);
/* 318 */     vbox.add("/top:3/bottom:3/width:60/center", this.okButton);
/* 319 */     add("Center", vbox);
/* 320 */     validate();
/*     */   }
/*     */   
/*     */   public void error(String msg) {
/* 324 */     this.errorDisplay.setText(msg);
/* 325 */     setVisible(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 331 */   public void windowClosing(WindowEvent e) { setVisible(false); }
/*     */ 
/*     */   
/*     */   public void windowOpened(WindowEvent e) {}
/*     */ 
/*     */   
/*     */   public void windowClosed(WindowEvent e) {}
/*     */ 
/*     */   
/*     */   public void windowIconified(WindowEvent e) {}
/*     */ 
/*     */   
/*     */   public void actionPerformed(ActionEvent e) {
/* 344 */     Component source = (Component)e.getSource();
/* 345 */     if (source == this.okButton) windowClosing(null);
/*     */   
/*     */   }
/*     */   
/*     */   public void windowDeiconified(WindowEvent e) {}
/*     */   
/*     */   public void windowActivated(WindowEvent e) {}
/*     */   
/*     */   public void windowDeactivated(WindowEvent e) {}
/*     */   
/* 355 */   private static final Font DIALOG_FONT = new Font("Dialog", 0, 12);
/* 356 */   private static final Color DIALOG_BGCOLOR = Color.red;
/*     */   private KarelProgram program;
/*     */   private Canvas bugIcon;
/*     */   private Button okButton;
/*     */   private KarelErrorCanvas errorDisplay;
/*     */ }


/* Location:              /root/karel.jar!/stanford/karel/KarelErrorDialog.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */