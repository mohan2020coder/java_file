/*     */ package stanford.karel;
/*     */ 
/*     */ import acm.program.Program;
/*     */ import acm.util.AppletMenuBar;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.io.File;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class KarelProgram
/*     */   extends Program
/*     */ {
/*     */   public static final int NORTH = 0;
/*     */   public static final int EAST = 1;
/*     */   public static final int SOUTH = 2;
/*     */   public static final int WEST = 3;
/*     */   public static final int INFINITE = 99999999;
/*     */   public static final int SIMPLE = 0;
/*     */   public static final int FANCY = 1;
/*  33 */   public static final Color BLACK = Color.black;
/*  34 */   public static final Color BLUE = Color.blue;
/*  35 */   public static final Color CYAN = Color.cyan;
/*  36 */   public static final Color DARK_GRAY = Color.darkGray;
/*  37 */   public static final Color GRAY = Color.gray;
/*  38 */   public static final Color GREEN = Color.green;
/*  39 */   public static final Color LIGHT_GRAY = Color.lightGray;
/*  40 */   public static final Color MAGENTA = Color.magenta;
/*  41 */   public static final Color ORANGE = Color.orange;
/*  42 */   public static final Color PINK = Color.pink;
/*  43 */   public static final Color RED = Color.red;
/*  44 */   public static final Color WHITE = Color.white;
/*  45 */   public static final Color YELLOW = Color.yellow;
/*     */   
/*     */   private KarelWorld world;
/*     */   private KarelControlPanel controlPanel;
/*     */   private KarelErrorDialog errorDialog;
/*     */   private AppletMenuBar menuBar;
/*     */   private boolean started;
/*     */   
/*     */   public KarelProgram() {
/*  54 */     this.world = createWorld();
/*  55 */     this.world.setRepaintFlag(false);
/*  56 */     this.world.init(10, 10);
/*  57 */     setLayout(new BorderLayout());
/*  58 */     add("Center", this.world);
/*  59 */     this.controlPanel = new KarelControlPanel(this);
/*  60 */     this.world.setMonitor(this.controlPanel);
/*  61 */     add("West", this.controlPanel);
/*  62 */     validate();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void main() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  84 */   public KarelWorld getWorld() { return this.world; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getWorldDirectory() {
/*  95 */     dir = System.getProperty("user.dir");
/*  96 */     if ((new File(dir, "worlds")).isDirectory()) {
/*  97 */       dir = String.valueOf(dir) + "/worlds";
/*     */     }
/*  99 */     return dir;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 112 */   protected KarelWorld createWorld() { return new KarelWorld(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isStarted() {
/* 121 */     if (this.world == null || !super.isStarted()) return false; 
/* 122 */     Dimension size = this.world.getSize();
/* 123 */     if (size == null || size.width == 0 || size.height == 0) return false; 
/* 124 */     return true;
/*     */   }
/*     */ 
/*     */   
/* 128 */   protected Karel getKarel() { return this.world.getKarel(); }
/*     */ 
/*     */ 
/*     */   
/* 132 */   public void add(Karel karel) { add(karel, 1, 1, 1, 99999999); }
/*     */ 
/*     */   
/*     */   public void add(Karel karel, int x, int y, int dir, int nBeepers) {
/* 136 */     karel.setLocation(x, y);
/* 137 */     karel.setDirection(dir);
/* 138 */     karel.setBeepersInBag(nBeepers);
/* 139 */     this.world.add(karel);
/*     */   }
/*     */ 
/*     */   
/* 143 */   protected void setStartupObject(Object obj) { super.setStartupObject(obj); }
/*     */ 
/*     */ 
/*     */   
/* 147 */   protected void start(String[] args) { super.start(args); }
/*     */ 
/*     */   
/*     */   protected void startRun() {
/* 151 */     this.menuBar = createMenuBar();
/* 152 */     this.menuBar.installInFrame(this.world);
/* 153 */     Karel karel = (Karel)getStartupObject();
/* 154 */     if (karel != null) {
/* 155 */       String className = karel.getClass().getName();
/* 156 */       className = className.substring(className.lastIndexOf(".") + 1);
/* 157 */       this.world.add(karel);
/* 158 */       setTitle(className);
/*     */       try {
/* 160 */         File worldFile = new File(getWorldDirectory(), String.valueOf(className) + ".w");
/* 161 */         if (worldFile.canRead()) this.world.load(worldFile); 
/* 162 */       } catch (Exception exception) {}
/*     */     } 
/*     */ 
/*     */     
/* 166 */     this.world.setRepaintFlag(true);
/* 167 */     this.world.repaint();
/*     */     while (true) {
/* 169 */       this.started = false;
/* 170 */       synchronized (this) {
/* 171 */         while (!this.started) {
/*     */           try {
/* 173 */             wait();
/* 174 */           } catch (InterruptedException interruptedException) {}
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/*     */       try {
/* 180 */         if (karel == null) {
/* 181 */           main(); continue;
/*     */         } 
/* 183 */         karel.run();
/*     */       }
/* 185 */       catch (Exception ex) {
/* 186 */         if (this.errorDialog == null) this.errorDialog = new KarelErrorDialog(this); 
/* 187 */         this.errorDialog.error(ex.getMessage());
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   void signalStarted() {
/* 193 */     synchronized (this) {
/* 194 */       this.started = true;
/* 195 */       notifyAll();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 208 */   protected AppletMenuBar createMenuBar() { return new KarelMenuBar(this.world); }
/*     */ }


/* Location:              /root/karel.jar!/stanford/karel/KarelProgram.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */