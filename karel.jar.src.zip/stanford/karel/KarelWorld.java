/*      */ package stanford.karel;
/*      */ import acm.util.ErrorException;
/*      */ import java.awt.Color;
/*      */ import java.awt.Component;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.Font;
/*      */ import java.awt.FontMetrics;
/*      */ import java.awt.Graphics;
/*      */ import java.awt.Point;
/*      */ import java.awt.Rectangle;
/*      */ import java.awt.event.MouseEvent;
/*      */ import java.io.File;
/*      */ import java.io.FileReader;
/*      */ import java.io.IOException;
/*      */ import java.io.PrintWriter;
/*      */ import java.io.Reader;
/*      */ import java.io.StreamTokenizer;
/*      */ import java.text.NumberFormat;
/*      */ import java.util.Enumeration;
/*      */ import java.util.Vector;
/*      */ 
/*      */ class KarelWorld extends Canvas {
/*      */   public static final int NORTH = 0;
/*      */   public static final int EAST = 1;
/*      */   public static final int SOUTH = 2;
/*      */   public static final int WEST = 3;
/*      */   public static final int NORTHEAST = 10;
/*      */   public static final int NORTHWEST = 11;
/*      */   public static final int SOUTHEAST = 12;
/*      */   public static final int SOUTHWEST = 13;
/*      */   public static final int CENTER = 14;
/*      */   public static final int INFINITE = 99999999;
/*      */   public static final int PLUS1 = -1;
/*      */   public static final int MINUS1 = -2;
/*      */   public static final int BLANKB = -3;
/*      */   public static final int SIMPLE = 0;
/*      */   public static final int FANCY = 1;
/*      */   public static final int LEFT_NUMBER_MARGIN = 16;
/*      */   public static final int BOTTOM_NUMBER_MARGIN = 15;
/*      */   public static final int DOUBLE_WALL_THRESHOLD = 24;
/*      */   public static final int CROSS_THRESHOLD = 11;
/*      */   public static final int NUMBER_THRESHOLD = 15;
/*   43 */   public static final Font NUMBER_FONT = new Font("Times", 0, 9);
/*      */   
/*      */   public static final double WALL_FRACTION = 0.3D;
/*      */   
/*      */   public static final double WALL_TOLERANCE = 0.15D;
/*      */   
/*      */   public static final int MAX_WIDTH = 50;
/*      */   
/*      */   public static final int MAX_HEIGHT = 50;
/*      */   public static final int MAX_DISPLAY_WIDTH = 316;
/*      */   public static final int MAX_DISPLAY_HEIGHT = 315;
/*      */   public static final boolean TOKEN_TRACE = false;
/*   55 */   public static final Color BEEPER_COLOR = Color.lightGray;
/*   56 */   public static final Color MARKED_COLOR = Color.darkGray;
/*      */   
/*      */   public static final int BEEPER_BORDER = 1;
/*      */   
/*      */   public static final String BEEPER_FONT_FAMILY = "Times";
/*      */   public static final int MIN_FANCY = 20;
/*      */   public static final int MIN_BEEPER = 4;
/*      */   public static final int MIN_LABEL = 15;
/*      */   public static final double BEEPER_FRACTION = 0.7D;
/*      */   public static final double SIMPLE_FRACTION = 0.7D;
/*      */   
/*      */   public KarelWorld() {
/*   68 */     this.sizeLock = new Object();
/*   69 */     setTitle("Karel World");
/*   70 */     setBackground(Color.white);
/*   71 */     KarelWorldListener listener = new KarelWorldListener(this);
/*   72 */     addMouseListener(listener);
/*   73 */     addMouseMotionListener(listener);
/*   74 */     addComponentListener(listener);
/*   75 */     this.speedFormat = NumberFormat.getInstance();
/*   76 */     this.speedFormat.setMinimumIntegerDigits(1);
/*   77 */     this.speedFormat.setMaximumIntegerDigits(1);
/*   78 */     this.speedFormat.setMinimumFractionDigits(2);
/*   79 */     this.speedFormat.setMaximumFractionDigits(2);
/*   80 */     this.forcedSize = 0;
/*   81 */     this.numberSquaresFlag = true;
/*   82 */     this.look = 1;
/*   83 */     this.alignment = 14;
/*   84 */     this.karels = new Vector();
/*   85 */     setRepaintFlag(true);
/*      */   }
/*      */   
/*      */   public void init(int cols, int rows) {
/*   89 */     synchronized (this.sizeLock) {
/*   90 */       this.cols = cols;
/*   91 */       this.rows = rows;
/*   92 */       setDisplayParameters(cols, rows);
/*   93 */       this.editMode = false;
/*   94 */       this.map = new Corner[cols + 2][rows + 2];
/*   95 */       for (int x = 1; x <= cols + 1; x++) {
/*   96 */         for (int y = 1; y <= rows + 1; y++) {
/*   97 */           this.map[x][y] = new Corner();
/*   98 */           (this.map[x][y]).wallSouth = !(y != 1 && y != rows + 1);
/*   99 */           (this.map[x][y]).wallWest = !(x != 1 && x != cols + 1);
/*  100 */           (this.map[x][y]).color = null;
/*      */         } 
/*      */       } 
/*  103 */       repaint();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void add(Karel karel) {
/*  108 */     if (this.karels.indexOf(karel) == -1) {
/*  109 */       karel.setWorld(this);
/*  110 */       this.karels.addElement(karel);
/*      */     } 
/*  112 */     repaint();
/*      */   }
/*      */   
/*      */   public void remove(Karel karel) {
/*  116 */     this.karels.removeElement(karel);
/*  117 */     karel.setWorld(null);
/*  118 */     repaint();
/*      */   }
/*      */ 
/*      */   
/*  122 */   public Karel getKarel() { return getKarel(0); }
/*      */ 
/*      */   
/*      */   public Karel getKarel(int k) {
/*  126 */     if (k < 0 || k >= this.karels.size()) {
/*  127 */       throw new ErrorException("Illegal Karel index");
/*      */     }
/*  129 */     return (Karel)this.karels.elementAt(k);
/*      */   }
/*      */ 
/*      */   
/*  133 */   public int getKarelCount() { return this.karels.size(); }
/*      */ 
/*      */   
/*      */   public Karel getKarelOnSquare(int x, int y) {
/*  137 */     for (Enumeration e = this.karels.elements(); e.hasMoreElements(); ) {
/*  138 */       Karel karel = (Karel)e.nextElement();
/*  139 */       Point pt = karel.getLocation();
/*  140 */       if (pt.x == x && pt.y == y) return karel; 
/*      */     } 
/*  142 */     return null;
/*      */   }
/*      */ 
/*      */   
/*  146 */   public void setTitle(String title) { this.title = title; }
/*      */ 
/*      */ 
/*      */   
/*  150 */   public String getTitle() { return this.title; }
/*      */ 
/*      */ 
/*      */   
/*  154 */   public void setPathname(String pathname) { this.pathname = pathname; }
/*      */ 
/*      */ 
/*      */   
/*  158 */   public String getPathname() { return this.pathname; }
/*      */ 
/*      */ 
/*      */   
/*  162 */   public void setRepaintFlag(boolean flag) { this.repaintFlag = flag; }
/*      */ 
/*      */ 
/*      */   
/*  166 */   public boolean getRepaintFlag() { return this.repaintFlag; }
/*      */ 
/*      */ 
/*      */   
/*  170 */   public boolean getNumberSquaresFlag() { return this.numberSquaresFlag; }
/*      */ 
/*      */ 
/*      */   
/*  174 */   public void setNumberSquaresFlag(boolean flag) { this.numberSquaresFlag = flag; }
/*      */ 
/*      */ 
/*      */   
/*  178 */   public int getAlignment() { return this.alignment; }
/*      */ 
/*      */ 
/*      */   
/*  182 */   public void setAlignment(int alignment) { this.alignment = alignment; }
/*      */ 
/*      */ 
/*      */   
/*  186 */   public int getLook() { return this.look; }
/*      */ 
/*      */ 
/*      */   
/*  190 */   public void setLook(int look) { this.look = look; }
/*      */ 
/*      */ 
/*      */   
/*  194 */   public String getPathName() { return this.pathname; }
/*      */ 
/*      */ 
/*      */   
/*  198 */   public void setPathName(String pathname) { this.pathname = pathname; }
/*      */ 
/*      */ 
/*      */   
/*  202 */   public boolean getEditMode() { return this.editMode; }
/*      */ 
/*      */ 
/*      */   
/*  206 */   public void setEditMode(boolean flag) { this.editMode = flag; }
/*      */ 
/*      */   
/*      */   public void updateEditMode(boolean flag) {
/*  210 */     if (this.monitor == null) throw new ErrorException("No map editor defined"); 
/*  211 */     setEditMode(flag);
/*  212 */     repaint();
/*      */   }
/*      */ 
/*      */   
/*  216 */   public void forceSquareSize(int size) { this.forcedSize = size; }
/*      */ 
/*      */ 
/*      */   
/*      */   public void reset() {}
/*      */ 
/*      */ 
/*      */   
/*  224 */   public int getSquareSize() { return this.sqSize; }
/*      */ 
/*      */ 
/*      */   
/*  228 */   public int getColumns() { return this.cols; }
/*      */ 
/*      */ 
/*      */   
/*  232 */   public int getRows() { return this.rows; }
/*      */ 
/*      */ 
/*      */   
/*  236 */   public boolean outOfBounds(Point pt) { return outOfBounds(pt.x, pt.y); }
/*      */ 
/*      */ 
/*      */   
/*  240 */   public boolean outOfBounds(int x, int y) { return !(x >= 1 && x <= this.cols && y >= 1 && y <= this.rows); }
/*      */ 
/*      */ 
/*      */   
/*  244 */   public int getBeepersOnCorner(Point pt) { return getBeepersOnCorner(pt.x, pt.y); }
/*      */ 
/*      */ 
/*      */   
/*  248 */   public int getBeepersOnCorner(int x, int y) { return (this.map[x][y]).nBeepers; }
/*      */ 
/*      */   
/*      */   public void setBeepersOnCorner(Point pt, int nBeepers) {
/*  252 */     (this.map[pt.x][pt.y]).nBeepers = nBeepers;
/*  253 */     updateCorner(pt);
/*      */   }
/*      */ 
/*      */   
/*  257 */   public void setBeepersOnCorner(int x, int y, int nBeepers) { setBeepersOnCorner(new Point(x, y), nBeepers); }
/*      */ 
/*      */   
/*      */   public static int adjustBeepers(int nBeepers, int delta) {
/*  261 */     if (nBeepers == 99999999) return 99999999; 
/*  262 */     return nBeepers + delta;
/*      */   }
/*      */   
/*      */   public static int setBeepers(int nBeepers, int delta) {
/*  266 */     if (delta == 99999999) return 99999999; 
/*  267 */     if (delta == -1) return (nBeepers == 99999999) ? 99999999 : (nBeepers + 1); 
/*  268 */     if (delta == -2) return (nBeepers == 99999999) ? 99999999 : Math.max(0, nBeepers - 1); 
/*  269 */     return delta;
/*      */   }
/*      */ 
/*      */   
/*  273 */   public Color getCornerColor(Point pt) { return getCornerColor(pt.x, pt.y); }
/*      */ 
/*      */ 
/*      */   
/*  277 */   public Color getCornerColor(int x, int y) { return (this.map[x][y]).color; }
/*      */ 
/*      */   
/*      */   public void setCornerColor(Point pt, Color color) {
/*  281 */     (this.map[pt.x][pt.y]).color = color;
/*  282 */     updateCorner(pt);
/*      */   }
/*      */ 
/*      */   
/*  286 */   public void setCornerColor(int x, int y, Color color) { setCornerColor(new Point(x, y), color); }
/*      */ 
/*      */ 
/*      */   
/*  290 */   public boolean checkWall(Point pt, int dir) { return checkWall(pt.x, pt.y, dir); }
/*      */ 
/*      */   
/*      */   public boolean checkWall(int x, int y, int dir) {
/*  294 */     switch (dir) { case 2:
/*  295 */         return (this.map[x][y]).wallSouth;
/*  296 */       case 3: return (this.map[x][y]).wallWest;
/*  297 */       case 0: return (this.map[x][y + 1]).wallSouth;
/*  298 */       case 1: return (this.map[x + 1][y]).wallWest; }
/*      */     
/*  300 */     return false;
/*      */   }
/*      */   
/*      */   public void setWall(Point pt, int dir) {
/*  304 */     switch (dir) { case 2:
/*  305 */         (this.map[pt.x][pt.y]).wallSouth = true; break;
/*  306 */       case 3: (this.map[pt.x][pt.y]).wallWest = true; break;
/*  307 */       case 0: (this.map[pt.x][pt.y + 1]).wallSouth = true; break;
/*  308 */       case 1: (this.map[pt.x + 1][pt.y]).wallWest = true; break; }
/*      */     
/*  310 */     updateCorner(pt);
/*      */   }
/*      */ 
/*      */   
/*  314 */   public void setWall(int x, int y, int dir) { setWall(new Point(x, y), dir); }
/*      */ 
/*      */   
/*      */   public void clearWall(Point pt, int dir) {
/*  318 */     switch (dir) { case 2:
/*  319 */         (this.map[pt.x][pt.y]).wallSouth = false; break;
/*  320 */       case 3: (this.map[pt.x][pt.y]).wallWest = false; break;
/*  321 */       case 0: (this.map[pt.x][pt.y + 1]).wallSouth = false; break;
/*  322 */       case 1: (this.map[pt.x + 1][pt.y]).wallWest = false; break; }
/*      */     
/*  324 */     updateCorner(pt);
/*  325 */     if (this.sqSize >= 24) {
/*  326 */       Point left = adjacentPoint(pt, leftFrom(dir));
/*  327 */       Point right = adjacentPoint(pt, rightFrom(dir));
/*  328 */       updateCorner(left);
/*  329 */       updateCorner(right);
/*  330 */       updateCorner(adjacentPoint(left, dir));
/*  331 */       updateCorner(adjacentPoint(pt, dir));
/*  332 */       updateCorner(adjacentPoint(right, dir));
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*  337 */   public void clearWall(int x, int y, int dir) { clearWall(new Point(x, y), dir); }
/*      */ 
/*      */ 
/*      */   
/*  341 */   public void updateCorner(int x, int y) { updateCorner(new Point(x, y)); }
/*      */ 
/*      */   
/*      */   public void updateCorner(Point pt) {
/*  345 */     Rectangle r = getCornerRect(pt);
/*  346 */     if (this.repaintFlag) repaint(r.x, r.y, r.width, r.height); 
/*      */   }
/*      */   
/*      */   public static String directionName(int dir) {
/*  350 */     switch (dir) { case 2:
/*  351 */         return "SOUTH";
/*  352 */       case 3: return "WEST";
/*  353 */       case 0: return "NORTH";
/*  354 */       case 1: return "EAST"; }
/*      */     
/*  356 */     return null;
/*      */   }
/*      */   
/*      */   public static int leftFrom(int dir) {
/*  360 */     switch (dir) { case 2:
/*  361 */         return 1;
/*  362 */       case 3: return 2;
/*  363 */       case 0: return 3;
/*  364 */       case 1: return 0; }
/*      */     
/*  366 */     return -1;
/*      */   }
/*      */   
/*      */   public static int rightFrom(int dir) {
/*  370 */     switch (dir) { case 2:
/*  371 */         return 3;
/*  372 */       case 3: return 0;
/*  373 */       case 0: return 1;
/*  374 */       case 1: return 2; }
/*      */     
/*  376 */     return -1;
/*      */   }
/*      */   
/*      */   public static int oppositeDirection(int dir) {
/*  380 */     switch (dir) { case 2:
/*  381 */         return 0;
/*  382 */       case 3: return 1;
/*  383 */       case 0: return 2;
/*  384 */       case 1: return 3; }
/*      */     
/*  386 */     return -1;
/*      */   }
/*      */ 
/*      */   
/*  390 */   public static Point adjacentPoint(Point pt, int dir) { return adjacentPoint(pt.x, pt.y, dir); }
/*      */ 
/*      */   
/*      */   public static Point adjacentPoint(int x, int y, int dir) {
/*  394 */     switch (dir) { case 2:
/*  395 */         return new Point(x, y - 1);
/*  396 */       case 3: return new Point(x - 1, y);
/*  397 */       case 0: return new Point(x, y + 1);
/*  398 */       case 1: return new Point(x + 1, y); }
/*      */     
/*  400 */     return null;
/*      */   }
/*      */ 
/*      */   
/*  404 */   public void repaint() { if (this.repaintFlag) super.repaint();
/*      */      }
/*      */ 
/*      */   
/*  408 */   public void update(Graphics g) { paint(g); }
/*      */ 
/*      */   
/*      */   public void paint(Graphics g) {
/*  412 */     if (this.map == null)
/*  413 */       return;  synchronized (this.sizeLock) {
/*  414 */       if (this.offscreen == null) {
/*  415 */         Dimension size = getSize();
/*  416 */         this.offscreen = createImage(size.width, size.height);
/*      */       } 
/*  418 */       Graphics osg = this.offscreen.getGraphics();
/*  419 */       drawEmptyWorld(osg);
/*  420 */       for (int pass = 0; pass < 2; pass++) {
/*  421 */         for (int x = 1; x <= this.cols + 1; x++) {
/*  422 */           for (int y = 1; y <= this.rows + 1; y++) {
/*  423 */             boolean mustPaint = false;
/*  424 */             if (getKarelOnSquare(x, y) != null) {
/*  425 */               mustPaint = true;
/*  426 */             } else if ((this.map[x][y]).color != null) {
/*  427 */               mustPaint = true;
/*  428 */             } else if ((this.map[x][y]).nBeepers != 0) {
/*  429 */               mustPaint = true;
/*  430 */             } else if (x > 1 && (this.map[x][y]).wallWest) {
/*  431 */               mustPaint = true;
/*  432 */             } else if (y > 1 && (this.map[x][y]).wallSouth) {
/*  433 */               mustPaint = true;
/*  434 */             } else if (x < this.cols && (this.map[x + 1][y]).wallWest) {
/*  435 */               mustPaint = true;
/*  436 */             } else if (y < this.rows && (this.map[x][y + 1]).wallSouth) {
/*  437 */               mustPaint = true;
/*      */             } 
/*  439 */             if (mustPaint) {
/*  440 */               if (pass == 0) {
/*  441 */                 updateContents(osg, new Point(x, y));
/*      */               } else {
/*  443 */                 updateWalls(osg, new Point(x, y));
/*      */               } 
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } 
/*  449 */       drawWorldFrame(osg);
/*      */     } 
/*  451 */     g.drawImage(this.offscreen, 0, 0, this);
/*      */   }
/*      */ 
/*      */   
/*  455 */   public void trace() { if (this.monitor != null) this.monitor.trace();
/*      */      }
/*      */ 
/*      */   
/*  459 */   protected void setMonitor(KarelWorldMonitor monitor) { this.monitor = monitor; }
/*      */ 
/*      */ 
/*      */   
/*  463 */   protected KarelWorldMonitor getMonitor() { return this.monitor; }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void componentResizedHook() {
/*  469 */     setDisplayParameters(this.cols, this.rows);
/*  470 */     repaint();
/*      */   }
/*      */   
/*      */   protected void mousePressedHook(MouseEvent e) {
/*  474 */     if (this.editMode) {
/*  475 */       this.lastClick = "";
/*  476 */       Point pt = getClickCorner(e.getX(), e.getY());
/*  477 */       if (pt == null) {
/*  478 */         this.activeKarel = null;
/*  479 */         checkForWallClick(e.getX(), e.getY());
/*      */       } else {
/*  481 */         this.activeKarel = getKarelOnSquare(pt.x, pt.y);
/*  482 */         if (this.activeKarel == null) checkForCornerClick(pt); 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void mouseDraggedHook(MouseEvent e) {
/*  488 */     if (!this.editMode)
/*  489 */       return;  if (this.activeKarel != null)
/*  490 */     { Point pt = getClickCorner(e.getX(), e.getY());
/*  491 */       if (pt != null && !pt.equals(this.activeKarel.getLocation())) {
/*  492 */         this.activeKarel.setLocation(pt);
/*  493 */         repaint();
/*      */       }
/*      */        }
/*  496 */     else if (!checkForWallClick(e.getX(), e.getY())) { checkForCornerClick(e.getX(), e.getY()); }
/*      */   
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean checkForWallClick(int mx, int my) {
/*      */     int dir;
/*  503 */     double sx = (mx - this.leftMargin + this.sqSize / 2) / this.sqSize;
/*  504 */     double sy = ((getSize()).height - my - this.bottomMargin - 1 + this.sqSize / 2) / this.sqSize;
/*  505 */     int tx = (int)(sx + 0.5D);
/*  506 */     int ty = (int)(sy + 0.5D);
/*      */     
/*  508 */     if (Math.abs(Math.abs(sx - tx) - 0.5D) <= 0.15D && Math.abs(sy - ty) < 0.3D) {
/*  509 */       if (tx > sx) tx--; 
/*  510 */       if (tx < 0 || tx > this.cols || ty < 1 || ty > this.rows) return false; 
/*  511 */       dir = 1;
/*  512 */     } else if (Math.abs(Math.abs(sy - ty) - 0.5D) <= 0.15D && Math.abs(sx - tx) < 0.3D) {
/*  513 */       if (ty > sy) ty--; 
/*  514 */       if (tx < 1 || tx > this.cols || ty < 0 || ty > this.rows) return false; 
/*  515 */       dir = 0;
/*      */     } else {
/*  517 */       return false;
/*      */     } 
/*  519 */     String click = String.valueOf(tx) + "/" + ty + "/" + dir;
/*  520 */     if (!click.equals(this.lastClick)) {
/*  521 */       if (this.monitor != null) this.monitor.wallAction(new Point(tx, ty), dir); 
/*  522 */       this.lastClick = click;
/*      */     } 
/*  524 */     return true;
/*      */   }
/*      */ 
/*      */   
/*  528 */   private boolean checkForCornerClick(int mx, int my) { return checkForCornerClick(getClickCorner(mx, my)); }
/*      */ 
/*      */   
/*      */   private boolean checkForCornerClick(Point pt) {
/*  532 */     if (pt == null) return false; 
/*  533 */     String click = String.valueOf(pt.x) + "/" + pt.y;
/*  534 */     if (!click.equals(this.lastClick)) {
/*  535 */       if (this.monitor != null) this.monitor.cornerAction(pt); 
/*  536 */       this.lastClick = click;
/*      */     } 
/*  538 */     return true;
/*      */   }
/*      */   
/*      */   private Point getClickCorner(int mx, int my) {
/*  542 */     double sx = (mx - this.leftMargin + this.sqSize / 2) / this.sqSize;
/*  543 */     double sy = ((getSize()).height - my - this.bottomMargin - 1 + this.sqSize / 2) / this.sqSize;
/*  544 */     int tx = (int)(sx + 0.5D);
/*  545 */     int ty = (int)(sy + 0.5D);
/*  546 */     if (tx < 1 || tx > this.cols || ty < 1 || ty > this.rows) return null; 
/*  547 */     if (Math.abs(Math.abs(sx - tx) - 0.5D) * this.sqSize <= 1.0D) return null; 
/*  548 */     if (Math.abs(Math.abs(sy - ty) - 0.5D) * this.sqSize <= 1.0D) return null; 
/*  549 */     return new Point(tx, ty);
/*      */   }
/*      */   
/*      */   private static String encodeColor(Color color) {
/*  553 */     if (color.equals(Color.black)) return "BLACK"; 
/*  554 */     if (color.equals(Color.blue)) return "BLUE"; 
/*  555 */     if (color.equals(Color.cyan)) return "CYAN"; 
/*  556 */     if (color.equals(Color.darkGray)) return "DARK_GRAY"; 
/*  557 */     if (color.equals(Color.gray)) return "GRAY"; 
/*  558 */     if (color.equals(Color.green)) return "GREEN"; 
/*  559 */     if (color.equals(Color.lightGray)) return "LIGHT_GRAY"; 
/*  560 */     if (color.equals(Color.magenta)) return "MAGENTA"; 
/*  561 */     if (color.equals(Color.orange)) return "ORANGE"; 
/*  562 */     if (color.equals(Color.pink)) return "PINK"; 
/*  563 */     if (color.equals(Color.red)) return "RED"; 
/*  564 */     if (color.equals(Color.white)) return "WHITE"; 
/*  565 */     if (color.equals(Color.yellow)) return "YELLOW"; 
/*  566 */     return "0x" + Integer.toString(color.getRGB() & 0xFFFFFF).toUpperCase();
/*      */   }
/*      */   
/*      */   private static Color decodeColor(String name) {
/*  570 */     if (name.equalsIgnoreCase("black")) return Color.black; 
/*  571 */     if (name.equalsIgnoreCase("blue")) return Color.blue; 
/*  572 */     if (name.equalsIgnoreCase("cyan")) return Color.cyan; 
/*  573 */     if (name.equalsIgnoreCase("darkGray") || name.equalsIgnoreCase("DARK_GRAY")) return Color.darkGray; 
/*  574 */     if (name.equalsIgnoreCase("gray")) return Color.gray; 
/*  575 */     if (name.equalsIgnoreCase("green")) return Color.green; 
/*  576 */     if (name.equalsIgnoreCase("lightGray") || name.equalsIgnoreCase("LIGHT_GRAY")) return Color.lightGray; 
/*  577 */     if (name.equalsIgnoreCase("magenta")) return Color.magenta; 
/*  578 */     if (name.equalsIgnoreCase("orange")) return Color.orange; 
/*  579 */     if (name.equalsIgnoreCase("pink")) return Color.pink; 
/*  580 */     if (name.equalsIgnoreCase("red")) return Color.red; 
/*  581 */     if (name.equalsIgnoreCase("white")) return Color.white; 
/*  582 */     if (name.equalsIgnoreCase("yellow")) return Color.yellow; 
/*  583 */     return Color.decode(name);
/*      */   }
/*      */   
/*      */   private void setDisplayParameters(int cols, int rows) {
/*  587 */     this.offscreen = null;
/*  588 */     int usableWidth = (getSize()).width - (this.numberSquaresFlag ? 16 : 2);
/*  589 */     int usableHeight = (getSize()).height - (this.numberSquaresFlag ? 15 : 0) - 2;
/*  590 */     this.width = cols;
/*  591 */     this.height = rows;
/*  592 */     if (this.forcedSize == 0) {
/*  593 */       this.sqSize = Math.min(usableWidth / cols, usableHeight / rows);
/*      */     } else {
/*  595 */       this.sqSize = this.forcedSize;
/*      */     } 
/*  597 */     this.width = cols * this.sqSize;
/*  598 */     this.height = rows * this.sqSize;
/*  599 */     switch (this.alignment) { case 3: case 11:
/*      */       case 13:
/*  601 */         this.leftMargin = this.numberSquaresFlag ? 16 : 2; break;
/*      */       case 0: case 2:
/*      */       case 14:
/*  604 */         this.leftMargin = (this.numberSquaresFlag ? 16 : 2) + (usableWidth - this.width) / 2; break;
/*      */       case 1: case 10:
/*      */       case 12:
/*  607 */         this.leftMargin = (getSize()).width - this.width - 1;
/*      */         break; }
/*      */     
/*  610 */     switch (this.alignment) { case 0: case 10:
/*      */       case 11:
/*  612 */         this.bottomMargin = (getSize()).height - this.height - 2; break;
/*      */       case 1: case 3:
/*      */       case 14:
/*  615 */         this.bottomMargin = (this.numberSquaresFlag ? 15 : 0) + (usableHeight - this.height) / 2; break;
/*      */       case 2: case 12:
/*      */       case 13:
/*  618 */         this.bottomMargin = this.numberSquaresFlag ? 15 : 0;
/*      */         break; }
/*      */   
/*      */   }
/*      */   
/*      */   private void drawEmptyWorld(Graphics g) {
/*  624 */     if (g == null)
/*  625 */       return;  Dimension size = getSize();
/*  626 */     g.setColor(Color.white);
/*  627 */     g.fillRect(0, 0, size.width, size.height);
/*  628 */     g.setColor(Color.black);
/*  629 */     int x = this.leftMargin + this.sqSize / 2;
/*  630 */     for (int ix = 1; ix <= this.cols; ix++) {
/*  631 */       int y = (getSize()).height - this.bottomMargin - (this.sqSize + 1) / 2 - 1;
/*  632 */       for (int iy = 1; iy <= this.rows; iy++) {
/*  633 */         drawCornerMarker(g, x, y);
/*  634 */         y -= this.sqSize;
/*      */       } 
/*  636 */       x += this.sqSize;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void drawWorldFrame(Graphics g) { // Byte code:
/*      */     //   0: aload_1
/*      */     //   1: ifnonnull -> 5
/*      */     //   4: return
/*      */     //   5: aload_1
/*      */     //   6: getstatic java/awt/Color.black : Ljava/awt/Color;
/*      */     //   9: invokevirtual setColor : (Ljava/awt/Color;)V
/*      */     //   12: aload_0
/*      */     //   13: getfield leftMargin : I
/*      */     //   16: istore_2
/*      */     //   17: aload_0
/*      */     //   18: invokevirtual getSize : ()Ljava/awt/Dimension;
/*      */     //   21: getfield height : I
/*      */     //   24: aload_0
/*      */     //   25: getfield bottomMargin : I
/*      */     //   28: isub
/*      */     //   29: iconst_1
/*      */     //   30: isub
/*      */     //   31: aload_0
/*      */     //   32: getfield height : I
/*      */     //   35: isub
/*      */     //   36: istore_3
/*      */     //   37: aload_0
/*      */     //   38: getfield sqSize : I
/*      */     //   41: bipush #24
/*      */     //   43: if_icmplt -> 89
/*      */     //   46: aload_1
/*      */     //   47: iload_2
/*      */     //   48: iload_3
/*      */     //   49: aload_0
/*      */     //   50: getfield width : I
/*      */     //   53: iconst_1
/*      */     //   54: isub
/*      */     //   55: aload_0
/*      */     //   56: getfield height : I
/*      */     //   59: iconst_1
/*      */     //   60: isub
/*      */     //   61: invokevirtual drawRect : (IIII)V
/*      */     //   64: aload_1
/*      */     //   65: iload_2
/*      */     //   66: iconst_1
/*      */     //   67: isub
/*      */     //   68: iload_3
/*      */     //   69: iconst_1
/*      */     //   70: isub
/*      */     //   71: aload_0
/*      */     //   72: getfield width : I
/*      */     //   75: iconst_1
/*      */     //   76: iadd
/*      */     //   77: aload_0
/*      */     //   78: getfield height : I
/*      */     //   81: iconst_1
/*      */     //   82: iadd
/*      */     //   83: invokevirtual drawRect : (IIII)V
/*      */     //   86: goto -> 107
/*      */     //   89: aload_1
/*      */     //   90: iload_2
/*      */     //   91: iconst_1
/*      */     //   92: isub
/*      */     //   93: iload_3
/*      */     //   94: iconst_1
/*      */     //   95: isub
/*      */     //   96: aload_0
/*      */     //   97: getfield width : I
/*      */     //   100: aload_0
/*      */     //   101: getfield height : I
/*      */     //   104: invokevirtual drawRect : (IIII)V
/*      */     //   107: aload_0
/*      */     //   108: getfield sqSize : I
/*      */     //   111: bipush #15
/*      */     //   113: if_icmple -> 322
/*      */     //   116: aload_0
/*      */     //   117: getfield numberSquaresFlag : Z
/*      */     //   120: ifeq -> 322
/*      */     //   123: aload_1
/*      */     //   124: getstatic stanford/karel/KarelWorld.NUMBER_FONT : Ljava/awt/Font;
/*      */     //   127: invokevirtual setFont : (Ljava/awt/Font;)V
/*      */     //   130: aload_1
/*      */     //   131: invokevirtual getFontMetrics : ()Ljava/awt/FontMetrics;
/*      */     //   134: astore #4
/*      */     //   136: aload_0
/*      */     //   137: getfield leftMargin : I
/*      */     //   140: aload_0
/*      */     //   141: getfield sqSize : I
/*      */     //   144: iconst_2
/*      */     //   145: idiv
/*      */     //   146: iadd
/*      */     //   147: istore_2
/*      */     //   148: aload_0
/*      */     //   149: invokevirtual getSize : ()Ljava/awt/Dimension;
/*      */     //   152: getfield height : I
/*      */     //   155: aload_0
/*      */     //   156: getfield bottomMargin : I
/*      */     //   159: isub
/*      */     //   160: bipush #10
/*      */     //   162: iadd
/*      */     //   163: istore_3
/*      */     //   164: iconst_1
/*      */     //   165: istore #5
/*      */     //   167: goto -> 215
/*      */     //   170: new java/lang/StringBuffer
/*      */     //   173: dup
/*      */     //   174: invokespecial <init> : ()V
/*      */     //   177: iload #5
/*      */     //   179: invokevirtual append : (I)Ljava/lang/StringBuffer;
/*      */     //   182: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   185: astore #6
/*      */     //   187: aload_1
/*      */     //   188: aload #6
/*      */     //   190: iload_2
/*      */     //   191: aload #4
/*      */     //   193: aload #6
/*      */     //   195: invokevirtual stringWidth : (Ljava/lang/String;)I
/*      */     //   198: iconst_2
/*      */     //   199: idiv
/*      */     //   200: isub
/*      */     //   201: iload_3
/*      */     //   202: invokevirtual drawString : (Ljava/lang/String;II)V
/*      */     //   205: iload_2
/*      */     //   206: aload_0
/*      */     //   207: getfield sqSize : I
/*      */     //   210: iadd
/*      */     //   211: istore_2
/*      */     //   212: iinc #5, 1
/*      */     //   215: iload #5
/*      */     //   217: aload_0
/*      */     //   218: getfield cols : I
/*      */     //   221: if_icmple -> 170
/*      */     //   224: aload_0
/*      */     //   225: getfield leftMargin : I
/*      */     //   228: iconst_3
/*      */     //   229: isub
/*      */     //   230: istore_2
/*      */     //   231: aload_0
/*      */     //   232: invokevirtual getSize : ()Ljava/awt/Dimension;
/*      */     //   235: getfield height : I
/*      */     //   238: aload_0
/*      */     //   239: getfield bottomMargin : I
/*      */     //   242: isub
/*      */     //   243: aload_0
/*      */     //   244: getfield sqSize : I
/*      */     //   247: iconst_2
/*      */     //   248: idiv
/*      */     //   249: isub
/*      */     //   250: iconst_2
/*      */     //   251: iadd
/*      */     //   252: istore_3
/*      */     //   253: iconst_1
/*      */     //   254: istore #5
/*      */     //   256: goto -> 313
/*      */     //   259: aload_1
/*      */     //   260: new java/lang/StringBuffer
/*      */     //   263: dup
/*      */     //   264: invokespecial <init> : ()V
/*      */     //   267: iload #5
/*      */     //   269: invokevirtual append : (I)Ljava/lang/StringBuffer;
/*      */     //   272: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   275: iload_2
/*      */     //   276: aload_1
/*      */     //   277: invokevirtual getFontMetrics : ()Ljava/awt/FontMetrics;
/*      */     //   280: new java/lang/StringBuffer
/*      */     //   283: dup
/*      */     //   284: invokespecial <init> : ()V
/*      */     //   287: iload #5
/*      */     //   289: invokevirtual append : (I)Ljava/lang/StringBuffer;
/*      */     //   292: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   295: invokevirtual stringWidth : (Ljava/lang/String;)I
/*      */     //   298: isub
/*      */     //   299: iload_3
/*      */     //   300: invokevirtual drawString : (Ljava/lang/String;II)V
/*      */     //   303: iload_3
/*      */     //   304: aload_0
/*      */     //   305: getfield sqSize : I
/*      */     //   308: isub
/*      */     //   309: istore_3
/*      */     //   310: iinc #5, 1
/*      */     //   313: iload #5
/*      */     //   315: aload_0
/*      */     //   316: getfield rows : I
/*      */     //   319: if_icmple -> 259
/*      */     //   322: return
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #641	-> 0
/*      */     //   #642	-> 5
/*      */     //   #643	-> 12
/*      */     //   #644	-> 17
/*      */     //   #645	-> 37
/*      */     //   #646	-> 46
/*      */     //   #647	-> 64
/*      */     //   #649	-> 89
/*      */     //   #651	-> 107
/*      */     //   #652	-> 123
/*      */     //   #653	-> 130
/*      */     //   #654	-> 136
/*      */     //   #655	-> 148
/*      */     //   #656	-> 164
/*      */     //   #657	-> 170
/*      */     //   #658	-> 187
/*      */     //   #659	-> 205
/*      */     //   #656	-> 212
/*      */     //   #661	-> 224
/*      */     //   #662	-> 231
/*      */     //   #663	-> 253
/*      */     //   #664	-> 259
/*      */     //   #665	-> 303
/*      */     //   #663	-> 310
/*      */     //   #668	-> 322
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	323	0	this	Lstanford/karel/KarelWorld;
/*      */     //   0	323	1	g	Ljava/awt/Graphics;
/*      */     //   17	306	2	x	I
/*      */     //   37	286	3	y	I
/*      */     //   136	186	4	fm	Ljava/awt/FontMetrics;
/*      */     //   167	57	5	ix	I
/*      */     //   187	25	6	label	Ljava/lang/String;
/*      */     //   256	66	5	iy	I }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void updateCorner(Graphics g, Point pt) {
/*  671 */     updateContents(g, pt);
/*  672 */     updateWalls(g, pt);
/*      */   }
/*      */   
/*      */   public void updateContents(Graphics g, Point pt) {
/*  676 */     if (g == null)
/*  677 */       return;  if (outOfBounds(pt))
/*  678 */       return;  int x = this.leftMargin + (pt.x - 1) * this.sqSize;
/*  679 */     int y = (getSize()).height - this.bottomMargin - 1 - pt.y * this.sqSize;
/*  680 */     drawCorner(g, x, y, pt);
/*      */   }
/*      */   
/*      */   public void drawCorner(Graphics g, int x, int y, Point pt) {
/*  684 */     if (g == null)
/*  685 */       return;  int sqSize = getSquareSize();
/*  686 */     Color color = getCornerColor(pt);
/*  687 */     g.setColor((color == null) ? Color.white : color);
/*  688 */     g.fillRect(x, y, sqSize, sqSize);
/*  689 */     int cx = x + sqSize / 2;
/*  690 */     int cy = y + sqSize / 2;
/*  691 */     int nBeepers = getBeepersOnCorner(pt);
/*  692 */     if (nBeepers > 0) {
/*  693 */       if (nBeepers == 1) nBeepers = -3; 
/*  694 */       drawBeeperForStyle(g, cx, cy, sqSize, nBeepers, 1);
/*      */     } 
/*  696 */     Karel karel = getKarelOnSquare(pt.x, pt.y);
/*  697 */     if (karel != null)
/*  698 */     { drawKarel(g, cx, cy, karel.getDirection(), sqSize); }
/*      */     
/*  700 */     else if (color == null && nBeepers == 0) { drawCornerMarker(g, cx, cy); }
/*      */   
/*      */   }
/*      */   
/*      */   public static void drawMarkedCorner(Graphics g, int x, int y, int size) {
/*  705 */     if (g == null)
/*  706 */       return;  int inset = Math.max(2, size / 5);
/*  707 */     g.setColor(Color.white);
/*  708 */     g.fillRect(x, y, size, size);
/*  709 */     g.setColor(MARKED_COLOR);
/*  710 */     g.fillRect(x + inset, y + inset, size - 2 * inset, size - 2 * inset);
/*      */   }
/*      */   
/*      */   public void drawKarel(Graphics g, int x, int y, int dir, int size) {
/*  714 */     if (g == null)
/*  715 */       return;  if (size < 20 || getLook() == 0) {
/*  716 */       drawSimpleKarel(g, x, y, dir, size);
/*      */     } else {
/*  718 */       drawFancyKarel(g, x, y, dir, size);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void drawSimpleKarel(Graphics g, int x, int y, int dir, int size) {
/*  723 */     if (g == null)
/*  724 */       return;  size = (int)Math.round(size * 0.7D);
/*  725 */     if (size % 2 == 0) size--; 
/*  726 */     int half = (size + 1) / 2;
/*  727 */     for (int pass = 1; pass <= 2; pass++) {
/*  728 */       KarelRegion r = new KarelRegion();
/*  729 */       r.setOrigin(x, y, -half, -half, dir);
/*  730 */       r.addVector(half, 0.0D, dir);
/*  731 */       r.addVector(half, half, dir);
/*  732 */       r.addVector(-half, half, dir);
/*  733 */       r.addVector(-half, 0.0D, dir);
/*  734 */       r.addVector(0.0D, -size, dir);
/*  735 */       if (pass == 1) {
/*  736 */         g.setColor(Color.white);
/*  737 */         g.fillPolygon(r.getPolygon());
/*      */       } else {
/*  739 */         g.setColor(Color.black);
/*  740 */         g.drawPolygon(r.getPolygon());
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*  746 */   public void drawFancyKarel(Graphics g, int x, int y, int dir, int size) { drawFancyKarel(g, x, y, dir, size - 6, Color.white); }
/*      */ 
/*      */   
/*      */   public static void drawFancyKarel(Graphics g, int x, int y, int dir, int size, Color color) {
/*  750 */     if (g == null)
/*  751 */       return;  for (int pass = 1; pass <= 2; pass++) {
/*  752 */       KarelRegion r = new KarelRegion();
/*  753 */       r.setOrigin(x, y, -0.2D * size, -0.33D * size + 0.1D * size, dir);
/*  754 */       int sx = r.getCurrentX();
/*  755 */       int sy = r.getCurrentY();
/*  756 */       g.setColor((pass == 1) ? color : Color.black);
/*  757 */       r.addVector(0.0D, 0.8D * size - 0.1D * size, dir);
/*  758 */       r.addVector(0.6D * size - 0.15D * size, 0.0D, dir);
/*  759 */       r.addVector(0.15D * size, -0.15D * size, dir);
/*  760 */       r.addVector(0.0D, -(0.8D * size - 0.15D * size), dir);
/*  761 */       r.addVector(-(0.6D * size - 0.1D * size), 0.0D, dir);
/*  762 */       r.addVector(-0.1D * size, 0.1D * size, dir);
/*  763 */       if (pass == 1) {
/*  764 */         r.getPolygon().addPoint(sx, sy);
/*  765 */         r.addVector(0.13D * size, 
/*  766 */             0.18000000000000002D * size, dir);
/*      */       } else {
/*  768 */         g.drawPolygon(r.getPolygon());
/*  769 */         r = new KarelRegion();
/*  770 */         r.setOrigin(sx, sy, 0.13D * size, 
/*  771 */             0.18000000000000002D * size, dir);
/*      */       } 
/*  773 */       r.addVector(0.3D * size, 0.0D, dir);
/*  774 */       r.addVector(0.0D, 0.4D * size, dir);
/*  775 */       r.addVector(-0.3D * size, 0.0D, dir);
/*  776 */       r.addVector(0.0D, -0.4D * size, dir);
/*  777 */       if (pass == 1) {
/*  778 */         r.getPolygon().addPoint(sx, sy);
/*  779 */         g.fillPolygon(r.getPolygon());
/*  780 */         r = new KarelRegion();
/*  781 */         r.setOrigin(sx, sy, 0.13D * size - 1.0D, 
/*  782 */             0.18000000000000002D * size - 1.0D, dir);
/*  783 */         r.addVector(0.3D * size + 2.0D, 0.0D, dir);
/*  784 */         r.addVector(0.0D, 0.4D * size + 2.0D, dir);
/*  785 */         r.addVector(-(0.3D * size + 2.0D), 0.0D, dir);
/*  786 */         r.addVector(0.0D, -(0.4D * size + 2.0D), dir);
/*  787 */         g.drawPolygon(r.getPolygon());
/*      */       } else {
/*  789 */         g.drawPolygon(r.getPolygon());
/*      */       } 
/*      */     } 
/*  792 */     g.setColor(Color.black);
/*  793 */     KarelRegion r = new KarelRegion();
/*  794 */     r.setOrigin(x, y, -0.07D * size + 0.3D * size, (
/*  795 */         -0.05D * size + -0.33D * size) / 2.0D, dir);
/*  796 */     r.addVector(-0.15D * size, 0.0D, dir);
/*  797 */     g.drawPolygon(r.getPolygon());
/*  798 */     r = new KarelRegion();
/*  799 */     r.setOrigin(x, y, -0.2D * size, -0.05D * size, dir);
/*  800 */     r.addVector(-(0.08D * size + 0.08D * size), 0.0D, dir);
/*  801 */     r.addVector(0.0D, -0.2D * size, dir);
/*  802 */     r.addVector(0.08D * size, 0.0D, dir);
/*  803 */     r.addVector(0.0D, 0.2D * size - 0.08D * size, dir);
/*  804 */     r.addVector(0.08D * size, 0.0D, dir);
/*  805 */     r.addVector(0.0D, 0.08D * size, dir);
/*  806 */     g.fillPolygon(r.getPolygon());
/*  807 */     g.drawPolygon(r.getPolygon());
/*  808 */     r = new KarelRegion();
/*  809 */     r.setOrigin(x, y, -0.07D * size + 0.3D * size - 0.15D * size, 
/*  810 */         -0.33D * size, dir);
/*  811 */     r.addVector(0.0D, -(0.08D * size + 0.08D * size), dir);
/*  812 */     r.addVector(0.2D * size, 0.0D, dir);
/*  813 */     r.addVector(0.0D, 0.08D * size, dir);
/*  814 */     r.addVector(-(0.2D * size - 0.08D * size), 0.0D, dir);
/*  815 */     r.addVector(0.0D, 0.08D * size, dir);
/*  816 */     r.addVector(-0.08D * size, 0.0D, dir);
/*  817 */     g.fillPolygon(r.getPolygon());
/*  818 */     g.drawPolygon(r.getPolygon());
/*      */   }
/*      */ 
/*      */   
/*  822 */   public void drawBeeperForStyle(Graphics g, int x, int y, int size, int n, int border) { drawBeeper(g, x, y, size, n, border, this); }
/*      */ 
/*      */   
/*      */   public static void drawBeeper(Graphics g, int x, int y, int size, int n, int border, Component comp) {
/*  826 */     if (g == null)
/*  827 */       return;  int beeperSize = (int)Math.round(size * 0.7D);
/*  828 */     if (beeperSize % 2 == 0) beeperSize--; 
/*  829 */     int half = (beeperSize + 1) / 2;
/*  830 */     KarelRegion r = new KarelRegion();
/*  831 */     r.setOrigin(x, y, 0.0D, -half, 1);
/*  832 */     r.addVector(half, half, 1);
/*  833 */     r.addVector(-half, half, 1);
/*  834 */     r.addVector(-half, -half, 1);
/*  835 */     r.addVector(half, -half, 1);
/*  836 */     g.setColor(BEEPER_COLOR);
/*  837 */     g.fillPolygon(r.getPolygon());
/*  838 */     g.drawPolygon(r.getPolygon());
/*  839 */     g.setColor(Color.black);
/*  840 */     for (int i = 0; i < border; i++) {
/*  841 */       int delta = half + i;
/*  842 */       g.drawLine(x - delta, y, x, y + delta);
/*  843 */       g.drawLine(x, y + delta, x + delta, y);
/*  844 */       g.drawLine(x + delta, y, x, y - delta);
/*  845 */       g.drawLine(x, y - delta, x - delta, y);
/*      */     } 
/*  847 */     if (size > 15 && n != 1) {
/*  848 */       labelBeeper(g, x, y, size, beeperLabel(n), comp);
/*      */     }
/*      */   }
/*      */   
/*      */   public static void labelBeeper(Graphics g, int x, int y, int size, String label, Component comp) {
/*  853 */     if (label.equals("∞")) {
/*  854 */       if (infinityImage == null) {
/*  855 */         infinityImage = MediaTools.createImage(INFINITY);
/*      */       }
/*  857 */       g.drawImage(infinityImage, x - 4, y - 2, comp);
/*      */     } else {
/*  859 */       int psz = 7;
/*  860 */       switch (label.length()) { case 1: case 2:
/*  861 */           psz = 10; break;
/*  862 */         default: psz = 7; break; }
/*      */       
/*  864 */       Font font = new Font("Times", 0, psz);
/*  865 */       g.setFont(font);
/*  866 */       FontMetrics fm = g.getFontMetrics();
/*  867 */       g.drawString(label, x - fm.stringWidth(label) / 2, y + fm.getAscent() / 2);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String beeperLabel(int n) { // Byte code:
/*      */     //   0: iload_0
/*      */     //   1: lookupswitch default -> 60, -3 -> 56, -2 -> 52, -1 -> 48, 99999999 -> 44
/*      */     //   44: ldc_w '∞'
/*      */     //   47: areturn
/*      */     //   48: ldc_w '+1'
/*      */     //   51: areturn
/*      */     //   52: ldc_w '-1'
/*      */     //   55: areturn
/*      */     //   56: ldc_w ''
/*      */     //   59: areturn
/*      */     //   60: new java/lang/StringBuffer
/*      */     //   63: dup
/*      */     //   64: invokespecial <init> : ()V
/*      */     //   67: iload_0
/*      */     //   68: invokevirtual append : (I)Ljava/lang/StringBuffer;
/*      */     //   71: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   74: areturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #872	-> 0
/*      */     //   #873	-> 44
/*      */     //   #874	-> 48
/*      */     //   #875	-> 52
/*      */     //   #876	-> 56
/*      */     //   #877	-> 60
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	75	0	n	I }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateWalls(Graphics g, Point pt) {
/*  882 */     if (g == null)
/*  883 */       return;  if (outOfBounds(pt))
/*  884 */       return;  int x = this.leftMargin + (pt.x - 1) * this.sqSize;
/*  885 */     int y = (getSize()).height - this.bottomMargin - 1 - pt.y * this.sqSize;
/*  886 */     g.setColor(Color.black);
/*  887 */     for (int dir = 0; dir <= 3; dir++) {
/*  888 */       if (checkWall(pt, dir)) drawWall(g, x, y, dir); 
/*  889 */       if (this.sqSize < 24) fixCornerPoint(g, pt, dir); 
/*      */     }  } private void drawWall(Graphics g, int x, int y, int dir) { int y1; int y1; int y1; int y1; int y1; int x1; int x1; int x1; int x1; int x1; int y0; int y0; int y0; int y0; int y0; int x0; int x0;
/*      */     int x0;
/*      */     int x0;
/*      */     int x0;
/*  894 */     if (g == null)
/*      */       return; 
/*  896 */     switch (dir) {
/*      */       case 0:
/*  898 */         x0 = x;
/*  899 */         y0 = y;
/*  900 */         x1 = x0 + this.sqSize;
/*  901 */         y1 = y0;
/*      */         break;
/*      */       case 1:
/*  904 */         x0 = x + this.sqSize;
/*  905 */         y0 = y;
/*  906 */         x1 = x0;
/*  907 */         y1 = y0 + this.sqSize;
/*      */         break;
/*      */       case 2:
/*  910 */         x0 = x;
/*  911 */         y0 = y + this.sqSize;
/*  912 */         x1 = x0 + this.sqSize;
/*  913 */         y1 = y0;
/*      */         break;
/*      */       case 3:
/*  916 */         x0 = x;
/*  917 */         y0 = y;
/*  918 */         x1 = x0;
/*  919 */         y1 = y0 + this.sqSize;
/*      */         break;
/*      */       default:
/*  922 */         x0 = y0 = x1 = y1 = 0;
/*      */         break;
/*      */     } 
/*  925 */     if (this.sqSize < 24) {
/*  926 */       g.drawLine(x0 - 1, y0 - 1, x1 - 1, y1 - 1);
/*      */     }
/*  928 */     else if (x0 == x1) {
/*  929 */       g.drawLine(x0 - 1, y0 - 1, x1 - 1, y1);
/*  930 */       g.drawLine(x0, y0 - 1, x1, y1);
/*      */     } else {
/*  932 */       g.drawLine(x0 - 1, y0 - 1, x1, y1 - 1);
/*  933 */       g.drawLine(x0 - 1, y0, x1, y1);
/*      */     }  }
/*      */ 
/*      */ 
/*      */   
/*      */   public void drawCornerMarker(Graphics g, int x, int y) {
/*  939 */     if (g == null)
/*  940 */       return;  g.setColor(Color.black);
/*  941 */     if (this.sqSize < 11) {
/*  942 */       g.drawLine(x, y, x, y);
/*      */     } else {
/*  944 */       g.drawLine(x - 1, y, x + 1, y);
/*  945 */       g.drawLine(x, y - 1, x, y + 1);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void fixCornerPoint(Graphics g, Point pt, int dir) {
/*  950 */     int left = leftFrom(dir);
/*  951 */     Point pUp = adjacentPoint(pt, dir);
/*  952 */     Point pLeft = adjacentPoint(pt, left);
/*  953 */     if (!outOfBounds(pUp) && checkWall(pUp, left)) {
/*  954 */       int x = this.leftMargin + (pUp.x - 1) * this.sqSize;
/*  955 */       int y = (getSize()).height - this.bottomMargin - 1 - pUp.y * this.sqSize;
/*  956 */       drawWall(g, x, y, left);
/*  957 */     } else if (!outOfBounds(pLeft) && checkWall(pLeft, dir)) {
/*  958 */       int x = this.leftMargin + (pLeft.x - 1) * this.sqSize;
/*  959 */       int y = (getSize()).height - this.bottomMargin - 1 - pLeft.y * this.sqSize;
/*  960 */       drawWall(g, x, y, dir);
/*      */     } 
/*      */   }
/*      */   
/*      */   private Rectangle getCornerRect(Point pt) {
/*  965 */     int x = this.leftMargin + (pt.x - 1) * this.sqSize;
/*  966 */     int y = (getSize()).height - this.bottomMargin - 1 - pt.y * this.sqSize;
/*  967 */     return new Rectangle(x - 1, y - 1, this.sqSize + 2, this.sqSize + 2);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void save() {
/*  973 */     if (this.pathname == null)
/*  974 */       return;  Point pt = new Point(0, 0);
/*      */     try {
/*  976 */       PrintWriter wr = new PrintWriter(new FileWriter(this.pathname));
/*  977 */       wr.println("Dimension: (" + this.cols + ", " + this.rows + ")");
/*  978 */       for (pt.x = 1; pt.x <= this.cols; pt.x++) {
/*  979 */         for (pt.y = 1; pt.y <= this.rows; pt.y++) {
/*  980 */           if (pt.x > 1 && checkWall(pt, 3)) {
/*  981 */             wr.println("Wall: (" + pt.x + ", " + pt.y + ") west");
/*      */           }
/*  983 */           if (pt.y > 1 && checkWall(pt, 2)) {
/*  984 */             wr.println("Wall: (" + pt.x + ", " + pt.y + ") south");
/*      */           }
/*      */         } 
/*      */       } 
/*  988 */       for (pt.x = 1; pt.x <= this.cols; pt.x++) {
/*  989 */         for (pt.y = 1; pt.y <= this.rows; pt.y++) {
/*  990 */           Color color = getCornerColor(pt);
/*  991 */           if (color != null) {
/*  992 */             wr.println("Color: (" + pt.x + ", " + pt.y + ") " + encodeColor(color));
/*      */           }
/*  994 */           int nBeepers = getBeepersOnCorner(pt);
/*  995 */           if (nBeepers != 0) {
/*  996 */             String str = (nBeepers == 99999999) ? "INFINITE" : nBeepers;
/*  997 */             wr.println("Beeper: (" + pt.x + ", " + pt.y + ") " + str);
/*      */           } 
/*      */         } 
/*      */       } 
/* 1001 */       for (Enumeration e = this.karels.elements(); e.hasMoreElements(); ) {
/* 1002 */         Karel karel = (Karel)e.nextElement();
/* 1003 */         String dirName = "Error";
/* 1004 */         switch (karel.getDirection()) { case 0:
/* 1005 */             dirName = "north"; break;
/* 1006 */           case 1: dirName = "east"; break;
/* 1007 */           case 2: dirName = "south"; break;
/* 1008 */           case 3: dirName = "west"; break; }
/*      */         
/* 1010 */         Point loc = karel.getLocation();
/* 1011 */         wr.print("Karel: (" + loc.x + ", " + loc.y + ") " + dirName);
/* 1012 */         int nBeepers = karel.getBeepersInBag();
/* 1013 */         if (nBeepers != 0) {
/* 1014 */           String str = (nBeepers == 99999999) ? "INFINITE" : nBeepers;
/* 1015 */           if (getKarelCount() == 1) {
/* 1016 */             wr.println();
/* 1017 */             wr.println("BeeperBag: " + str); continue;
/*      */           } 
/* 1019 */           wr.println(" " + str);
/*      */         } 
/*      */       } 
/*      */       
/* 1023 */       if (this.monitor != null) {
/* 1024 */         wr.println("Speed: " + this.speedFormat.format(this.monitor.getSpeed()));
/*      */       }
/* 1026 */       wr.close();
/* 1027 */     } catch (IOException ex) {
/* 1028 */       throw new ErrorException(ex);
/*      */     } 
/* 1030 */     Platform.setFileTypeAndCreator(this.pathname, "TEXT", "CWIE");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void load(String[] lines) {
/* 1036 */     String program = "";
/* 1037 */     for (int i = 0; i < lines.length; i++) {
/* 1038 */       program = String.valueOf(program) + lines[i] + '\n';
/*      */     }
/* 1040 */     load(new StringReader(program));
/*      */   }
/*      */   
/*      */   public void load(File file) {
/*      */     try {
/* 1045 */       this.pathname = file.getPath();
/* 1046 */       Reader rd = new FileReader(file);
/* 1047 */       if (rd == null) throw new ErrorException("Can't open " + this.pathname); 
/* 1048 */       load(rd);
/* 1049 */       rd.close();
/* 1050 */     } catch (IOException ex) {
/* 1051 */       throw new ErrorException("I/O error reading map file");
/*      */     } 
/*      */   }
/*      */   
/*      */   public void load(String pathname) {
/*      */     try {
/* 1057 */       this.pathname = pathname;
/* 1058 */       Reader rd = new FileReader(pathname);
/* 1059 */       if (rd == null) throw new ErrorException("Can't open " + pathname); 
/* 1060 */       load(rd);
/* 1061 */       rd.close();
/* 1062 */     } catch (IOException ex) {
/* 1063 */       throw new ErrorException("I/O error reading map file");
/*      */     } 
/*      */   }
/*      */   
/*      */   public void load(Reader rd) {
/*      */     try {
/* 1069 */       setRepaintFlag(false);
/* 1070 */       this.lastBeeperCount = 99999999;
/* 1071 */       this.tokenizer = new StreamTokenizer(rd);
/* 1072 */       this.tokenizer.eolIsSignificant(true);
/* 1073 */       this.tokenizer.lowerCaseMode(true);
/* 1074 */       this.tokenizer.resetSyntax();
/* 1075 */       this.tokenizer.wordChars(65, 90);
/* 1076 */       this.tokenizer.wordChars(97, 122);
/* 1077 */       this.tokenizer.wordChars(48, 57);
/* 1078 */       this.tokenizer.wordChars(46, 46);
/* 1079 */       this.tokenizer.wordChars(95, 95);
/* 1080 */       this.tokenizer.whitespaceChars(32, 32);
/* 1081 */       this.tokenizer.whitespaceChars(9, 9);
/* 1082 */       this.tokenizer.whitespaceChars(13, 13); do {  }
/* 1083 */       while (readMapLine());
/*      */ 
/*      */       
/* 1086 */       rd.close();
/* 1087 */       setRepaintFlag(true);
/* 1088 */       repaint();
/* 1089 */     } catch (IOException ex) {
/* 1090 */       setRepaintFlag(true);
/* 1091 */       throw new ErrorException("I/O error reading map file");
/*      */     } 
/*      */   }
/*      */   private boolean readMapLine() {
/*      */     String cmd;
/* 1096 */     int token = nextToken();
/* 1097 */     switch (token) { case -1:
/* 1098 */         return false;
/* 1099 */       case 10: return true;
/*      */       case -3:
/* 1101 */         cmd = this.tokenizer.sval;
/* 1102 */         if (nextToken() != 58) {
/* 1103 */           throw new ErrorException("Missing colon after " + cmd);
/*      */         }
/* 1105 */         if (cmd.equals("dimension")) {
/* 1106 */           dimensionCommand();
/* 1107 */         } else if (cmd.equals("karel") || cmd.equals("turtle")) {
/* 1108 */           karelCommand();
/* 1109 */         } else if (cmd.equals("wall")) {
/* 1110 */           wallCommand();
/* 1111 */         } else if (cmd.equals("mark") || cmd.equals("color")) {
/* 1112 */           setColorCommand();
/* 1113 */         } else if (cmd.equals("speed")) {
/* 1114 */           speedCommand();
/* 1115 */         } else if (cmd.equals("beeper")) {
/* 1116 */           beeperCommand();
/* 1117 */         } else if (cmd.equals("beeperbag")) {
/* 1118 */           beeperBagCommand();
/*      */         } else {
/* 1120 */           throw new ErrorException("Illegal command: " + cmd);
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1126 */         return true; }
/*      */     
/*      */     throw new ErrorException("Illegal character '" + (char)token + "'");
/*      */   } private void dimensionCommand() {
/* 1130 */     verifyToken(40);
/* 1131 */     int cols = scanInt();
/* 1132 */     verifyToken(44);
/* 1133 */     int rows = scanInt();
/* 1134 */     verifyToken(41);
/* 1135 */     verifyToken(10);
/* 1136 */     init(cols, rows);
/*      */   }
/*      */   
/*      */   private void karelCommand() {
/* 1140 */     Point pt = new Point(0, 0);
/* 1141 */     int dir = 1;
/* 1142 */     int nBeepers = this.lastBeeperCount;
/* 1143 */     verifyToken(40);
/* 1144 */     pt.x = scanInt();
/* 1145 */     verifyToken(44);
/* 1146 */     pt.y = scanInt();
/* 1147 */     verifyToken(41);
/* 1148 */     if (nextToken() != -3) {
/* 1149 */       throw new ErrorException("Illegal direction");
/*      */     }
/* 1151 */     if ("north".startsWith(this.tokenizer.sval)) {
/* 1152 */       dir = 0;
/* 1153 */     } else if ("east".startsWith(this.tokenizer.sval)) {
/* 1154 */       dir = 1;
/* 1155 */     } else if ("south".startsWith(this.tokenizer.sval)) {
/* 1156 */       dir = 2;
/* 1157 */     } else if ("west".startsWith(this.tokenizer.sval)) {
/* 1158 */       dir = 3;
/*      */     } else {
/* 1160 */       throw new ErrorException("Illegal direction " + this.tokenizer.sval);
/*      */     } 
/* 1162 */     int token = nextToken();
/* 1163 */     if (token == -3) {
/* 1164 */       if ("infinite".startsWith(this.tokenizer.sval) || "infinity".startsWith(this.tokenizer.sval)) {
/* 1165 */         nBeepers = 99999999;
/*      */       } else {
/*      */         try {
/* 1168 */           nBeepers = Integer.parseInt(this.tokenizer.sval);
/* 1169 */         } catch (NumberFormatException ex) {
/* 1170 */           throw new ErrorException("Illegal beeper bag value");
/*      */         } 
/*      */       } 
/* 1173 */       token = nextToken();
/*      */     } 
/* 1175 */     if (token != 10) {
/* 1176 */       throw new ErrorException("Unexpected tokens at end of line");
/*      */     }
/* 1178 */     this.lastKarel = getKarel();
/* 1179 */     if (this.lastKarel != null) {
/* 1180 */       this.lastKarel.setLocation(pt.x, pt.y);
/* 1181 */       this.lastKarel.setDirection(dir);
/* 1182 */       this.lastKarel.setBeepersInBag(nBeepers);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void wallCommand() {
/* 1187 */     Point pt = new Point(0, 0);
/* 1188 */     int dir = 1;
/* 1189 */     verifyToken(40);
/* 1190 */     pt.x = scanInt();
/* 1191 */     verifyToken(44);
/* 1192 */     pt.y = scanInt();
/* 1193 */     verifyToken(41);
/* 1194 */     if (nextToken() != -3) {
/* 1195 */       throw new ErrorException("Illegal direction");
/*      */     }
/* 1197 */     if ("north".startsWith(this.tokenizer.sval)) {
/* 1198 */       dir = 0;
/* 1199 */     } else if ("east".startsWith(this.tokenizer.sval)) {
/* 1200 */       dir = 1;
/* 1201 */     } else if ("south".startsWith(this.tokenizer.sval)) {
/* 1202 */       dir = 2;
/* 1203 */     } else if ("west".startsWith(this.tokenizer.sval)) {
/* 1204 */       dir = 3;
/*      */     } else {
/* 1206 */       throw new ErrorException("Illegal direction " + this.tokenizer.sval);
/*      */     } 
/* 1208 */     verifyToken(10);
/* 1209 */     setWall(pt, dir);
/*      */   }
/*      */   
/*      */   private void setColorCommand() {
/* 1213 */     Point pt = new Point(0, 0);
/* 1214 */     String colorName = null;
/* 1215 */     verifyToken(40);
/* 1216 */     pt.x = scanInt();
/* 1217 */     verifyToken(44);
/* 1218 */     pt.y = scanInt();
/* 1219 */     verifyToken(41);
/* 1220 */     int tt = nextToken();
/* 1221 */     if (tt != 10) {
/* 1222 */       if (tt != -3) throw new ErrorException("Missing color name"); 
/* 1223 */       colorName = this.tokenizer.sval.toLowerCase();
/* 1224 */       verifyToken(10);
/*      */     } 
/* 1226 */     setCornerColor(pt, decodeColor(colorName));
/*      */   }
/*      */   
/*      */   private void speedCommand() {
/* 1230 */     if (nextToken() != -3) {
/* 1231 */       throw new ErrorException("I expected a number");
/*      */     }
/* 1233 */     double speed = (new Double(this.tokenizer.sval)).doubleValue();
/* 1234 */     verifyToken(10);
/* 1235 */     if (this.monitor != null) this.monitor.setSpeed(speed); 
/*      */   }
/*      */   
/*      */   protected void beeperBagCommand() {
/* 1239 */     if (nextToken() != -3) {
/* 1240 */       throw new ErrorException("Illegal beeper count");
/*      */     }
/* 1242 */     int nBeepers = 0;
/* 1243 */     if ("infinite".startsWith(this.tokenizer.sval) || "infinity".startsWith(this.tokenizer.sval)) {
/* 1244 */       nBeepers = 99999999;
/*      */     } else {
/* 1246 */       this.tokenizer.pushBack();
/* 1247 */       nBeepers = scanInt();
/*      */     } 
/* 1249 */     verifyToken(10);
/* 1250 */     if (this.lastKarel == null) {
/* 1251 */       this.lastBeeperCount = nBeepers;
/*      */     } else {
/* 1253 */       this.lastKarel.setBeepersInBag(nBeepers);
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void beeperCommand() {
/* 1258 */     Point pt = new Point(0, 0);
/* 1259 */     int dir = 1;
/* 1260 */     verifyToken(40);
/* 1261 */     pt.x = scanInt();
/* 1262 */     verifyToken(44);
/* 1263 */     pt.y = scanInt();
/* 1264 */     verifyToken(41);
/* 1265 */     int nBeepers = 1;
/* 1266 */     int token = nextToken();
/* 1267 */     if (token != 10) {
/* 1268 */       if (token != -3) {
/* 1269 */         throw new ErrorException("Illegal beeper count");
/*      */       }
/* 1271 */       if ("infinite".startsWith(this.tokenizer.sval) || "infinity".startsWith(this.tokenizer.sval)) {
/* 1272 */         nBeepers = 99999999;
/*      */       } else {
/* 1274 */         this.tokenizer.pushBack();
/* 1275 */         nBeepers = scanInt();
/*      */       } 
/* 1277 */       verifyToken(10);
/*      */     } 
/* 1279 */     setBeepersOnCorner(pt, nBeepers);
/*      */   } protected void ignoreCommand() {
/*      */     do {
/*      */     
/* 1283 */     } while (nextToken() != 10);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void verifyToken(int token) {
/* 1289 */     if (nextToken() != token) {
/* 1290 */       if (token == 10) {
/* 1291 */         throw new ErrorException("Unexpected tokens at end of line");
/*      */       }
/* 1293 */       throw new ErrorException("I expected a '" + (char)token + "'");
/*      */     } 
/*      */   }
/*      */   
/*      */   private int scanInt() {
/* 1298 */     if (nextToken() != -3) {
/* 1299 */       throw new ErrorException("I expected an integer");
/*      */     }
/*      */     try {
/* 1302 */       return Integer.parseInt(this.tokenizer.sval);
/* 1303 */     } catch (NumberFormatException ex) {
/* 1304 */       throw new ErrorException("Illegal integer");
/*      */     } 
/*      */   }
/*      */   
/*      */   private int nextToken() {
/* 1309 */     int token = 0;
/*      */     try {
/* 1311 */       token = this.tokenizer.nextToken();
/* 1312 */     } catch (IOException ex) {
/* 1313 */       throw new ErrorException("Exception: " + ex);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1327 */     return (token == 10) ? 10 : token;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static final String[] INFINITY = { 
/* 1333 */       "47494638396109000600F70000FFFFFF980098339999989800111111222222000054CBFFCB003298", 
/* 1334 */       "0033660033CC0033FE00323266330066660000659800989800CC9900FE99329800659800CC0099FE", 
/* 1335 */       "0098659898999999CC9900FE98009800329800659900CC9800FE3399CB3399FF9999339898659832", 
/* 1336 */       "0098650099339998659833CB9833FF9999CC0099FE00336699656698CC9898FF9999323200336600", 
/* 1337 */       "32003233006632009833339965009866339900663300983200666600986500CC3300FE3200CC6600", 
/* 1338 */       "FE65CCCC98CCFF99FFCC99FFFF993300CC3200FE6600CC6500FECC0033CC0066FE0032FE00653399", 
/* 1339 */       "33339966669933669865CC00CCCB00FEFE00CBFE00FE6699CC6598FF9898CC9999FFCB9833CC9966", 
/* 1340 */       "FF9933FF9865333333326532323265326565660033653232660066653265CC3300CC6600FE3200FE", 
/* 1341 */       "65000066CC0099CC0066FE0098FE00CCCC00FECB00CCFE00FEFE33CC0033FE0066CC0066FE00CB33", 
/* 1342 */       "98CC6699FF3399FF659866CC9965FF9898CC9899FF99CCCC00CCFE00FECB00FEFE00993333996633", 
/* 1343 */       "9933669865659833CB9966CC9933FF9865FF33CBCB33FFCC33CCFF33FFFF99CB3399FF3399CC6698", 
/* 1344 */       "FF65CC98CCCCCCCCCC99FFCBCBFFFF99CCFFCBCBFF99FFFFCBFF3333CB3366CB3333FF3366FF6533", 
/* 1345 */       "CB6666CC6633FF6565FFCB3333CB6533CB3365CC6666FF3333FF6633FF3366FF656533CB3333FF33", 
/* 1346 */       "33CB6633FF6666CB3366FF3366CC6665FF65CB33CBCC66CCCC33FFCC65FFFF33CCFF65CCFF33FFFF", 
/* 1347 */       "65FF66CCCC65FFCC65CCFF65FFFF98CCCC99FFCC99CCFF99FFFFCBCB33CCFF33CCCC66CCFF65FFCC", 
/* 1348 */       "33FFFF33FFCC65FFFF65444444656532DDDDDDCBFFFFFFFFCBEEEEEE100000980000001000660000", 
/* 1349 */       "000098000066777777888888AAAAAABBBBBB5555556666660000100000224400005400000000CC00", 
/* 1350 */       "00DC0000EE0000FE00003200004400880000980000AA0000BA0000CC0000DC0000EE0000FE00CC00", 
/* 1351 */       "00DC0000EE0000FE0000004400005400006600007600220000320000AA0000BA0000002200003200", 
/* 1352 */       "7600008800000000AA0000BA00007600008800000021F90401000090002C0000000009000600C7FF", 
/* 1353 */       "FFFF980098339999989800111111222222000054CBFFCB0032980033660033CC0033FE0032326633", 
/* 1354 */       "0066660000659800989800CC9900FE99329800659800CC0099FE0098659898999999CC9900FE9800", 
/* 1355 */       "9800329800659900CC9800FE3399CB3399FF99993398986598320098650099339998659833CB9833", 
/* 1356 */       "FF9999CC0099FE00336699656698CC9898FF99993232003366003200323300663200983333996500", 
/* 1357 */       "9866339900663300983200666600986500CC3300FE3200CC6600FE65CCCC98CCFF99FFCC99FFFF99", 
/* 1358 */       "3300CC3200FE6600CC6500FECC0033CC0066FE0032FE0065339933339966669933669865CC00CCCB", 
/* 1359 */       "00FEFE00CBFE00FE6699CC6598FF9898CC9999FFCB9833CC9966FF9933FF98653333333265323232", 
/* 1360 */       "65326565660033653232660066653265CC3300CC6600FE3200FE65000066CC0099CC0066FE0098FE", 
/* 1361 */       "00CCCC00FECB00CCFE00FEFE33CC0033FE0066CC0066FE00CB3398CC6699FF3399FF659866CC9965", 
/* 1362 */       "FF9898CC9899FF99CCCC00CCFE00FECB00FEFE009933339966339933669865659833CB9966CC9933", 
/* 1363 */       "FF9865FF33CBCB33FFCC33CCFF33FFFF99CB3399FF3399CC6698FF65CC98CCCCCCCCCC99FFCBCBFF", 
/* 1364 */       "FF99CCFFCBCBFF99FFFFCBFF3333CB3366CB3333FF3366FF6533CB6666CC6633FF6565FFCB3333CB", 
/* 1365 */       "6533CB3365CC6666FF3333FF6633FF3366FF656533CB3333FF3333CB6633FF6666CB3366FF3366CC", 
/* 1366 */       "6665FF65CB33CBCC66CCCC33FFCC65FFFF33CCFF65CCFF33FFFF65FF66CCCC65FFCC65CCFF65FFFF", 
/* 1367 */       "98CCCC99FFCC99CCFF99FFFFCBCB33CCFF33CCCC66CCFF65FFCC33FFFF33FFCC65FFFF6544444465", 
/* 1368 */       "6532DDDDDDCBFFFFFFFFCBEEEEEE100000980000001000660000000098000066777777888888AAAA", 
/* 1369 */       "AABBBBBB5555556666660000100000224400005400000000CC0000DC0000EE0000FE000032000044", 
/* 1370 */       "00880000980000AA0000BA0000CC0000DC0000EE0000FE00CC0000DC0000EE0000FE000000440000", 
/* 1371 */       "5400006600007600220000320000AA0000BA00000022000032007600008800000000AA0000BA0000", 
/* 1372 */       "7600008800000008190021091C4810D2BF7F06110A54C870E0C1840E174A2C4830200021FF0B4D41", 
/* 1373 */       "4347436F6E2004031039000000015772697474656E20627920474946436F6E76657274657220322E", 
/* 1374 */       "342E33206F66204D6F6E6461792C204D61792032352C2031393938003B" };
/*      */   private static final int KAREL_INSET = 6;
/*      */   private static final double BODY_OFFSET_X = -0.2D;
/*      */   private static final double BODY_OFFSET_Y = -0.33D;
/*      */   private static final double BODY_WIDTH = 0.6D;
/*      */   private static final double BODY_HEIGHT = 0.8D;
/*      */   private static final double UPPER_NOTCH = 0.15D;
/*      */   private static final double LOWER_NOTCH = 0.1D;
/*      */   private static final double SCREEN_OFFSET_X = -0.07D;
/*      */   private static final double SCREEN_OFFSET_Y = -0.05D;
/*      */   private static final double SCREEN_WIDTH = 0.3D;
/*      */   private static final double SCREEN_HEIGHT = 0.4D;
/*      */   private static final double SLOT_WIDTH = 0.15D;
/*      */   private static final double FOOT_WIDTH = 0.08D;
/*      */   private static final double FOOT_LENGTH = 0.2D;
/*      */   private static final double UPPER_ANKLE = 0.08D;
/*      */   private static final double LOWER_ANKLE = 0.08D;
/*      */   private static Image infinityImage;
/*      */   private StreamTokenizer tokenizer;
/*      */   private KarelWorldMonitor monitor;
/*      */   private Karel activeKarel;
/*      */   private Karel lastKarel;
/*      */   private boolean running;
/*      */   private boolean repaintFlag;
/*      */   private boolean editMode;
/*      */   private boolean numberSquaresFlag;
/*      */   private int cols;
/*      */   private int rows;
/*      */   private int sqSize;
/*      */   private int forcedSize;
/*      */   private int alignment;
/*      */   private int width;
/*      */   private int height;
/*      */   private int leftMargin;
/*      */   private int bottomMargin;
/*      */   private String lastClick;
/*      */   private String pathname;
/*      */   private String title;
/*      */   private Corner[][] map;
/*      */   private int look;
/*      */   private int beeperBag;
/*      */   private int lastBeeperCount;
/*      */   private NumberFormat speedFormat;
/*      */   private Vector karels;
/*      */   private Object sizeLock;
/*      */   private Image offscreen;
/*      */ }


/* Location:              /root/karel.jar!/stanford/karel/KarelWorld.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */