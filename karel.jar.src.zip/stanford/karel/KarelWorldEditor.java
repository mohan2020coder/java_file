/*     */ package stanford.karel;
/*     */ 
/*     */ import acm.util.MediaTools;
/*     */ import java.awt.Canvas;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Image;
/*     */ import java.awt.Point;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseListener;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Vector;
/*     */ 
/*     */ class KarelWorldEditor
/*     */   extends Canvas implements MouseListener {
/*     */   public KarelWorldEditor(KarelWorld world) {
/*  18 */     this.world = world;
/*  19 */     setBackground(Color.white);
/*  20 */     initEditorCanvas();
/*  21 */     addMouseListener(this);
/*     */   }
/*     */   
/*     */   public void initEditorCanvas() {
/*  25 */     this.tools = new Vector();
/*  26 */     int x = 8;
/*  27 */     int y = 3;
/*  28 */     createWallTool(x, y, "Draw Wall");
/*  29 */     x += 26; createWallTool(x, y, "Erase Wall");
/*  30 */     x += 32; createBeeperTool(x, y, "Single Beeper", 1);
/*  31 */     x += 26; createBeeperTool(x, y, "Add Beeper", -1);
/*  32 */     x += 26; createBeeperTool(x, y, "Subtract Beeper", -2);
/*  33 */     x += 26; createBeeperTool(x, y, "Clear Beepers", 0);
/*  34 */     x += 26; createBeeperTool(x, y, "Infinite Beepers", 99999999);
/*  35 */     if (this.world.getKarelCount() == 1) {
/*  36 */       Karel karel = this.world.getKarel();
/*  37 */       x = 8;
/*  38 */       y += 28;
/*  39 */       createBeeperBagTool(x + 56 + 18, y);
/*  40 */       createKarelTool(x, y, "East", 1);
/*  41 */       x += 28; createKarelTool(x, y, "North", 0);
/*  42 */       x = 8;
/*  43 */       createKarelTool(x, y + 28, "West", 3);
/*  44 */       x += 28; createKarelTool(x, y + 28, "South", 2);
/*  45 */       if (karel instanceof SuperKarel) {
/*  46 */         x = 8;
/*  47 */         y += Math.max(56, 47) + 8;
/*  48 */         for (int i = 0; i < NCOLORS; i++) {
/*  49 */           x += 18; createColorTool(x, y, 12, COLORS[i]);
/*  50 */           if (COLORS[i] == Color.white) {
/*  51 */             x = -10;
/*  52 */             y += 20;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*  57 */     this.selectedTool = (MapTool)this.tools.elementAt(0);
/*     */   }
/*     */ 
/*     */   
/*  61 */   public Dimension getPreferredSize() { return new Dimension(200, 94); }
/*     */ 
/*     */ 
/*     */   
/*  65 */   public MapTool getSelectedTool() { return this.selectedTool; }
/*     */ 
/*     */ 
/*     */   
/*  69 */   public KarelWorld getWorld() { return this.world; }
/*     */ 
/*     */   
/*     */   public void drawTools(Graphics g) {
/*  73 */     for (Enumeration e = this.tools.elements(); e.hasMoreElements();) {
/*  74 */       drawTool(g, (MapTool)e.nextElement());
/*     */     }
/*  76 */     if (this.beeperBagTool != null) drawBeeperBag(g);
/*     */   
/*     */   }
/*     */   
/*  80 */   public void drawKarelTool(Graphics g, MapTool tool) { this.world.drawFancyKarel(g, tool.x + tool.size / 2, tool.y + tool.size / 2, tool.dir, tool.size); }
/*     */ 
/*     */   
/*     */   public void drawBeeperTool(Graphics g, MapTool tool) {
/*  84 */     int border = (tool == getSelectedTool()) ? 3 : 1;
/*  85 */     KarelWorld.drawBeeper(g, tool.x + tool.size / 2, tool.y + tool.size / 2, 28, tool.beeperDelta, border, this);
/*     */   }
/*     */   
/*     */   public void drawBeeperBag(Graphics g) {
/*  89 */     int x = this.beeperBagTool.x;
/*  90 */     int y = this.beeperBagTool.y;
/*  91 */     if (this.beeperBagImage == null) {
/*  92 */       this.beeperBagImage = MediaTools.createImage(BEEPER_BAG);
/*     */     }
/*  94 */     g.drawImage(this.beeperBagImage, this.beeperBagTool.x, this.beeperBagTool.y, this);
/*  95 */     x += 17;
/*  96 */     y += 28;
/*  97 */     Karel karel = this.world.getKarel();
/*  98 */     int nBeepers = (karel == null) ? 0 : karel.getBeepersInBag();
/*  99 */     KarelWorld.drawBeeper(g, x, y, 28, nBeepers, 1, this);
/*     */   }
/*     */ 
/*     */   
/* 103 */   public void defineTool(MapTool tool) { this.tools.addElement(tool); }
/*     */ 
/*     */   
/*     */   public MapTool createWallTool(int x, int y, String label) {
/* 107 */     MapTool tool = new MapTool(1, x, y, 20);
/* 108 */     tool.label = label;
/* 109 */     defineTool(tool);
/* 110 */     return tool;
/*     */   }
/*     */   
/*     */   public MapTool createColorTool(int x, int y, int size, Color color) {
/* 114 */     MapTool tool = new MapTool(2, x, y, size);
/* 115 */     tool.color = color;
/* 116 */     defineTool(tool);
/* 117 */     return tool;
/*     */   }
/*     */   
/*     */   public MapTool createKarelTool(int x, int y, String label, int dir) {
/* 121 */     MapTool tool = new MapTool(3, x, y, 28);
/* 122 */     tool.label = label;
/* 123 */     tool.dir = dir;
/* 124 */     defineTool(tool);
/* 125 */     return tool;
/*     */   }
/*     */   
/*     */   public MapTool createBeeperTool(int x, int y, String label, int beeperDelta) {
/* 129 */     MapTool tool = new MapTool(4, x, y, 20);
/* 130 */     tool.label = label;
/* 131 */     tool.beeperDelta = beeperDelta;
/* 132 */     defineTool(tool);
/* 133 */     return tool;
/*     */   }
/*     */   
/*     */   public MapTool createBeeperBagTool(int x, int y) {
/* 137 */     this.beeperBagTool = new MapTool(5, x, y, 0);
/* 138 */     return this.beeperBagTool;
/*     */   }
/*     */   
/*     */   public void drawTool(Graphics g, MapTool tool) {
/* 142 */     g.setColor(getBackground());
/* 143 */     int span = tool.size + 4 + 1;
/* 144 */     g.fillRect(tool.x - 2, tool.y - 2, span, span);
/* 145 */     g.setColor(Color.black);
/* 146 */     switch (tool.toolClass) { case 1:
/* 147 */         drawWallTool(g, tool); break;
/* 148 */       case 2: drawColorTool(g, tool); break;
/* 149 */       case 3: drawKarelTool(g, tool); break;
/* 150 */       case 4: drawBeeperTool(g, tool);
/*     */         break; }
/*     */   
/*     */   }
/*     */   public void drawWallTool(Graphics g, MapTool tool) {
/* 155 */     int border = (tool == this.selectedTool) ? 3 : 1;
/* 156 */     drawSquare(g, tool.x, tool.y, tool.size, border, null);
/* 157 */     int x = tool.x + (tool.size - 12 + 1) / 2;
/* 158 */     int y = tool.y + (tool.size + 1) / 2;
/* 159 */     if (tool.label.equals("Erase Wall")) {
/* 160 */       g.setColor(Color.gray);
/* 161 */       g.drawRect(x, y - 1, 12, 2);
/* 162 */       g.setColor(Color.black);
/*     */     } else {
/* 164 */       g.fillRect(x, y - 1, 12, 2);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void drawColorTool(Graphics g, MapTool tool) {
/* 169 */     int border = (tool == this.selectedTool) ? 3 : 1;
/* 170 */     Color color = null;
/* 171 */     if (tool.color == null) {
/* 172 */       color = null;
/* 173 */       int x = tool.x + tool.size / 2;
/* 174 */       int y = tool.y + tool.size / 2;
/* 175 */       g.setColor(Color.white);
/* 176 */       g.fillRect(tool.x, tool.y, tool.size, tool.size);
/* 177 */       g.setColor(Color.black);
/* 178 */       g.drawLine(x - 1, y, x + 1, y);
/* 179 */       g.drawLine(x, y - 1, x, y + 1);
/*     */     } else {
/* 181 */       color = tool.color;
/*     */     } 
/* 183 */     drawSquare(g, tool.x, tool.y, tool.size, border, color);
/*     */   }
/*     */   
/*     */   public boolean inBeeperBag(Point pt) {
/* 187 */     if (this.beeperBagTool == null) return false; 
/* 188 */     int x = this.beeperBagTool.x;
/* 189 */     int y = this.beeperBagTool.y;
/* 190 */     return (pt.x > x && pt.x < x + 35 && pt.y > y && pt.y < y + 47);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void wallAction(Point pt, int dir) {
/* 196 */     MapTool tool = getSelectedTool();
/* 197 */     if (tool.toolClass != 1)
/* 198 */       return;  if (tool.label.equals("Draw Wall")) {
/* 199 */       this.world.setWall(pt, dir);
/* 200 */       this.world.repaint();
/* 201 */     } else if (tool.label.equals("Erase Wall")) {
/* 202 */       this.world.clearWall(pt, dir);
/* 203 */       this.world.repaint();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void cornerAction(Point pt) {
/* 208 */     MapTool tool = getSelectedTool();
/* 209 */     if (tool.toolClass == 2) {
/* 210 */       this.world.setCornerColor(pt, tool.color);
/* 211 */       this.world.repaint();
/* 212 */     } else if (tool.toolClass == 4) {
/* 213 */       int nBeepers = this.world.getBeepersOnCorner(pt);
/* 214 */       nBeepers = KarelWorld.setBeepers(nBeepers, tool.beeperDelta);
/* 215 */       this.world.setBeepersOnCorner(pt, nBeepers);
/* 216 */       this.world.repaint();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void toolAction(Point pt) {
/* 221 */     if (inBeeperBag(pt)) {
/* 222 */       MapTool tool = getSelectedTool();
/* 223 */       if (tool == null)
/* 224 */         return;  if (tool.toolClass == 4) {
/* 225 */         Karel karel = this.world.getKarel();
/* 226 */         if (karel != null) {
/* 227 */           int nBeepers = karel.getBeepersInBag();
/* 228 */           nBeepers = KarelWorld.setBeepers(nBeepers, tool.beeperDelta);
/* 229 */           karel.setBeepersInBag(nBeepers);
/* 230 */           drawBeeperBag(getGraphics());
/* 231 */           repaint();
/*     */         } 
/*     */       } 
/*     */     } else {
/* 235 */       MapTool tool = findTool(pt);
/* 236 */       if (tool == null)
/* 237 */         return;  if (tool.toolClass == 3) {
/* 238 */         Karel karel = this.world.getKarel();
/* 239 */         if (karel != null) {
/* 240 */           karel.setDirection(tool.dir);
/*     */         }
/* 242 */         this.world.repaint();
/*     */       } else {
/* 244 */         this.oldTool = this.selectedTool;
/* 245 */         this.selectedTool = tool;
/* 246 */         drawTool(getGraphics(), tool);
/* 247 */         drawTool(getGraphics(), this.oldTool);
/* 248 */         repaint();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/* 254 */   public void paint(Graphics g) { drawTools(g); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 260 */   public void mousePressed(MouseEvent e) { toolAction(e.getPoint()); }
/*     */   
/*     */   public void mouseClicked(MouseEvent e) {}
/*     */   
/*     */   public void mouseReleased(MouseEvent e) {}
/*     */   
/*     */   public void mouseEntered(MouseEvent e) {}
/*     */   
/*     */   public void mouseExited(MouseEvent e) {}
/*     */   
/*     */   private void drawSquare(Graphics g, int x, int y, int size, int border, Color color) {
/* 271 */     if (color != null) {
/* 272 */       g.setColor(color);
/* 273 */       g.fillRect(x, y, size, size);
/*     */     } 
/* 275 */     g.setColor(Color.black);
/* 276 */     for (int i = 0; i < border; i++) {
/* 277 */       g.drawRect(x - i, y - i, size + 2 * i, size + 2 * i);
/*     */     }
/*     */   }
/*     */   
/*     */   private MapTool findTool(Point pt) {
/* 282 */     for (Enumeration e = this.tools.elements(); e.hasMoreElements(); ) {
/* 283 */       MapTool tool = (MapTool)e.nextElement();
/* 284 */       if (tool.contains(pt)) return tool; 
/*     */     } 
/* 286 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static String[] BEEPER_BAG = { 
/* 292 */       "47494638396123002F00D52000CBFFCB663300666600999999999933979764983200986500CC9898", 
/* 293 */       "323200CCCC98FFCC99CB9833CC9966333333643131643164CC660098CC98993333996633976464CC", 
/* 294 */       "CCCCFFCBCBCB6533CC6666CCCC66444444646431DDDDDDCBFFFFFFFFCBEEEEEE777777888888AAAA", 
/* 295 */       "AABBBBBB555555666666440000320000910000910000910000910000910000910000910000910000", 
/* 296 */       "91000091000091000091000091000091000091000091000091000091000091000091000091000091", 
/* 297 */       "000091000021F9040100001E002C0000000023002F004506FF408F70482C1A8FC8A4E7A3785428D0", 
/* 298 */       "07E7615228AF9F69E5C0E5620E182834C40929411C28664D6178BF847537CCA08429A147D1F1B483", 
/* 299 */       "0F19737E5D6F6C6213254668057D62057F5E908415010A1F4A1F210E0E0F0E1B09280F2328091B0F", 
/* 300 */       "A79B24574A080F1413141C014E96AB450A288C0C61111107BE847762091C4705097D727273070D6F", 
/* 301 */       "0775116A150F0D441F01504F18056276616B5FE26C770561B61622260E010207D40F090D15B6469A", 
/* 302 */       "9B2256460A229B0E66F5865CE0402AC08904A71E0400C5E142402421BC75A300E221920F0A097561", 
/* 303 */       "648082AA87253854A8D04B1AB077E00C256095A68FC93F6E0865F8468100850A280014F9D0C0891A", 
/* 304 */       "FF68C19E11EA45E1801D07FA9630F2168E99A43FE40854C0A0F0929058DFA42E53F32D523843154C", 
/* 305 */       "402862210D856E66ED74FBA2319C9D2805AE2028F52028979169E23520D1C1A2DF800A4A7C4C42A2", 
/* 306 */       "44525B1D4A6C4A90C001070B23868070C0785389BE8039209C95D0714262871F7E3041CC5582130B", 
/* 307 */       "1398B0FA57C88527136F3EE8E0B035916C8DF0D8BE75EA40802EB23820C0EC57C180BA810241ADF9", 
/* 308 */       "00C500D14DB670E915CC8E9BB08393609432154A0492D5C1BDD3A3448314EF50BA482F0AC69BD107", 
/* 309 */       "082A1A21512183390AD435561713A68283EC4274008539851C500001EFF8C15618ED3DF14076596C", 
/* 310 */       "33C824FA8DB3C613D4D023C40710A4017F4E4D6C01156224604803450652B0868209DEE9E7A2206F", 
/* 311 */       "D9F1C4064364E1CA3723EE32E15D776C034E08AC51900D1436C978873031A9275101E4090182905C", 
/* 312 */       "39C2143336D55107060D04C0DA864E60F08459D22913941C0E2E90041E6671E0CE8B771D80480900", 
/* 313 */       "D93240028F04C0C12415A481406DB675308004769A1050100021FF0B4D414347436F6E2004031039", 
/* 314 */       "000000015772697474656E20627920474946436F6E76657274657220322E342E33206F66204D6F6E", 
/* 315 */       "6461792C204D61792032352C2031393938003B" };
/*     */   
/*     */   private static final int NORTH = 0;
/*     */   
/*     */   private static final int EAST = 1;
/*     */   
/*     */   private static final int SOUTH = 2;
/*     */   
/*     */   private static final int WEST = 3;
/*     */   
/*     */   private static final int INFINITE = 99999999;
/*     */   
/*     */   private static final int PLUS1 = -1;
/*     */   
/*     */   private static final int MINUS1 = -2;
/*     */   private static final int WALL_TOOL = 1;
/*     */   private static final int COLOR_TOOL = 2;
/*     */   private static final int ROBOT_TOOL = 3;
/*     */   private static final int BEEPER_TOOL = 4;
/*     */   private static final int BEEPER_BAG_TOOL = 5;
/*     */   private static final int BIG_TOOL_SIZE = 20;
/*     */   private static final int COLOR_TOOL_SIZE = 12;
/*     */   private static final int KAREL_TOOL_SIZE = 28;
/*     */   private static final int BEEPER_TOOL_SIZE = 28;
/*     */   private static final int TOOL_SEP = 6;
/*     */   private static final int TOOL_Y_DELTA = 8;
/*     */   private static final int TOOL_MARGIN = 20;
/*     */   private static final int TOOL_X = 8;
/*     */   private static final int TOOL_Y = 3;
/*     */   private static final int LABEL_SEP = 5;
/*     */   private static final int ROBOT_DELTA = 300;
/*     */   private static final int ROBOT_SIZE = 22;
/*     */   private static final int ROBOT_SEP = 15;
/*     */   private static final int SELECTED_PIXELS = 3;
/*     */   private static final int WALL_LENGTH = 12;
/*     */   private static final int BEEPER_BAG_WIDTH = 35;
/*     */   private static final int BEEPER_BAG_HEIGHT = 47;
/*     */   private static final int BAG_LABEL_DELTA_Y = 28;
/*     */   private static final int WIDTH = 200;
/*     */   private static final int HEIGHT = 94;
/*     */   private static final Color[] COLORS = { 
/* 356 */       null, Color.black, Color.darkGray, Color.gray, Color.lightGray, Color.white, 
/* 357 */       Color.red, Color.pink, Color.orange, Color.yellow, Color.green, Color.cyan, Color.blue, Color.magenta };
/*     */   
/* 359 */   private static final int NCOLORS = COLORS.length;
/*     */   private KarelWorld world;
/*     */   private Vector tools;
/*     */   private MapTool selectedTool;
/*     */   private MapTool oldTool;
/*     */   private MapTool beeperBagTool;
/*     */   private Image beeperBagImage;
/*     */ }


/* Location:              /root/karel.jar!/stanford/karel/KarelWorldEditor.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */