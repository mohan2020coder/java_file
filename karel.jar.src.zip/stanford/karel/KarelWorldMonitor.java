package stanford.karel;

import java.awt.Point;

interface KarelWorldMonitor {
  void startWorldEdit();
  
  void endWorldEdit();
  
  void wallAction(Point paramPoint, int paramInt);
  
  void cornerAction(Point paramPoint);
  
  void trace();
  
  void setSpeed(double paramDouble);
  
  double getSpeed();
}


/* Location:              /root/karel.jar!/stanford/karel/KarelWorldMonitor.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */