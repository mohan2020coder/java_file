/*    */ package stanford.karel;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import java.awt.Point;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SuperKarel
/*    */   extends Karel
/*    */ {
/* 19 */   public static final Color BLACK = Color.black;
/* 20 */   public static final Color BLUE = Color.blue;
/* 21 */   public static final Color CYAN = Color.cyan;
/* 22 */   public static final Color DARK_GRAY = Color.darkGray;
/* 23 */   public static final Color GRAY = Color.gray;
/* 24 */   public static final Color GREEN = Color.green;
/* 25 */   public static final Color LIGHT_GRAY = Color.lightGray;
/* 26 */   public static final Color MAGENTA = Color.magenta;
/* 27 */   public static final Color ORANGE = Color.orange;
/* 28 */   public static final Color PINK = Color.pink;
/* 29 */   public static final Color RED = Color.red;
/* 30 */   public static final Color WHITE = Color.white;
/* 31 */   public static final Color YELLOW = Color.yellow;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void run() {}
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void turnRight() {
/* 44 */     checkWorld("turnRight");
/* 45 */     setDirection(KarelWorld.rightFrom(getDirection()));
/* 46 */     getWorld().trace();
/*    */   }
/*    */   
/*    */   public void turnAround() {
/* 50 */     checkWorld("turnAround");
/* 51 */     setDirection(KarelWorld.oppositeDirection(getDirection()));
/* 52 */     getWorld().trace();
/*    */   }
/*    */   
/*    */   public void paintCorner(Color color) {
/* 56 */     KarelWorld world = getWorld();
/* 57 */     Point pt = getLocation();
/* 58 */     checkWorld("paintCorner");
/* 59 */     world.setCornerColor(pt.x, pt.y, color);
/* 60 */     world.trace();
/*    */   }
/*    */   
/*    */   public boolean random() {
/* 64 */     checkWorld("random");
/* 65 */     return random(0.5D);
/*    */   }
/*    */   
/*    */   public boolean random(double p) {
/* 69 */     checkWorld("random");
/* 70 */     return (Math.random() < p);
/*    */   }
/*    */   
/*    */   public boolean cornerColorIs(Color color) {
/* 74 */     KarelWorld world = getWorld();
/* 75 */     Point pt = getLocation();
/* 76 */     checkWorld("cornerColorIs");
/* 77 */     if (color == null) {
/* 78 */       return (world.getCornerColor(pt.x, pt.y) == null);
/*    */     }
/* 80 */     return color.equals(world.getCornerColor(pt.x, pt.y));
/*    */   }
/*    */ }


/* Location:              /root/karel.jar!/stanford/karel/SuperKarel.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */