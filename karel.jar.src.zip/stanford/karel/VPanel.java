/*    */ package stanford.karel;
/*    */ 
/*    */ import java.awt.Component;
/*    */ import java.awt.Panel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class VPanel
/*    */   extends Panel
/*    */ {
/* 16 */   public VPanel() { setLayout(new HVLayout(3)); }
/*    */ 
/*    */ 
/*    */   
/* 20 */   public Component add(String constraint) { return add(constraint, null); }
/*    */ 
/*    */ 
/*    */   
/* 24 */   public Component add(Component comp) { return add("", comp); }
/*    */ 
/*    */   
/*    */   public Component add(String constraint, Component comp) {
/* 28 */     if (comp == null) comp = new EmptyCanvas(); 
/* 29 */     return super.add(constraint, comp);
/*    */   }
/*    */ }


/* Location:              /root/karel.jar!/stanford/karel/VPanel.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */